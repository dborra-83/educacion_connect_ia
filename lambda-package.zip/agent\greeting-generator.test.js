"use strict";
/**
 * Tests para greeting-generator
 */
Object.defineProperty(exports, "__esModule", { value: true });
const vitest_1 = require("vitest");
const greeting_generator_1 = require("./greeting-generator");
(0, vitest_1.describe)('GreetingGenerator', () => {
    const mockProfile = {
        studentId: 'STU001',
        firstName: 'Carlos',
        lastName: 'Rodríguez',
        email: 'carlos@universidad.edu',
        phone: '+57 300 123 4567',
        program: {
            name: 'Ingeniería Informática',
            code: 'ING-INF',
            enrollmentDate: '2022-01-15',
        },
        academicStatus: 'active',
    };
    (0, vitest_1.describe)('generateGreeting', () => {
        (0, vitest_1.it)('debe generar saludo con nombre completo', () => {
            const greeting = (0, greeting_generator_1.generateGreeting)(mockProfile);
            (0, vitest_1.expect)(greeting).toContain('Carlos Rodríguez');
            (0, vitest_1.expect)(greeting).toContain('Hola');
        });
        (0, vitest_1.it)('debe incluir nombre del programa si está disponible', () => {
            const greeting = (0, greeting_generator_1.generateGreeting)(mockProfile);
            (0, vitest_1.expect)(greeting).toContain('Ingeniería Informática');
        });
        (0, vitest_1.it)('debe incluir pregunta de ayuda', () => {
            const greeting = (0, greeting_generator_1.generateGreeting)(mockProfile);
            (0, vitest_1.expect)(greeting).toContain('¿En qué puedo ayudarte');
        });
        (0, vitest_1.it)('debe solicitar identificación cuando no hay perfil', () => {
            const greeting = (0, greeting_generator_1.generateGreeting)(undefined);
            (0, vitest_1.expect)(greeting).toContain('identificación');
            (0, vitest_1.expect)(greeting).not.toContain('Carlos');
        });
        (0, vitest_1.it)('debe manejar perfil sin programa', () => {
            const profileWithoutProgram = {
                ...mockProfile,
                program: undefined,
            };
            const greeting = (0, greeting_generator_1.generateGreeting)(profileWithoutProgram);
            (0, vitest_1.expect)(greeting).toContain('Carlos Rodríguez');
            (0, vitest_1.expect)(greeting).not.toContain('Ingeniería');
        });
    });
    (0, vitest_1.describe)('generateIdentificationRequest', () => {
        (0, vitest_1.it)('debe generar mensaje de solicitud de identificación', () => {
            const message = (0, greeting_generator_1.generateIdentificationRequest)();
            (0, vitest_1.expect)(message).toContain('Hola');
            (0, vitest_1.expect)(message).toContain('identificación');
            (0, vitest_1.expect)(message).toContain('estudiante');
        });
    });
    (0, vitest_1.describe)('generateDetailedGreeting', () => {
        (0, vitest_1.it)('debe generar saludo con estado académico activo', () => {
            const greeting = (0, greeting_generator_1.generateDetailedGreeting)(mockProfile, true);
            (0, vitest_1.expect)(greeting).toContain('Carlos Rodríguez');
            (0, vitest_1.expect)(greeting).toContain('activo');
        });
        (0, vitest_1.it)('debe generar saludo sin estado académico cuando no se solicita', () => {
            const greeting = (0, greeting_generator_1.generateDetailedGreeting)(mockProfile, false);
            (0, vitest_1.expect)(greeting).toContain('Carlos Rodríguez');
            (0, vitest_1.expect)(greeting).not.toContain('activo');
        });
        (0, vitest_1.it)('debe manejar estado académico graduado', () => {
            const graduatedProfile = {
                ...mockProfile,
                academicStatus: 'graduated',
            };
            const greeting = (0, greeting_generator_1.generateDetailedGreeting)(graduatedProfile, true);
            (0, vitest_1.expect)(greeting).toContain('Felicitaciones');
            (0, vitest_1.expect)(greeting).toContain('graduación');
        });
        (0, vitest_1.it)('debe manejar estado académico inactivo', () => {
            const inactiveProfile = {
                ...mockProfile,
                academicStatus: 'inactive',
            };
            const greeting = (0, greeting_generator_1.generateDetailedGreeting)(inactiveProfile, true);
            (0, vitest_1.expect)(greeting).toContain('inactivo');
        });
    });
    (0, vitest_1.describe)('generateReturningStudentGreeting', () => {
        (0, vitest_1.it)('debe generar saludo de retorno con primer nombre', () => {
            const greeting = (0, greeting_generator_1.generateReturningStudentGreeting)(mockProfile);
            (0, vitest_1.expect)(greeting).toContain('Carlos');
            (0, vitest_1.expect)(greeting).toContain('de nuevo');
        });
        (0, vitest_1.it)('debe mencionar último contacto si está disponible', () => {
            const profileWithCRM = {
                ...mockProfile,
                crmData: {
                    lastContact: new Date(Date.now() - 3 * 24 * 60 * 60 * 1000).toISOString(), // 3 días atrás
                    preferredChannel: 'email',
                    tags: [],
                },
            };
            const greeting = (0, greeting_generator_1.generateReturningStudentGreeting)(profileWithCRM);
            (0, vitest_1.expect)(greeting).toContain('Carlos');
            (0, vitest_1.expect)(greeting).toContain('días');
        });
        (0, vitest_1.it)('debe manejar contacto del mismo día', () => {
            const profileWithCRM = {
                ...mockProfile,
                crmData: {
                    lastContact: new Date().toISOString(),
                    preferredChannel: 'email',
                    tags: [],
                },
            };
            const greeting = (0, greeting_generator_1.generateReturningStudentGreeting)(profileWithCRM);
            (0, vitest_1.expect)(greeting).toContain('hoy');
        });
    });
    (0, vitest_1.describe)('sanitizeAndFormatName', () => {
        (0, vitest_1.it)('debe capitalizar nombres correctamente', () => {
            const result = (0, greeting_generator_1.sanitizeAndFormatName)('carlos', 'rodríguez');
            (0, vitest_1.expect)(result).toBe('Carlos Rodríguez');
        });
        (0, vitest_1.it)('debe manejar nombres con múltiples palabras', () => {
            const result = (0, greeting_generator_1.sanitizeAndFormatName)('juan carlos', 'garcía lópez');
            (0, vitest_1.expect)(result).toBe('Juan Carlos García López');
        });
        (0, vitest_1.it)('debe manejar nombres con espacios extra', () => {
            const result = (0, greeting_generator_1.sanitizeAndFormatName)('  carlos  ', '  rodríguez  ');
            (0, vitest_1.expect)(result).toBe('Carlos Rodríguez');
        });
        (0, vitest_1.it)('debe manejar nombres en mayúsculas', () => {
            const result = (0, greeting_generator_1.sanitizeAndFormatName)('CARLOS', 'RODRÍGUEZ');
            (0, vitest_1.expect)(result).toBe('Carlos Rodríguez');
        });
    });
    (0, vitest_1.describe)('generateTimeBasedGreeting', () => {
        (0, vitest_1.beforeEach)(() => {
            vitest_1.vi.useFakeTimers();
        });
        (0, vitest_1.afterEach)(() => {
            vitest_1.vi.useRealTimers();
        });
        (0, vitest_1.it)('debe generar "Buenos días" en la mañana', () => {
            vitest_1.vi.setSystemTime(new Date('2024-01-15T08:00:00'));
            const greeting = (0, greeting_generator_1.generateTimeBasedGreeting)(mockProfile);
            (0, vitest_1.expect)(greeting).toContain('Buenos días');
            (0, vitest_1.expect)(greeting).toContain('Carlos');
        });
        (0, vitest_1.it)('debe generar "Buenas tardes" en la tarde', () => {
            vitest_1.vi.setSystemTime(new Date('2024-01-15T15:00:00'));
            const greeting = (0, greeting_generator_1.generateTimeBasedGreeting)(mockProfile);
            (0, vitest_1.expect)(greeting).toContain('Buenas tardes');
        });
        (0, vitest_1.it)('debe generar "Buenas noches" en la noche', () => {
            vitest_1.vi.setSystemTime(new Date('2024-01-15T21:00:00'));
            const greeting = (0, greeting_generator_1.generateTimeBasedGreeting)(mockProfile);
            (0, vitest_1.expect)(greeting).toContain('Buenas noches');
        });
        (0, vitest_1.it)('debe incluir programa si está disponible', () => {
            vitest_1.vi.setSystemTime(new Date('2024-01-15T10:00:00'));
            const greeting = (0, greeting_generator_1.generateTimeBasedGreeting)(mockProfile);
            (0, vitest_1.expect)(greeting).toContain('Ingeniería Informática');
        });
    });
});
//# sourceMappingURL=greeting-generator.test.js.map