"use strict";
/**
 * Tests para profile-manager
 */
Object.defineProperty(exports, "__esModule", { value: true });
const vitest_1 = require("vitest");
const profile_manager_1 = require("./profile-manager");
(0, vitest_1.describe)('ProfileManager', () => {
    (0, vitest_1.describe)('extractStudentIdFromContext', () => {
        (0, vitest_1.it)('debe extraer studentId de Attributes', () => {
            const connectEvent = {
                Details: {
                    ContactData: {
                        Attributes: {
                            studentId: 'STU001',
                        },
                    },
                },
            };
            const result = (0, profile_manager_1.extractStudentIdFromContext)(connectEvent);
            (0, vitest_1.expect)(result).toBe('STU001');
        });
        (0, vitest_1.it)('debe extraer studentId de Parameters', () => {
            const connectEvent = {
                Details: {
                    Parameters: {
                        studentId: 'STU002',
                    },
                },
            };
            const result = (0, profile_manager_1.extractStudentIdFromContext)(connectEvent);
            (0, vitest_1.expect)(result).toBe('STU002');
        });
        (0, vitest_1.it)('debe retornar undefined si no hay studentId', () => {
            const connectEvent = {
                Details: {},
            };
            const result = (0, profile_manager_1.extractStudentIdFromContext)(connectEvent);
            (0, vitest_1.expect)(result).toBeUndefined();
        });
    });
    (0, vitest_1.describe)('retrieveStudentProfile', () => {
        (0, vitest_1.it)('debe recuperar perfil cuando hay studentId', async () => {
            const context = {
                sessionId: 'session-123',
                studentId: 'STU001',
                conversationHistory: [],
                entities: new Map(),
            };
            const profile = await (0, profile_manager_1.retrieveStudentProfile)(context, true);
            (0, vitest_1.expect)(profile).toBeDefined();
            (0, vitest_1.expect)(profile?.studentId).toBe('STU001');
            (0, vitest_1.expect)(context.studentProfile).toBeDefined();
        });
        (0, vitest_1.it)('debe usar caché si el perfil ya está en contexto', async () => {
            const cachedProfile = {
                studentId: 'STU001',
                firstName: 'Carlos',
                lastName: 'Rodríguez',
                email: 'carlos@test.com',
                phone: '+57 300 123 4567',
            };
            const context = {
                sessionId: 'session-123',
                studentId: 'STU001',
                studentProfile: cachedProfile,
                conversationHistory: [],
                entities: new Map(),
            };
            const profile = await (0, profile_manager_1.retrieveStudentProfile)(context, true);
            (0, vitest_1.expect)(profile).toBe(cachedProfile);
        });
        (0, vitest_1.it)('debe retornar undefined si no hay studentId', async () => {
            const context = {
                sessionId: 'session-123',
                conversationHistory: [],
                entities: new Map(),
            };
            const profile = await (0, profile_manager_1.retrieveStudentProfile)(context, true);
            (0, vitest_1.expect)(profile).toBeUndefined();
        });
    });
    (0, vitest_1.describe)('initializeConversationContext', () => {
        (0, vitest_1.it)('debe inicializar contexto con perfil cuando hay studentId', async () => {
            const connectEvent = {
                Details: {
                    ContactData: {
                        Attributes: {
                            studentId: 'STU001',
                        },
                    },
                },
            };
            const context = await (0, profile_manager_1.initializeConversationContext)('session-123', connectEvent, true);
            (0, vitest_1.expect)(context.sessionId).toBe('session-123');
            (0, vitest_1.expect)(context.studentId).toBe('STU001');
            (0, vitest_1.expect)(context.studentProfile).toBeDefined();
            (0, vitest_1.expect)(context.conversationHistory).toEqual([]);
        });
        (0, vitest_1.it)('debe inicializar contexto sin perfil cuando no hay studentId', async () => {
            const connectEvent = {
                Details: {},
            };
            const context = await (0, profile_manager_1.initializeConversationContext)('session-123', connectEvent, true);
            (0, vitest_1.expect)(context.sessionId).toBe('session-123');
            (0, vitest_1.expect)(context.studentId).toBeUndefined();
            (0, vitest_1.expect)(context.studentProfile).toBeUndefined();
        });
    });
    (0, vitest_1.describe)('validateUserDataAgainstProfile', () => {
        const mockProfile = {
            studentId: 'STU001',
            firstName: 'Carlos',
            lastName: 'Rodríguez',
            email: 'carlos@universidad.edu',
            phone: '+57 300 123 4567',
            program: {
                name: 'Ingeniería Informática',
                code: 'ING-INF',
                enrollmentDate: '2022-01-15',
            },
        };
        (0, vitest_1.it)('debe detectar contradicción en email', () => {
            const userData = {
                email: 'otro@email.com',
            };
            const result = (0, profile_manager_1.validateUserDataAgainstProfile)(userData, mockProfile);
            (0, vitest_1.expect)(result.hasContradiction).toBe(true);
            (0, vitest_1.expect)(result.contradictions.length).toBeGreaterThan(0);
            (0, vitest_1.expect)(result.contradictions[0]).toContain('Email');
        });
        (0, vitest_1.it)('debe detectar contradicción en teléfono', () => {
            const userData = {
                phone: '+57 310 999 8888',
            };
            const result = (0, profile_manager_1.validateUserDataAgainstProfile)(userData, mockProfile);
            (0, vitest_1.expect)(result.hasContradiction).toBe(true);
            (0, vitest_1.expect)(result.contradictions[0]).toContain('Teléfono');
        });
        (0, vitest_1.it)('debe detectar contradicción en nombre', () => {
            const userData = {
                firstName: 'Juan',
            };
            const result = (0, profile_manager_1.validateUserDataAgainstProfile)(userData, mockProfile);
            (0, vitest_1.expect)(result.hasContradiction).toBe(true);
            (0, vitest_1.expect)(result.contradictions[0]).toContain('Nombre');
        });
        (0, vitest_1.it)('debe detectar contradicción en programa', () => {
            const userData = {
                program: 'ADM-EMP',
            };
            const result = (0, profile_manager_1.validateUserDataAgainstProfile)(userData, mockProfile);
            (0, vitest_1.expect)(result.hasContradiction).toBe(true);
            (0, vitest_1.expect)(result.contradictions[0]).toContain('Programa');
        });
        (0, vitest_1.it)('no debe detectar contradicciones cuando los datos coinciden', () => {
            const userData = {
                email: 'carlos@universidad.edu',
                phone: '+57 300 123 4567',
                firstName: 'Carlos',
            };
            const result = (0, profile_manager_1.validateUserDataAgainstProfile)(userData, mockProfile);
            (0, vitest_1.expect)(result.hasContradiction).toBe(false);
            (0, vitest_1.expect)(result.contradictions.length).toBe(0);
        });
        (0, vitest_1.it)('debe detectar múltiples contradicciones', () => {
            const userData = {
                email: 'otro@email.com',
                phone: '+57 310 999 8888',
                firstName: 'Juan',
            };
            const result = (0, profile_manager_1.validateUserDataAgainstProfile)(userData, mockProfile);
            (0, vitest_1.expect)(result.hasContradiction).toBe(true);
            (0, vitest_1.expect)(result.contradictions.length).toBe(3);
        });
    });
    (0, vitest_1.describe)('generateConfirmationMessage', () => {
        (0, vitest_1.it)('debe generar mensaje con lista de contradicciones', () => {
            const contradictions = [
                'Email proporcionado no coincide',
                'Teléfono proporcionado no coincide',
            ];
            const message = (0, profile_manager_1.generateConfirmationMessage)(contradictions);
            (0, vitest_1.expect)(message).toContain('diferencias');
            (0, vitest_1.expect)(message).toContain('1. Email');
            (0, vitest_1.expect)(message).toContain('2. Teléfono');
            (0, vitest_1.expect)(message).toContain('confirmar');
        });
        (0, vitest_1.it)('debe numerar las contradicciones', () => {
            const contradictions = ['Contradicción 1', 'Contradicción 2', 'Contradicción 3'];
            const message = (0, profile_manager_1.generateConfirmationMessage)(contradictions);
            (0, vitest_1.expect)(message).toContain('1.');
            (0, vitest_1.expect)(message).toContain('2.');
            (0, vitest_1.expect)(message).toContain('3.');
        });
    });
});
//# sourceMappingURL=profile-manager.test.js.map