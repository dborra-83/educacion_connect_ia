/**
 * Tests para el Gestor de Estado de Conversación
 */
export {};
//# sourceMappingURL=conversation-manager.test.d.ts.map