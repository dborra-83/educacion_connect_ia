/**
 * Tests para el Procesador de Consultas a Base de Conocimiento
 */
export {};
//# sourceMappingURL=knowledge-query-processor.test.d.ts.map