/**
 * Exporta todas las herramientas MCP
 */
export * from './get-student-profile';
export * from './query-knowledge-base';
export * from './check-academic-record';
export * from './generate-certificate';
//# sourceMappingURL=index.d.ts.map