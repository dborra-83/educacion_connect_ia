/**
 * Gestor de perfiles de estudiantes
 * Maneja la recuperación y caché de perfiles durante la sesión
 */
import { StudentProfile } from '../types/mcp-tools';
import { ConversationContext } from '../types/models';
/**
 * Extrae el studentId del contexto de Amazon Connect
 * En producción, esto vendría del evento de Amazon Connect
 */
export declare function extractStudentIdFromContext(connectEvent: any): string | undefined;
/**
 * Recupera el perfil del estudiante al iniciar la conversación
 * Implementa caché en el contexto de conversación
 */
export declare function retrieveStudentProfile(context: ConversationContext, useMock?: boolean): Promise<StudentProfile | undefined>;
/**
 * Inicializa el contexto de conversación con el perfil del estudiante
 */
export declare function initializeConversationContext(sessionId: string, connectEvent: any, useMock?: boolean): Promise<ConversationContext>;
/**
 * Valida si los datos proporcionados por el usuario contradicen el perfil
 */
export declare function validateUserDataAgainstProfile(userProvidedData: Record<string, any>, profile: StudentProfile): {
    hasContradiction: boolean;
    contradictions: string[];
};
/**
 * Genera mensaje de confirmación cuando hay datos contradictorios
 */
export declare function generateConfirmationMessage(contradictions: string[]): string;
//# sourceMappingURL=profile-manager.d.ts.map