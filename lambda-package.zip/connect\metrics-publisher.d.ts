/**
 * Publicador de métricas a CloudWatch
 * Cumple con requisito 9.4: Exposición de métricas
 */
/**
 * Tipos de métricas
 */
export declare enum MetricType {
    ERROR_RATE = "ErrorRate",
    RESPONSE_TIME = "ResponseTime",
    ESCALATION_RATE = "EscalationRate",
    TOOL_USAGE = "ToolUsage",
    INTENT_DETECTION = "IntentDetection",
    SESSION_DURATION = "SessionDuration"
}
/**
 * Unidades de métricas
 */
export declare enum MetricUnit {
    COUNT = "Count",
    MILLISECONDS = "Milliseconds",
    SECONDS = "Seconds",
    PERCENT = "Percent",
    NONE = "None"
}
/**
 * Datos de una métrica
 */
export interface MetricData {
    metricName: string;
    value: number;
    unit: MetricUnit;
    timestamp: Date;
    dimensions?: Record<string, string>;
}
/**
 * Publicador de métricas a CloudWatch
 */
export declare class MetricsPublisher {
    private namespace;
    private metricsBuffer;
    private flushInterval;
    private flushTimer?;
    constructor(namespace?: string, flushInterval?: number);
    /**
     * Publica una métrica de tasa de error
     */
    publishErrorRate(errorOccurred: boolean, dimensions?: Record<string, string>): void;
    /**
     * Publica una métrica de tiempo de respuesta
     */
    publishResponseTime(milliseconds: number, dimensions?: Record<string, string>): void;
    /**
     * Publica una métrica de tasa de escalamiento
     */
    publishEscalationRate(escalated: boolean, dimensions?: Record<string, string>): void;
    /**
     * Publica una métrica de uso de herramienta
     */
    publishToolUsage(toolName: string, dimensions?: Record<string, string>): void;
    /**
     * Publica una métrica de detección de intención
     */
    publishIntentDetection(intent: string, confidence: number, dimensions?: Record<string, string>): void;
    /**
     * Publica una métrica de duración de sesión
     */
    publishSessionDuration(seconds: number, dimensions?: Record<string, string>): void;
    /**
     * Publica una métrica genérica
     */
    private publishMetric;
    /**
     * Envía todas las métricas acumuladas a CloudWatch
     */
    flush(): Promise<void>;
    /**
     * Inicia el flush automático de métricas
     */
    private startAutoFlush;
    /**
     * Detiene el flush automático y envía métricas pendientes
     */
    stop(): Promise<void>;
}
/**
 * Instancia singleton del publicador de métricas
 */
export declare const metricsPublisher: MetricsPublisher;
//# sourceMappingURL=metrics-publisher.d.ts.map