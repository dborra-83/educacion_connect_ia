/**
 * Tests para profile-manager
 */
export {};
//# sourceMappingURL=profile-manager.test.d.ts.map