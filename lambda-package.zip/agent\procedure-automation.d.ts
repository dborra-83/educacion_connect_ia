/**
 * Automatización de Trámites Administrativos
 * Clasifica, valida y ejecuta trámites administrativos de manera automatizada
 */
/**
 * Tipos de trámite soportados
 */
export declare enum ProcedureType {
    CERTIFICATE_REQUEST = "certificate_request",
    ENROLLMENT = "enrollment",
    COURSE_REGISTRATION = "course_registration",
    GRADE_APPEAL = "grade_appeal",
    PROGRAM_CHANGE = "program_change",
    WITHDRAWAL = "withdrawal",
    UNKNOWN = "unknown"
}
/**
 * Resultado de clasificación de trámite
 */
export interface ProcedureClassification {
    type: ProcedureType;
    confidence: number;
    parameters: Record<string, any>;
}
/**
 * Resultado de validación de requisitos
 */
export interface ValidationResult {
    isValid: boolean;
    missingRequirements: string[];
    impediments: string[];
    warnings: string[];
}
/**
 * Paso de ejecución de trámite
 */
export interface ProcedureStep {
    stepNumber: number;
    name: string;
    status: 'pending' | 'in_progress' | 'completed' | 'failed';
    result?: any;
    error?: string;
}
/**
 * Resultado de ejecución de trámite
 */
export interface ProcedureExecutionResult {
    success: boolean;
    procedureType: ProcedureType;
    steps: ProcedureStep[];
    finalMessage: string;
    trackingId?: string;
}
/**
 * Clasificador de tipos de trámite
 */
export declare class ProcedureClassifier {
    /**
     * Identifica el tipo de trámite desde el mensaje del usuario
     */
    static classify(userMessage: string): ProcedureClassification;
}
/**
 * Validador de requisitos de trámite
 */
export declare class ProcedureValidator {
    /**
     * Valida que el estudiante cumple los requisitos para un trámite
     */
    static validate(procedureType: ProcedureType, studentId: string, parameters: Record<string, any>, useMock?: boolean): Promise<ValidationResult>;
    /**
     * Valida requisitos para solicitud de certificado
     */
    private static validateCertificateRequest;
    /**
     * Valida requisitos para inscripción
     */
    private static validateEnrollment;
    /**
     * Valida requisitos para registro de materias
     */
    private static validateCourseRegistration;
    /**
     * Valida requisitos para apelación de calificación
     */
    private static validateGradeAppeal;
    /**
     * Valida requisitos para cambio de programa
     */
    private static validateProgramChange;
    /**
     * Valida requisitos para retiro
     */
    private static validateWithdrawal;
}
/**
 * Ejecutor de trámites multi-paso
 */
export declare class ProcedureExecutor {
    /**
     * Ejecuta un trámite completo con todos sus pasos
     */
    static execute(procedureType: ProcedureType, studentId: string, parameters: Record<string, any>, useMock?: boolean): Promise<ProcedureExecutionResult>;
    /**
     * Ejecuta solicitud de certificado
     */
    private static executeCertificateRequest;
    /**
     * Ejecuta inscripción
     */
    private static executeEnrollment;
    /**
     * Ejecuta registro de materias
     */
    private static executeCourseRegistration;
    /**
     * Ejecuta apelación de calificación
     */
    private static executeGradeAppeal;
    /**
     * Ejecuta cambio de programa
     */
    private static executeProgramChange;
    /**
     * Ejecuta retiro
     */
    private static executeWithdrawal;
}
//# sourceMappingURL=procedure-automation.d.ts.map