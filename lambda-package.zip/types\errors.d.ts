/**
 * Jerarquía de errores personalizados del sistema
 */
export declare class MCPError extends Error {
    code: string;
    statusCode: number;
    metadata?: Record<string, any>;
    constructor(message: string, code: string, statusCode?: number, metadata?: Record<string, any>);
}
export declare class StudentNotFoundError extends MCPError {
    constructor(studentId: string);
}
export declare class InvalidStudentIdError extends MCPError {
    constructor(studentId: string);
}
export declare class EmptyQueryError extends MCPError {
    constructor();
}
export declare class NoResultsFoundError extends MCPError {
    constructor(query: string);
}
export declare class StudentHasDebtsError extends MCPError {
    constructor(studentId: string, debtAmount: number);
}
export declare class InvalidCertificateTypeError extends MCPError {
    constructor(certificateType: string);
}
export declare class GenerationFailedError extends MCPError {
    constructor(reason: string);
}
export declare class DeliveryFailedError extends MCPError {
    constructor(reason: string, destination: string);
}
export declare class ServiceUnavailableError extends MCPError {
    constructor(serviceName: string);
}
export declare class TimeoutError extends MCPError {
    constructor(operation: string, timeoutMs: number);
}
export declare class UnauthorizedAccessError extends MCPError {
    constructor(resource: string);
}
export declare class ForbiddenAccessError extends MCPError {
    constructor(resource: string, reason: string);
}
export interface ErrorResponse {
    error: {
        code: string;
        message: string;
        statusCode: number;
        metadata?: Record<string, any>;
        timestamp: string;
    };
}
export interface ErrorMetadata {
    timestamp: string;
    requestId?: string;
    studentId?: string;
    operation?: string;
    stackTrace?: string;
}
export declare function createErrorResponse(error: MCPError, requestId?: string): ErrorResponse;
//# sourceMappingURL=errors.d.ts.map