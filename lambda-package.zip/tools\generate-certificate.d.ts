/**
 * Herramienta MCP: generateCertificate
 * Genera y envía certificados académicos
 * Integración con Lambda para generación de PDFs y envío
 */
import { GenerateCertificateInput, GenerateCertificateResult } from '../types/mcp-tools';
/**
 * Genera el certificado
 */
export declare function generateCertificate(input: GenerateCertificateInput): Promise<GenerateCertificateResult>;
/**
 * Mock para desarrollo/testing
 * Simula generación y entrega de certificados
 */
export declare function generateCertificateMock(input: GenerateCertificateInput): Promise<GenerateCertificateResult>;
/**
 * Mock que simula fallo en generación
 */
export declare function generateCertificateFailMock(input: GenerateCertificateInput): Promise<GenerateCertificateResult>;
/**
 * Mock que simula fallo en entrega
 */
export declare function generateCertificateDeliveryFailMock(input: GenerateCertificateInput): Promise<GenerateCertificateResult>;
//# sourceMappingURL=generate-certificate.d.ts.map