/**
 * Herramienta MCP: getStudentProfile
 * Recupera el perfil unificado del estudiante desde DynamoDB
 * Integra datos de CRM y LMS
 */
import { GetStudentProfileInput, StudentProfile } from '../types/mcp-tools';
/**
 * Recupera el perfil del estudiante desde DynamoDB
 */
export declare function getStudentProfile(input: GetStudentProfileInput): Promise<StudentProfile>;
/**
 * Mock para desarrollo/testing sin AWS
 * Simula datos de estudiantes
 */
export declare function getStudentProfileMock(input: GetStudentProfileInput): Promise<StudentProfile>;
//# sourceMappingURL=get-student-profile.d.ts.map