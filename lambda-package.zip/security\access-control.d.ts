/**
 * Control de acceso y detección de intentos no autorizados
 * Cumple con requisito 10.5: Bloqueo de accesos no autorizados
 */
/**
 * Resultado de verificación de acceso
 */
export interface AccessCheckResult {
    allowed: boolean;
    reason?: string;
    blocked?: boolean;
    requiresEscalation?: boolean;
}
/**
 * Control de acceso
 */
export declare class AccessControl {
    /**
     * Verifica si se permite el acceso a un recurso
     */
    static checkAccess(params: {
        sessionId: string;
        authenticatedStudentId?: string;
        requestedStudentId: string;
        resourceType: string;
        operation: string;
    }): Promise<AccessCheckResult>;
    /**
     * Verifica si una sesión está bloqueada
     */
    private static isSessionBlocked;
    /**
     * Registra un intento sospechoso
     */
    private static recordSuspiciousAttempt;
    /**
     * Determina si se debe bloquear una sesión
     */
    private static shouldBlockSession;
    /**
     * Bloquea una sesión temporalmente
     */
    private static blockSession;
    /**
     * Desbloquea una sesión manualmente
     */
    static unblockSession(sessionId: string): void;
    /**
     * Obtiene estadísticas de seguridad
     */
    static getSecurityStats(): {
        blockedSessions: number;
        suspiciousAttempts: number;
    };
    /**
     * Limpia sesiones bloqueadas expiradas
     */
    static cleanupExpiredBlocks(): number;
}
//# sourceMappingURL=access-control.d.ts.map