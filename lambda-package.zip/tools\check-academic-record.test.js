"use strict";
/**
 * Tests para checkAcademicRecord
 */
Object.defineProperty(exports, "__esModule", { value: true });
const vitest_1 = require("vitest");
const check_academic_record_1 = require("./check-academic-record");
const errors_1 = require("../types/errors");
(0, vitest_1.describe)('checkAcademicRecord', () => {
    (0, vitest_1.describe)('Casos de éxito', () => {
        (0, vitest_1.it)('debe recuperar historial académico completo', async () => {
            const result = await (0, check_academic_record_1.checkAcademicRecordMock)({
                studentId: 'STU001',
                includeCourses: true,
                includeGrades: true,
            });
            (0, vitest_1.expect)(result).toBeDefined();
            (0, vitest_1.expect)(result.studentId).toBe('STU001');
            (0, vitest_1.expect)(result.gpa).toBeGreaterThan(0);
            (0, vitest_1.expect)(result.totalCredits).toBeGreaterThan(0);
            (0, vitest_1.expect)(result.completedCredits).toBeGreaterThan(0);
            (0, vitest_1.expect)(result.academicStanding).toBeTruthy();
            (0, vitest_1.expect)(result.courses).toBeDefined();
            (0, vitest_1.expect)(result.courses.length).toBeGreaterThan(0);
        });
        (0, vitest_1.it)('debe incluir calificaciones cuando includeGrades es true', async () => {
            const result = await (0, check_academic_record_1.checkAcademicRecordMock)({
                studentId: 'STU001',
                includeCourses: true,
                includeGrades: true,
            });
            (0, vitest_1.expect)(result.courses).toBeDefined();
            (0, vitest_1.expect)(result.courses[0].grade).toBeTruthy();
        });
        (0, vitest_1.it)('debe excluir calificaciones cuando includeGrades es false', async () => {
            const result = await (0, check_academic_record_1.checkAcademicRecordMock)({
                studentId: 'STU001',
                includeCourses: true,
                includeGrades: false,
            });
            (0, vitest_1.expect)(result.courses).toBeDefined();
            (0, vitest_1.expect)(result.courses[0].grade).toBe('');
        });
        (0, vitest_1.it)('debe filtrar cursos por semestre', async () => {
            const result = await (0, check_academic_record_1.checkAcademicRecordMock)({
                studentId: 'STU001',
                includeCourses: true,
                semester: '2023-1',
            });
            (0, vitest_1.expect)(result.courses).toBeDefined();
            result.courses.forEach((course) => {
                (0, vitest_1.expect)(course.semester).toBe('2023-1');
            });
        });
        (0, vitest_1.it)('debe retornar estudiante con buen rendimiento académico', async () => {
            const result = await (0, check_academic_record_1.checkAcademicRecordMock)({
                studentId: 'STU002',
            });
            (0, vitest_1.expect)(result.gpa).toBeGreaterThan(3.5);
            (0, vitest_1.expect)(result.academicStanding).toBe('good');
        });
    });
    (0, vitest_1.describe)('Detección de alertas académicas', () => {
        (0, vitest_1.it)('debe detectar materias reprobadas', async () => {
            const result = await (0, check_academic_record_1.checkAcademicRecordMock)({
                studentId: 'STU001',
                includeCourses: true,
            });
            (0, vitest_1.expect)(result.alerts).toBeDefined();
            const failedAlert = result.alerts.find((a) => a.type === 'failed_course');
            (0, vitest_1.expect)(failedAlert).toBeDefined();
            (0, vitest_1.expect)(failedAlert.message).toContain('reprobada');
        });
        (0, vitest_1.it)('debe detectar GPA bajo', async () => {
            const result = await (0, check_academic_record_1.checkAcademicRecordMock)({
                studentId: 'STU001',
            });
            (0, vitest_1.expect)(result.alerts).toBeDefined();
            const lowGPAAlert = result.alerts.find((a) => a.type === 'low_gpa');
            (0, vitest_1.expect)(lowGPAAlert).toBeDefined();
            (0, vitest_1.expect)(lowGPAAlert.severity).toBeTruthy();
        });
        (0, vitest_1.it)('debe asignar severidad alta a múltiples materias reprobadas', async () => {
            const result = await (0, check_academic_record_1.checkAcademicRecordMock)({
                studentId: 'STU001',
                includeCourses: true,
            });
            const failedCourses = result.courses.filter((c) => c.status === 'failed');
            if (failedCourses.length > 2) {
                const failedAlert = result.alerts.find((a) => a.type === 'failed_course');
                (0, vitest_1.expect)(failedAlert.severity).toBe('high');
            }
        });
        (0, vitest_1.it)('no debe generar alertas para estudiante con buen rendimiento', async () => {
            const result = await (0, check_academic_record_1.checkAcademicRecordMock)({
                studentId: 'STU002',
            });
            (0, vitest_1.expect)(result.alerts).toBeDefined();
            (0, vitest_1.expect)(result.alerts.length).toBe(0);
        });
    });
    (0, vitest_1.describe)('Casos de error', () => {
        (0, vitest_1.it)('debe lanzar StudentNotFoundError cuando el estudiante no existe', async () => {
            await (0, vitest_1.expect)((0, check_academic_record_1.checkAcademicRecordMock)({
                studentId: 'STU999',
            })).rejects.toThrow(errors_1.StudentNotFoundError);
        });
        (0, vitest_1.it)('debe lanzar InvalidStudentIdError cuando el ID está vacío', async () => {
            await (0, vitest_1.expect)((0, check_academic_record_1.checkAcademicRecordMock)({
                studentId: '',
            })).rejects.toThrow(errors_1.InvalidStudentIdError);
        });
    });
    (0, vitest_1.describe)('Validación de datos', () => {
        (0, vitest_1.it)('debe incluir todos los campos requeridos en cada curso', async () => {
            const result = await (0, check_academic_record_1.checkAcademicRecordMock)({
                studentId: 'STU001',
                includeCourses: true,
            });
            result.courses.forEach((course) => {
                (0, vitest_1.expect)(course.courseCode).toBeTruthy();
                (0, vitest_1.expect)(course.courseName).toBeTruthy();
                (0, vitest_1.expect)(course.semester).toBeTruthy();
                (0, vitest_1.expect)(course.status).toBeTruthy();
                (0, vitest_1.expect)(course.credits).toBeGreaterThan(0);
            });
        });
        (0, vitest_1.it)('debe tener créditos completados menores o iguales a créditos totales', async () => {
            const result = await (0, check_academic_record_1.checkAcademicRecordMock)({
                studentId: 'STU001',
            });
            (0, vitest_1.expect)(result.completedCredits).toBeLessThanOrEqual(result.totalCredits);
        });
        (0, vitest_1.it)('debe tener GPA entre 0 y 5', async () => {
            const result = await (0, check_academic_record_1.checkAcademicRecordMock)({
                studentId: 'STU001',
            });
            (0, vitest_1.expect)(result.gpa).toBeGreaterThanOrEqual(0);
            (0, vitest_1.expect)(result.gpa).toBeLessThanOrEqual(5);
        });
    });
});
//# sourceMappingURL=check-academic-record.test.js.map