export {};
//# sourceMappingURL=access-control.test.d.ts.map