/**
 * Utilidad para reintentos con backoff exponencial
 * Implementa estrategia de reintento con delay exponencial: 1s, 2s, 4s
 */
export declare function retryWithBackoff<T>(fn: () => Promise<T>, maxRetries?: number, initialDelayMs?: number): Promise<T>;
/**
 * Delay helper para testing y uso general
 */
export declare function delay(ms: number): Promise<void>;
//# sourceMappingURL=retry.d.ts.map