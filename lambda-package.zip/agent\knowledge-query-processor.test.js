"use strict";
/**
 * Tests para el Procesador de Consultas a Base de Conocimiento
 */
Object.defineProperty(exports, "__esModule", { value: true });
const vitest_1 = require("vitest");
const knowledge_query_processor_1 = require("./knowledge-query-processor");
(0, vitest_1.describe)('KnowledgeQueryProcessor', () => {
    let processor;
    (0, vitest_1.beforeEach)(() => {
        processor = new knowledge_query_processor_1.KnowledgeQueryProcessor(true); // usar mocks
    });
    (0, vitest_1.describe)('Detección de Tipo de Consulta', () => {
        (0, vitest_1.it)('debe detectar consulta sobre pensum', async () => {
            const result = await processor.processQuery('¿Cuál es el pensum de Ingeniería?');
            (0, vitest_1.expect)(result.queryType).toBe(knowledge_query_processor_1.QueryType.PENSUM);
        });
        (0, vitest_1.it)('debe detectar consulta sobre requisitos', async () => {
            const result = await processor.processQuery('¿Qué requisitos necesito para inscribirme?');
            (0, vitest_1.expect)(result.queryType).toBe(knowledge_query_processor_1.QueryType.REQUISITOS);
        });
        (0, vitest_1.it)('debe detectar consulta sobre fechas', async () => {
            const result = await processor.processQuery('¿Cuándo son las inscripciones?');
            (0, vitest_1.expect)(result.queryType).toBe(knowledge_query_processor_1.QueryType.FECHAS);
        });
        (0, vitest_1.it)('debe detectar consulta sobre admisión', async () => {
            const result = await processor.processQuery('¿Cómo puedo aplicar para admisión?');
            (0, vitest_1.expect)(result.queryType).toBe(knowledge_query_processor_1.QueryType.ADMISION);
        });
        (0, vitest_1.it)('debe detectar consulta sobre programa', async () => {
            const result = await processor.processQuery('¿Qué programas de maestría ofrecen?');
            (0, vitest_1.expect)(result.queryType).toBe(knowledge_query_processor_1.QueryType.PROGRAMA);
        });
        (0, vitest_1.it)('debe detectar consulta general', async () => {
            const result = await processor.processQuery('¿Dónde está la biblioteca?');
            (0, vitest_1.expect)(result.queryType).toBe(knowledge_query_processor_1.QueryType.GENERAL);
        });
    });
    (0, vitest_1.describe)('Procesamiento de Consultas', () => {
        (0, vitest_1.it)('debe procesar consulta y retornar resultados', async () => {
            const result = await processor.processQuery('¿Cuál es el pensum de Ingeniería Informática?');
            (0, vitest_1.expect)(result).toBeDefined();
            (0, vitest_1.expect)(result.answer).toBeTruthy();
            (0, vitest_1.expect)(result.hasResults).toBe(true);
        });
        (0, vitest_1.it)('debe incluir fuentes en los resultados', async () => {
            const result = await processor.processQuery('¿Cuáles son los requisitos de admisión?');
            (0, vitest_1.expect)(result.sources).toBeDefined();
            (0, vitest_1.expect)(Array.isArray(result.sources)).toBe(true);
        });
        (0, vitest_1.it)('debe formatear respuesta con excerpts', async () => {
            const result = await processor.processQuery('¿Qué programas ofrecen?');
            (0, vitest_1.expect)(result.answer).toContain('**');
            (0, vitest_1.expect)(result.hasResults).toBe(true);
        });
        (0, vitest_1.it)('debe incluir introducción apropiada según tipo de consulta', async () => {
            const result = await processor.processQuery('¿Cuál es el pensum?');
            (0, vitest_1.expect)(result.answer).toContain('plan de estudios');
        });
    });
    (0, vitest_1.describe)('Manejo de Consultas sin Resultados', () => {
        (0, vitest_1.it)('debe generar mensaje apropiado cuando no hay resultados', async () => {
            // Esta consulta debería retornar resultados con el mock, pero probamos la lógica
            const result = await processor.processQuery('xyz123 consulta inexistente');
            (0, vitest_1.expect)(result).toBeDefined();
            (0, vitest_1.expect)(result.answer).toBeTruthy();
        });
        (0, vitest_1.it)('debe incluir sugerencias cuando no hay resultados', async () => {
            const result = await processor.processQuery('consulta muy específica sin resultados');
            // El mock siempre retorna resultados, pero verificamos que la estructura esté correcta
            (0, vitest_1.expect)(result.answer).toBeTruthy();
        });
    });
    (0, vitest_1.describe)('Citación de Fuentes', () => {
        (0, vitest_1.it)('debe extraer fuentes de los resultados', async () => {
            const result = await processor.processQuery('¿Qué es el programa de Ingeniería?');
            if (result.hasResults) {
                (0, vitest_1.expect)(result.sources.length).toBeGreaterThan(0);
            }
        });
        (0, vitest_1.it)('debe incluir fuentes en la respuesta formateada', async () => {
            const result = await processor.processQuery('Información sobre admisiones');
            if (result.hasResults && result.sources.length > 0) {
                (0, vitest_1.expect)(result.answer).toContain('Fuentes:');
            }
        });
        (0, vitest_1.it)('debe evitar fuentes duplicadas', async () => {
            const result = await processor.processQuery('Programas académicos');
            if (result.hasResults) {
                const uniqueSources = new Set(result.sources);
                (0, vitest_1.expect)(uniqueSources.size).toBe(result.sources.length);
            }
        });
    });
    (0, vitest_1.describe)('Filtrado por Programa', () => {
        (0, vitest_1.it)('debe aceptar programId como parámetro', async () => {
            const result = await processor.processQuery('¿Cuál es el pensum?', 'PROG001');
            (0, vitest_1.expect)(result).toBeDefined();
            (0, vitest_1.expect)(result.hasResults).toBe(true);
        });
        (0, vitest_1.it)('debe procesar consulta sin programId', async () => {
            const result = await processor.processQuery('Información general');
            (0, vitest_1.expect)(result).toBeDefined();
        });
    });
    (0, vitest_1.describe)('Generación de Alternativas', () => {
        (0, vitest_1.it)('debe generar mensaje de alternativas', () => {
            const alternatives = processor.generateAlternatives();
            (0, vitest_1.expect)(alternatives).toBeTruthy();
            (0, vitest_1.expect)(alternatives).toContain('Reformular');
            (0, vitest_1.expect)(alternatives).toContain('Contactar');
        });
        (0, vitest_1.it)('debe incluir múltiples opciones en alternativas', () => {
            const alternatives = processor.generateAlternatives();
            (0, vitest_1.expect)(alternatives).toContain('•');
            (0, vitest_1.expect)(alternatives.split('•').length).toBeGreaterThan(2);
        });
    });
    (0, vitest_1.describe)('Formateo de Respuestas', () => {
        (0, vitest_1.it)('debe numerar los resultados', async () => {
            const result = await processor.processQuery('Programas disponibles');
            if (result.hasResults) {
                (0, vitest_1.expect)(result.answer).toMatch(/\*\*\d+\./);
            }
        });
        (0, vitest_1.it)('debe incluir títulos en negrita', async () => {
            const result = await processor.processQuery('Información académica');
            if (result.hasResults) {
                (0, vitest_1.expect)(result.answer).toContain('**');
            }
        });
        (0, vitest_1.it)('debe separar resultados con saltos de línea', async () => {
            const result = await processor.processQuery('Consulta general');
            if (result.hasResults) {
                (0, vitest_1.expect)(result.answer).toContain('\n\n');
            }
        });
    });
    (0, vitest_1.describe)('Tipos de Consulta Específicos', () => {
        (0, vitest_1.it)('debe manejar consultas sobre malla curricular', async () => {
            const result = await processor.processQuery('¿Cuál es la malla curricular?');
            (0, vitest_1.expect)(result.queryType).toBe(knowledge_query_processor_1.QueryType.PENSUM);
        });
        (0, vitest_1.it)('debe manejar consultas sobre documentos requeridos', async () => {
            const result = await processor.processQuery('¿Qué documentos necesito?');
            (0, vitest_1.expect)(result.queryType).toBe(knowledge_query_processor_1.QueryType.REQUISITOS);
        });
        (0, vitest_1.it)('debe manejar consultas sobre plazos', async () => {
            const result = await processor.processQuery('¿Cuál es el plazo de matrícula?');
            (0, vitest_1.expect)(result.queryType).toBe(knowledge_query_processor_1.QueryType.FECHAS);
        });
        (0, vitest_1.it)('debe manejar consultas sobre proceso de ingreso', async () => {
            const result = await processor.processQuery('¿Cómo es el proceso de ingreso?');
            (0, vitest_1.expect)(result.queryType).toBe(knowledge_query_processor_1.QueryType.ADMISION);
        });
    });
    (0, vitest_1.describe)('Integración con Base de Conocimiento', () => {
        (0, vitest_1.it)('debe invocar queryKnowledgeBase correctamente', async () => {
            const result = await processor.processQuery('Consulta de prueba');
            (0, vitest_1.expect)(result).toBeDefined();
            (0, vitest_1.expect)(result.queryType).toBeDefined();
        });
        (0, vitest_1.it)('debe manejar múltiples resultados', async () => {
            const result = await processor.processQuery('Programas académicos disponibles');
            (0, vitest_1.expect)(result.hasResults).toBe(true);
        });
    });
});
//# sourceMappingURL=knowledge-query-processor.test.js.map