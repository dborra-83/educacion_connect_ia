"use strict";
/**
 * Orquestador de Generación de Certificados
 * Maneja el flujo completo: verificación de identidad, deudas, generación y entrega
 */
Object.defineProperty(exports, "__esModule", { value: true });
exports.orchestrateCertificateGeneration = orchestrateCertificateGeneration;
exports.generateCertificateRequestMessage = generateCertificateRequestMessage;
exports.validateCertificateRequest = validateCertificateRequest;
const get_student_profile_1 = require("../tools/get-student-profile");
const check_academic_record_1 = require("../tools/check-academic-record");
const generate_certificate_1 = require("../tools/generate-certificate");
const errors_1 = require("../types/errors");
const logger_1 = require("../utils/logger");
/**
 * Verifica la identidad del estudiante
 */
async function verifyStudentIdentity(studentId, useMock = true) {
    logger_1.logger.info(`Verificando identidad del estudiante: ${studentId}`);
    const getProfileFn = useMock ? get_student_profile_1.getStudentProfileMock : get_student_profile_1.getStudentProfile;
    const profile = await getProfileFn({
        studentId,
        includeAcademic: true,
        includeCRM: false,
    });
    logger_1.logger.info(`Identidad verificada para: ${profile.firstName} ${profile.lastName}`);
    return profile;
}
/**
 * Verifica si el estudiante tiene deudas pendientes
 */
async function checkStudentDebts(studentId, useMock = true) {
    logger_1.logger.info(`Verificando deudas del estudiante: ${studentId}`);
    const checkRecordFn = useMock ? check_academic_record_1.checkAcademicRecordMock : check_academic_record_1.checkAcademicRecord;
    try {
        const record = await checkRecordFn({
            studentId,
            includeCourses: false,
            includeGrades: false,
        });
        // Verificar si hay deudas en el estado financiero
        // En el mock, esto viene en alerts o podríamos tener un campo específico
        const hasDebts = record.alerts?.some((alert) => alert.message.toLowerCase().includes('deuda'));
        if (hasDebts) {
            // Intentar extraer monto de la deuda
            const debtAlert = record.alerts?.find((alert) => alert.message.toLowerCase().includes('deuda'));
            logger_1.logger.warn(`Estudiante ${studentId} tiene deudas pendientes`);
            return {
                hasDebts: true,
                debtAmount: 0, // En producción, esto vendría del sistema financiero
            };
        }
        logger_1.logger.info(`Estudiante ${studentId} no tiene deudas pendientes`);
        return {
            hasDebts: false,
        };
    }
    catch (error) {
        logger_1.logger.error(`Error al verificar deudas de ${studentId}:`, error);
        // En caso de error, asumir que no hay deudas para no bloquear innecesariamente
        return {
            hasDebts: false,
        };
    }
}
/**
 * Orquesta el proceso completo de generación de certificado
 * Implementa el flujo: verificar identidad → verificar deudas → generar → entregar
 */
async function orchestrateCertificateGeneration(input, useMock = true) {
    const { studentId, certificateType, deliveryMethod, language = 'es' } = input;
    logger_1.logger.info(`Iniciando proceso de generación de certificado ${certificateType} para: ${studentId}`);
    try {
        // Paso 1: Verificar identidad del estudiante
        const profile = await verifyStudentIdentity(studentId, useMock);
        // Paso 2: Verificar deudas pendientes
        const debtStatus = await checkStudentDebts(studentId, useMock);
        if (debtStatus.hasDebts) {
            logger_1.logger.warn(`Generación bloqueada por deudas para: ${studentId}`);
            return {
                success: false,
                message: `Lo siento, ${profile.firstName}. Para generar tu certificado, necesitas estar al día con tus pagos. ${debtStatus.debtAmount ? `Tienes un saldo pendiente de $${debtStatus.debtAmount}.` : ''} Por favor, acércate a la oficina de tesorería o realiza el pago en línea.`,
                blockedReason: 'debts',
            };
        }
        // Paso 3: Generar el certificado
        const generateFn = useMock ? generate_certificate_1.generateCertificateMock : generate_certificate_1.generateCertificate;
        const certificateResult = await generateFn({
            studentId,
            certificateType,
            deliveryMethod,
            language,
        });
        // Paso 4: Confirmar entrega
        let confirmationMessage = `¡Perfecto, ${profile.firstName}! `;
        if (certificateResult.status === 'sent' && certificateResult.deliveryStatus) {
            confirmationMessage += `Tu certificado de ${getCertificateTypeName(certificateType)} ha sido generado y enviado a ${certificateResult.deliveryStatus.destination}. `;
            confirmationMessage += `Deberías recibirlo en los próximos minutos. `;
        }
        else if (certificateResult.downloadUrl) {
            confirmationMessage += `Tu certificado de ${getCertificateTypeName(certificateType)} ha sido generado. `;
            confirmationMessage += `Puedes descargarlo desde el siguiente enlace (válido por 24 horas): ${certificateResult.downloadUrl}`;
        }
        else {
            confirmationMessage += `Tu certificado de ${getCertificateTypeName(certificateType)} ha sido generado exitosamente. `;
        }
        confirmationMessage += `\n\nNúmero de certificado: ${certificateResult.certificateId}`;
        logger_1.logger.info(`Certificado generado exitosamente para: ${studentId}`);
        return {
            success: true,
            certificateResult,
            message: confirmationMessage,
        };
    }
    catch (error) {
        logger_1.logger.error(`Error en proceso de generación de certificado para ${studentId}:`, error);
        // Manejar error de deudas específicamente
        if (error instanceof errors_1.StudentHasDebtsError) {
            return {
                success: false,
                message: `Lo siento, para generar tu certificado necesitas estar al día con tus pagos. Tienes un saldo pendiente de $${error.metadata?.debtAmount || 0}. Por favor, acércate a la oficina de tesorería.`,
                blockedReason: 'debts',
            };
        }
        // Error genérico
        return {
            success: false,
            message: 'Lo siento, tuve un problema al generar tu certificado. Por favor, intenta de nuevo más tarde o contacta con la oficina de registro.',
            blockedReason: 'system_error',
        };
    }
}
/**
 * Obtiene el nombre legible del tipo de certificado
 */
function getCertificateTypeName(certificateType) {
    const names = {
        enrollment: 'inscripción',
        grades: 'calificaciones',
        graduation: 'graduación',
    };
    return names[certificateType] || certificateType;
}
/**
 * Genera mensaje de inicio del proceso
 */
function generateCertificateRequestMessage(profile, certificateType) {
    const typeName = getCertificateTypeName(certificateType);
    return `Perfecto, ${profile.firstName}. Voy a generar tu certificado de ${typeName}. Déjame verificar que todo esté en orden...`;
}
/**
 * Valida que el tipo de certificado sea válido
 */
function validateCertificateRequest(certificateType) {
    const validTypes = ['enrollment', 'grades', 'graduation'];
    if (!validTypes.includes(certificateType)) {
        return {
            valid: false,
            message: `El tipo de certificado "${certificateType}" no es válido. Los tipos disponibles son: inscripción, calificaciones y graduación.`,
        };
    }
    return {
        valid: true,
    };
}
//# sourceMappingURL=certificate-orchestrator.js.map