"use strict";
/**
 * Tests para academic-advisor
 */
Object.defineProperty(exports, "__esModule", { value: true });
const vitest_1 = require("vitest");
const academic_advisor_1 = require("./academic-advisor");
(0, vitest_1.describe)('AcademicAdvisor', () => {
    const goodRecord = {
        studentId: 'STU002',
        gpa: 3.8,
        totalCredits: 160,
        completedCredits: 120,
        academicStanding: 'good',
        courses: [
            {
                courseCode: 'ADM101',
                courseName: 'Administración',
                semester: '2023-1',
                grade: 'A',
                status: 'passed',
                credits: 3,
            },
        ],
        alerts: [],
    };
    const problematicRecord = {
        studentId: 'STU001',
        gpa: 2.8,
        totalCredits: 160,
        completedCredits: 80,
        academicStanding: 'warning',
        courses: [
            {
                courseCode: 'MAT101',
                courseName: 'Cálculo I',
                semester: '2023-1',
                grade: 'D',
                status: 'failed',
                credits: 4,
            },
            {
                courseCode: 'FIS101',
                courseName: 'Física I',
                semester: '2023-2',
                grade: 'F',
                status: 'failed',
                credits: 4,
            },
        ],
        alerts: [
            {
                type: 'failed_course',
                message: 'Tienes 2 materias reprobadas',
                severity: 'high',
            },
            {
                type: 'low_gpa',
                message: 'Tu GPA está por debajo del mínimo',
                severity: 'medium',
            },
        ],
    };
    (0, vitest_1.describe)('analyzeAcademicRecord', () => {
        (0, vitest_1.it)('debe detectar que no hay problemas en buen historial', () => {
            const analysis = (0, academic_advisor_1.analyzeAcademicRecord)(goodRecord);
            (0, vitest_1.expect)(analysis.hasIssues).toBe(false);
            (0, vitest_1.expect)(analysis.failedCourses.length).toBe(0);
            (0, vitest_1.expect)(analysis.lowGPA).toBe(false);
        });
        (0, vitest_1.it)('debe detectar materias reprobadas', () => {
            const analysis = (0, academic_advisor_1.analyzeAcademicRecord)(problematicRecord);
            (0, vitest_1.expect)(analysis.hasIssues).toBe(true);
            (0, vitest_1.expect)(analysis.failedCourses.length).toBe(2);
            (0, vitest_1.expect)(analysis.failedCourses[0].courseName).toBe('Cálculo I');
            (0, vitest_1.expect)(analysis.failedCourses[1].courseName).toBe('Física I');
        });
        (0, vitest_1.it)('debe detectar GPA bajo', () => {
            const analysis = (0, academic_advisor_1.analyzeAcademicRecord)(problematicRecord);
            (0, vitest_1.expect)(analysis.lowGPA).toBe(true);
            (0, vitest_1.expect)(analysis.gpaValue).toBe(2.8);
        });
        (0, vitest_1.it)('debe detectar materias en riesgo desde alertas', () => {
            const analysis = (0, academic_advisor_1.analyzeAcademicRecord)(problematicRecord);
            (0, vitest_1.expect)(analysis.coursesAtRisk.length).toBeGreaterThan(0);
        });
    });
    (0, vitest_1.describe)('generateTutoringRecommendation', () => {
        (0, vitest_1.it)('debe generar recomendación para una materia reprobada', () => {
            const failedCourses = [
                {
                    courseCode: 'MAT101',
                    courseName: 'Cálculo I',
                    semester: '2023-1',
                },
            ];
            const recommendation = (0, academic_advisor_1.generateTutoringRecommendation)(failedCourses);
            (0, vitest_1.expect)(recommendation).toContain('Cálculo I');
            (0, vitest_1.expect)(recommendation).toContain('tutoría');
            (0, vitest_1.expect)(recommendation).toContain('departamento');
        });
        (0, vitest_1.it)('debe generar recomendación para múltiples materias reprobadas', () => {
            const failedCourses = [
                {
                    courseCode: 'MAT101',
                    courseName: 'Cálculo I',
                    semester: '2023-1',
                },
                {
                    courseCode: 'FIS101',
                    courseName: 'Física I',
                    semester: '2023-2',
                },
            ];
            const recommendation = (0, academic_advisor_1.generateTutoringRecommendation)(failedCourses);
            (0, vitest_1.expect)(recommendation).toContain('2 materias');
            (0, vitest_1.expect)(recommendation).toContain('Cálculo I');
            (0, vitest_1.expect)(recommendation).toContain('Física I');
            (0, vitest_1.expect)(recommendation).toContain('plan de recuperación');
        });
        (0, vitest_1.it)('debe retornar string vacío si no hay materias reprobadas', () => {
            const recommendation = (0, academic_advisor_1.generateTutoringRecommendation)([]);
            (0, vitest_1.expect)(recommendation).toBe('');
        });
    });
    (0, vitest_1.describe)('generateResourceRecommendation', () => {
        (0, vitest_1.it)('debe generar recomendación de recursos', () => {
            const coursesAtRisk = [
                {
                    courseCode: 'MAT102',
                    courseName: 'Cálculo II',
                    alertType: 'at_risk',
                },
            ];
            const recommendation = (0, academic_advisor_1.generateResourceRecommendation)(coursesAtRisk);
            (0, vitest_1.expect)(recommendation).toContain('recursos');
            (0, vitest_1.expect)(recommendation).toContain('tutorías');
            (0, vitest_1.expect)(recommendation).toContain('técnicas de estudio');
        });
        (0, vitest_1.it)('debe retornar string vacío si no hay materias en riesgo', () => {
            const recommendation = (0, academic_advisor_1.generateResourceRecommendation)([]);
            (0, vitest_1.expect)(recommendation).toBe('');
        });
    });
    (0, vitest_1.describe)('generateSummerCoursesRecommendation', () => {
        (0, vitest_1.it)('debe generar recomendación de cursos de verano', () => {
            const failedCourses = [
                {
                    courseCode: 'MAT101',
                    courseName: 'Cálculo I',
                    semester: '2023-1',
                },
            ];
            const recommendation = (0, academic_advisor_1.generateSummerCoursesRecommendation)(failedCourses);
            (0, vitest_1.expect)(recommendation).toContain('cursos de verano');
            (0, vitest_1.expect)(recommendation).toContain('Cálculo I');
            (0, vitest_1.expect)(recommendation).toContain('horarios');
        });
        (0, vitest_1.it)('debe manejar múltiples materias', () => {
            const failedCourses = [
                {
                    courseCode: 'MAT101',
                    courseName: 'Cálculo I',
                    semester: '2023-1',
                },
                {
                    courseCode: 'FIS101',
                    courseName: 'Física I',
                    semester: '2023-2',
                },
            ];
            const recommendation = (0, academic_advisor_1.generateSummerCoursesRecommendation)(failedCourses);
            (0, vitest_1.expect)(recommendation).toContain('las materias');
        });
    });
    (0, vitest_1.describe)('generateGPAImprovementRecommendation', () => {
        (0, vitest_1.it)('debe generar recomendación para GPA bajo', () => {
            const recommendation = (0, academic_advisor_1.generateGPAImprovementRecommendation)(2.8);
            (0, vitest_1.expect)(recommendation).toContain('2.80');
            (0, vitest_1.expect)(recommendation).toContain('promedio académico');
            (0, vitest_1.expect)(recommendation).toContain('tutorías');
            (0, vitest_1.expect)(recommendation).toContain('asesor académico');
        });
        (0, vitest_1.it)('debe indicar nivel crítico para GPA muy bajo', () => {
            const recommendation = (0, academic_advisor_1.generateGPAImprovementRecommendation)(2.3);
            (0, vitest_1.expect)(recommendation).toContain('crítico');
        });
        (0, vitest_1.it)('debe retornar string vacío para GPA aceptable', () => {
            const recommendation = (0, academic_advisor_1.generateGPAImprovementRecommendation)(3.5);
            (0, vitest_1.expect)(recommendation).toBe('');
        });
    });
    (0, vitest_1.describe)('generateProactiveMessage', () => {
        (0, vitest_1.it)('debe generar mensaje positivo para buen rendimiento', () => {
            const analysis = (0, academic_advisor_1.analyzeAcademicRecord)(goodRecord);
            const message = (0, academic_advisor_1.generateProactiveMessage)(analysis);
            (0, vitest_1.expect)(message).toContain('Excelente');
            (0, vitest_1.expect)(message).toContain('buen estado');
        });
        (0, vitest_1.it)('debe generar mensaje completo para estudiante con problemas', () => {
            const analysis = (0, academic_advisor_1.analyzeAcademicRecord)(problematicRecord);
            const message = (0, academic_advisor_1.generateProactiveMessage)(analysis);
            (0, vitest_1.expect)(message).toContain('tutoría');
            (0, vitest_1.expect)(message).toContain('promedio académico');
            (0, vitest_1.expect)(message.length).toBeGreaterThan(100);
        });
        (0, vitest_1.it)('debe incluir múltiples recomendaciones', () => {
            const analysis = (0, academic_advisor_1.analyzeAcademicRecord)(problematicRecord);
            const message = (0, academic_advisor_1.generateProactiveMessage)(analysis);
            (0, vitest_1.expect)(message).toContain('tutoría');
            (0, vitest_1.expect)(message).toContain('cursos de verano');
        });
    });
    (0, vitest_1.describe)('analyzeImpediments', () => {
        (0, vitest_1.it)('debe detectar que no hay impedimentos en buen historial', () => {
            const analysis = (0, academic_advisor_1.analyzeImpediments)(goodRecord);
            (0, vitest_1.expect)(analysis.hasImpediments).toBe(false);
            (0, vitest_1.expect)(analysis.canProceed).toBe(true);
            (0, vitest_1.expect)(analysis.impediments.length).toBe(0);
        });
        (0, vitest_1.it)('debe detectar estado académico en probation', () => {
            const recordOnProbation = {
                ...goodRecord,
                academicStanding: 'probation',
            };
            const analysis = (0, academic_advisor_1.analyzeImpediments)(recordOnProbation);
            (0, vitest_1.expect)(analysis.hasImpediments).toBe(true);
            (0, vitest_1.expect)(analysis.canProceed).toBe(false);
            (0, vitest_1.expect)(analysis.impediments[0].type).toBe('academic');
            (0, vitest_1.expect)(analysis.impediments[0].severity).toBe('high');
        });
        (0, vitest_1.it)('debe detectar múltiples materias reprobadas como impedimento', () => {
            // Crear un record con más de 2 materias reprobadas para activar el impedimento
            const recordWithManyFailures = {
                ...problematicRecord,
                courses: [
                    {
                        courseCode: 'MAT101',
                        courseName: 'Cálculo I',
                        semester: '2023-1',
                        grade: 'F',
                        status: 'failed',
                        credits: 4,
                    },
                    {
                        courseCode: 'FIS101',
                        courseName: 'Física I',
                        semester: '2023-2',
                        grade: 'F',
                        status: 'failed',
                        credits: 4,
                    },
                    {
                        courseCode: 'QUI101',
                        courseName: 'Química I',
                        semester: '2024-1',
                        grade: 'F',
                        status: 'failed',
                        credits: 4,
                    },
                ],
            };
            const analysis = (0, academic_advisor_1.analyzeImpediments)(recordWithManyFailures);
            // Debe detectar impedimento por múltiples materias reprobadas (más de 2)
            (0, vitest_1.expect)(analysis.impediments.length).toBeGreaterThan(0);
            const academicImpediment = analysis.impediments.find((i) => i.type === 'academic');
            (0, vitest_1.expect)(academicImpediment).toBeDefined();
            (0, vitest_1.expect)(academicImpediment?.message).toContain('3 materias');
        });
        (0, vitest_1.it)('debe permitir proceder con impedimentos de severidad media', () => {
            const analysis = (0, academic_advisor_1.analyzeImpediments)(problematicRecord);
            // Si solo hay impedimentos de severidad media/baja, puede proceder
            const hasOnlyHighSeverity = analysis.impediments.every((i) => i.severity === 'high');
            if (!hasOnlyHighSeverity) {
                (0, vitest_1.expect)(analysis.canProceed).toBe(true);
            }
        });
    });
    (0, vitest_1.describe)('generateImpedimentMessage', () => {
        (0, vitest_1.it)('debe retornar string vacío si no hay impedimentos', () => {
            const analysis = (0, academic_advisor_1.analyzeImpediments)(goodRecord);
            const message = (0, academic_advisor_1.generateImpedimentMessage)(analysis);
            (0, vitest_1.expect)(message).toBe('');
        });
        (0, vitest_1.it)('debe generar mensaje de bloqueo para impedimentos críticos', () => {
            const recordOnProbation = {
                ...goodRecord,
                academicStanding: 'probation',
            };
            const analysis = (0, academic_advisor_1.analyzeImpediments)(recordOnProbation);
            const message = (0, academic_advisor_1.generateImpedimentMessage)(analysis);
            (0, vitest_1.expect)(message).toContain('impedimentos');
            (0, vitest_1.expect)(message).toContain('resolver');
            (0, vitest_1.expect)(message).toContain('oficina');
        });
        (0, vitest_1.it)('debe generar mensaje de advertencia para impedimentos no críticos', () => {
            const analysis = (0, academic_advisor_1.analyzeImpediments)(problematicRecord);
            // Forzar que pueda proceder
            analysis.canProceed = true;
            const message = (0, academic_advisor_1.generateImpedimentMessage)(analysis);
            if (analysis.hasImpediments) {
                (0, vitest_1.expect)(message).toContain('considerar');
                (0, vitest_1.expect)(message).toContain('continuar');
            }
        });
    });
});
//# sourceMappingURL=academic-advisor.test.js.map