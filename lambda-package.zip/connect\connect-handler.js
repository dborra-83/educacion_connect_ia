"use strict";
/**
 * Handler principal de Amazon Connect
 * Punto de entrada para eventos de Amazon Connect
 */
Object.defineProperty(exports, "__esModule", { value: true });
exports.HumanTransferManager = exports.handler = exports.ConnectHandler = void 0;
const reasoning_engine_1 = require("../agent/reasoning-engine");
const conversation_manager_1 = require("../agent/conversation-manager");
const error_handler_1 = require("../agent/error-handler");
const logger_1 = require("../utils/logger");
const metrics_publisher_1 = require("./metrics-publisher");
/**
 * Handler de Amazon Connect
 */
class ConnectHandler {
    reasoningEngine;
    constructor() {
        this.reasoningEngine = new reasoning_engine_1.ReasoningEngine();
    }
    /**
     * Procesa un evento de Amazon Connect
     */
    async handleEvent(event) {
        const startTime = Date.now();
        try {
            logger_1.logger.info('Evento de Amazon Connect recibido', {
                contactId: event.Details.ContactData.ContactId,
                channel: event.Details.ContactData.Channel,
            });
            // Obtener o crear contexto de conversación
            const sessionId = event.Details.ContactData.ContactId;
            const studentId = this.extractStudentId(event);
            const context = conversation_manager_1.ConversationManager.getOrCreateContext(sessionId, studentId);
            // Extraer mensaje del usuario
            const userMessage = this.extractUserMessage(event);
            // Procesar mensaje con el motor de razonamiento
            const response = await this.reasoningEngine.processMessage(userMessage, context);
            // Verificar si se requiere transferencia a agente humano
            if (response.requiresHumanEscalation) {
                const transferResult = await HumanTransferManager.initiateTransfer(event.Details.ContactData.ContactId, context, 'El agente requiere asistencia humana');
                // Agregar mensaje de transferencia a la respuesta
                response.message = HumanTransferManager.generateTransferMessage(transferResult);
                response.metadata = {
                    ...response.metadata,
                    transferId: transferResult.transferId,
                    queueName: transferResult.queueName,
                };
            }
            // Actualizar contexto con el nuevo mensaje
            conversation_manager_1.ConversationManager.updateContext(sessionId, {
                conversationHistory: [
                    ...context.conversationHistory,
                    {
                        role: 'user',
                        content: userMessage,
                        timestamp: new Date().toISOString(),
                    },
                    {
                        role: 'assistant',
                        content: response.message,
                        timestamp: new Date().toISOString(),
                    },
                ],
            });
            // Formatear respuesta para Amazon Connect
            const connectResponse = this.formatResponse(response);
            // Registrar interacción completa
            await this.logInteraction(event, userMessage, response, Date.now() - startTime, false);
            // Publicar métricas
            this.publishMetrics(response, Date.now() - startTime, false);
            logger_1.logger.info('Evento procesado exitosamente', {
                contactId: event.Details.ContactData.ContactId,
                processingTime: Date.now() - startTime,
            });
            return connectResponse;
        }
        catch (error) {
            logger_1.logger.error('Error procesando evento de Amazon Connect', {
                error,
                contactId: event.Details.ContactData.ContactId,
            });
            // Publicar métrica de error
            metrics_publisher_1.metricsPublisher.publishErrorRate(true, {
                ContactId: event.Details.ContactData.ContactId,
                Channel: event.Details.ContactData.Channel,
            });
            return this.handleError(error, event, Date.now() - startTime);
        }
    }
    /**
     * Extrae el studentId del evento de Amazon Connect
     */
    extractStudentId(event) {
        const attributes = event.Details.ContactData.Attributes;
        const parameters = event.Details.Parameters;
        return attributes.studentId || parameters.studentId;
    }
    /**
     * Extrae el mensaje del usuario del evento
     */
    extractUserMessage(event) {
        const parameters = event.Details.Parameters;
        return parameters.userMessage || parameters.inputText || parameters.text || '';
    }
    /**
     * Formatea la respuesta del agente para Amazon Connect
     */
    formatResponse(response) {
        const result = {
            message: response.message,
            requiresHumanEscalation: response.requiresHumanEscalation,
            metadata: response.metadata,
        };
        return {
            statusCode: 200,
            body: JSON.stringify(result),
            headers: {
                'Content-Type': 'application/json',
            },
        };
    }
    /**
     * Registra la interacción completa en CloudWatch
     * Cumple con requisito 9.2: Registro de interacciones
     */
    async logInteraction(event, userMessage, response, processingTime, errorOccurred) {
        const interactionLog = {
            contactId: event.Details.ContactData.ContactId,
            sessionId: event.Details.ContactData.ContactId,
            studentId: event.Details.ContactData.Attributes.studentId,
            channel: event.Details.ContactData.Channel,
            timestamp: new Date().toISOString(),
            userMessage,
            agentResponse: response.message,
            intent: response.metadata?.intent,
            toolsUsed: response.metadata?.toolsUsed || [],
            actionsExecuted: response.actions?.map((a) => a.type) || [],
            processingTime,
            requiresEscalation: response.requiresHumanEscalation,
            errorOccurred,
            metadata: {
                instanceARN: event.Details.ContactData.InstanceARN,
                initialContactId: event.Details.ContactData.InitialContactId,
                previousContactId: event.Details.ContactData.PreviousContactId,
            },
        };
        // Registrar en CloudWatch Logs con formato estructurado
        logger_1.logger.info('Interacción completa registrada', interactionLog);
        // En producción, aquí también se podría:
        // - Guardar en DynamoDB para análisis posterior
        // - Enviar a Kinesis para procesamiento en tiempo real
        // - Publicar métricas a CloudWatch Metrics
    }
    /**
     * Publica métricas de la interacción a CloudWatch
     * Cumple con requisito 9.4: Exposición de métricas
     */
    publishMetrics(response, processingTime, errorOccurred) {
        // Métrica de tiempo de respuesta
        metrics_publisher_1.metricsPublisher.publishResponseTime(processingTime);
        // Métrica de tasa de error
        metrics_publisher_1.metricsPublisher.publishErrorRate(errorOccurred);
        // Métrica de tasa de escalamiento
        metrics_publisher_1.metricsPublisher.publishEscalationRate(response.requiresHumanEscalation);
        // Métricas de uso de herramientas
        if (response.metadata?.toolsUsed) {
            response.metadata.toolsUsed.forEach((tool) => {
                metrics_publisher_1.metricsPublisher.publishToolUsage(tool);
            });
        }
        // Métrica de detección de intención
        if (response.metadata?.intent) {
            metrics_publisher_1.metricsPublisher.publishIntentDetection(response.metadata.intent, 0.8);
        }
    }
    /**
     * Maneja errores y genera respuesta apropiada
     */
    handleError(error, event, processingTime) {
        const errorResult = error_handler_1.ErrorHandler.handleError(error);
        const userMessage = error_handler_1.ErrorHandler.generateUserMessage(errorResult);
        // Registrar interacción con error
        this.logInteraction(event, this.extractUserMessage(event), {
            message: userMessage,
            requiresHumanEscalation: errorResult.requiresHumanEscalation,
            metadata: {
                toolsUsed: [],
                processingTime,
            },
        }, processingTime, true).catch((logError) => {
            logger_1.logger.error('Error al registrar interacción fallida', { logError });
        });
        const result = {
            message: userMessage,
            requiresHumanEscalation: errorResult.requiresHumanEscalation,
            metadata: {
                error: true,
                severity: errorResult.severity,
            },
        };
        return {
            statusCode: 200,
            body: JSON.stringify(result),
            headers: {
                'Content-Type': 'application/json',
            },
        };
    }
}
exports.ConnectHandler = ConnectHandler;
/**
 * Función Lambda handler para Amazon Connect
 */
const handler = async (event) => {
    const connectHandler = new ConnectHandler();
    return connectHandler.handleEvent(event);
};
exports.handler = handler;
/**
 * Gestor de transferencias a agentes humanos
 */
class HumanTransferManager {
    /**
     * Inicia una transferencia a un agente humano en Amazon Connect
     * Cumple con requisito 9.3: Transferencia a agente humano
     */
    static async initiateTransfer(contactId, context, reason) {
        logger_1.logger.info('Iniciando transferencia a agente humano', {
            contactId,
            sessionId: context.sessionId,
            studentId: context.studentId,
            reason,
        });
        // Preparar contexto para el agente humano
        const transferContext = this.prepareTransferContext(context, reason);
        // En producción, aquí se invocaría la API de Amazon Connect
        // para iniciar la transferencia a una cola de agentes humanos
        // Por ahora, retornamos un resultado simulado
        const result = {
            success: true,
            transferId: `TRANSFER-${Date.now()}`,
            queueName: this.selectQueue(reason),
            estimatedWaitTime: 120, // 2 minutos
            context: transferContext,
            timestamp: new Date().toISOString(),
        };
        logger_1.logger.info('Transferencia iniciada exitosamente', {
            contactId,
            transferId: result.transferId,
            queueName: result.queueName,
        });
        return result;
    }
    /**
     * Prepara el contexto de conversación para el agente humano
     */
    static prepareTransferContext(context, reason) {
        return {
            sessionId: context.sessionId,
            studentId: context.studentId,
            studentProfile: context.studentProfile
                ? {
                    name: `${context.studentProfile.firstName} ${context.studentProfile.lastName}`,
                    program: context.studentProfile.program,
                    email: context.studentProfile.email,
                }
                : undefined,
            conversationSummary: this.generateConversationSummary(context),
            transferReason: reason,
            lastIntent: context.currentIntent,
            timestamp: new Date().toISOString(),
        };
    }
    /**
     * Genera un resumen de la conversación para el agente humano
     */
    static generateConversationSummary(context) {
        const messageCount = context.conversationHistory.length;
        if (messageCount === 0) {
            return 'No hay mensajes previos en la conversación.';
        }
        // Tomar los últimos 5 mensajes para el resumen
        const recentMessages = context.conversationHistory.slice(-5);
        const summary = recentMessages
            .map((msg) => `${msg.role === 'user' ? 'Estudiante' : 'Agente'}: ${msg.content}`)
            .join('\n');
        return `Últimos ${recentMessages.length} mensajes:\n${summary}`;
    }
    /**
     * Selecciona la cola apropiada según el motivo de transferencia
     */
    static selectQueue(reason) {
        // Mapeo de razones a colas específicas
        const queueMap = {
            technical_error: 'TechnicalSupport',
            complex_query: 'AcademicAdvisors',
            financial_issue: 'FinancialAid',
            complaint: 'CustomerService',
            unknown: 'GeneralSupport',
        };
        // Detectar tipo de razón
        const lowerReason = reason.toLowerCase();
        if (lowerReason.includes('error') || lowerReason.includes('técnico')) {
            return queueMap.technical_error;
        }
        if (lowerReason.includes('académico') || lowerReason.includes('curso')) {
            return queueMap.complex_query;
        }
        if (lowerReason.includes('deuda') || lowerReason.includes('pago')) {
            return queueMap.financial_issue;
        }
        if (lowerReason.includes('queja') || lowerReason.includes('reclamo')) {
            return queueMap.complaint;
        }
        return queueMap.unknown;
    }
    /**
     * Genera mensaje de transferencia para el usuario
     */
    static generateTransferMessage(result) {
        const waitTimeMinutes = Math.ceil(result.estimatedWaitTime / 60);
        return (`Voy a transferirte con un agente humano que podrá ayudarte mejor. ` +
            `Te conectaré con el equipo de ${result.queueName}. ` +
            `El tiempo estimado de espera es de aproximadamente ${waitTimeMinutes} minuto${waitTimeMinutes > 1 ? 's' : ''}. ` +
            `He compartido el contexto de nuestra conversación con el agente para que pueda ayudarte más rápidamente.`);
    }
}
exports.HumanTransferManager = HumanTransferManager;
//# sourceMappingURL=connect-handler.js.map