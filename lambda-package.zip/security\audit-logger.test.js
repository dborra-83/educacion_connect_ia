"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const vitest_1 = require("vitest");
const audit_logger_1 = require("./audit-logger");
const logger_1 = require("../utils/logger");
vitest_1.vi.mock('../utils/logger');
(0, vitest_1.describe)('AuditLogger', () => {
    (0, vitest_1.beforeEach)(() => {
        vitest_1.vi.clearAllMocks();
    });
    (0, vitest_1.describe)('logAccess', () => {
        (0, vitest_1.it)('debe registrar acceso exitoso', async () => {
            await audit_logger_1.AuditLogger.logAccess({
                action: audit_logger_1.AuditAction.ACCESS_PROFILE,
                studentId: 'STU001',
                sessionId: 'session-123',
                resourceType: 'StudentProfile',
                resourceId: 'STU001',
                sensitivityLevel: audit_logger_1.SensitivityLevel.CONFIDENTIAL,
                success: true,
            });
            (0, vitest_1.expect)(logger_1.logger.info).toHaveBeenCalledWith('Registro de auditoría', vitest_1.expect.objectContaining({
                action: audit_logger_1.AuditAction.ACCESS_PROFILE,
                studentId: 'STU001',
                sessionId: 'session-123',
                success: true,
            }));
        });
        (0, vitest_1.it)('debe registrar acceso fallido con razón', async () => {
            await audit_logger_1.AuditLogger.logAccess({
                action: audit_logger_1.AuditAction.ACCESS_PROFILE,
                studentId: 'STU001',
                sessionId: 'session-123',
                resourceType: 'StudentProfile',
                sensitivityLevel: audit_logger_1.SensitivityLevel.CONFIDENTIAL,
                success: false,
                reason: 'Autenticación fallida',
            });
            (0, vitest_1.expect)(logger_1.logger.info).toHaveBeenCalledWith('Registro de auditoría', vitest_1.expect.objectContaining({
                success: false,
                reason: 'Autenticación fallida',
            }));
        });
        (0, vitest_1.it)('debe generar auditId único', async () => {
            await audit_logger_1.AuditLogger.logAccess({
                action: audit_logger_1.AuditAction.ACCESS_PROFILE,
                sessionId: 'session-123',
                resourceType: 'StudentProfile',
                sensitivityLevel: audit_logger_1.SensitivityLevel.CONFIDENTIAL,
                success: true,
            });
            const call = vitest_1.vi.mocked(logger_1.logger.info).mock.calls[0];
            const auditLog = call[1];
            (0, vitest_1.expect)(auditLog.auditId).toMatch(/^AUDIT-\d+-[a-z0-9]+$/);
        });
        (0, vitest_1.it)('debe incluir timestamp', async () => {
            await audit_logger_1.AuditLogger.logAccess({
                action: audit_logger_1.AuditAction.ACCESS_PROFILE,
                sessionId: 'session-123',
                resourceType: 'StudentProfile',
                sensitivityLevel: audit_logger_1.SensitivityLevel.CONFIDENTIAL,
                success: true,
            });
            const call = vitest_1.vi.mocked(logger_1.logger.info).mock.calls[0];
            const auditLog = call[1];
            (0, vitest_1.expect)(auditLog.timestamp).toBeDefined();
            (0, vitest_1.expect)(new Date(auditLog.timestamp).getTime()).toBeGreaterThan(0);
        });
    });
    (0, vitest_1.describe)('logProfileAccess', () => {
        (0, vitest_1.it)('debe registrar acceso a perfil', async () => {
            await audit_logger_1.AuditLogger.logProfileAccess('STU001', 'session-123', true);
            (0, vitest_1.expect)(logger_1.logger.info).toHaveBeenCalledWith('Registro de auditoría', vitest_1.expect.objectContaining({
                action: audit_logger_1.AuditAction.ACCESS_PROFILE,
                studentId: 'STU001',
                resourceType: 'StudentProfile',
                sensitivityLevel: audit_logger_1.SensitivityLevel.CONFIDENTIAL,
            }));
        });
    });
    (0, vitest_1.describe)('logAcademicRecordAccess', () => {
        (0, vitest_1.it)('debe registrar acceso a historial académico', async () => {
            await audit_logger_1.AuditLogger.logAcademicRecordAccess('STU001', 'session-123', true);
            (0, vitest_1.expect)(logger_1.logger.info).toHaveBeenCalledWith('Registro de auditoría', vitest_1.expect.objectContaining({
                action: audit_logger_1.AuditAction.ACCESS_ACADEMIC_RECORD,
                studentId: 'STU001',
                resourceType: 'AcademicRecord',
                sensitivityLevel: audit_logger_1.SensitivityLevel.CONFIDENTIAL,
            }));
        });
    });
    (0, vitest_1.describe)('logFinancialDataAccess', () => {
        (0, vitest_1.it)('debe registrar acceso a datos financieros', async () => {
            await audit_logger_1.AuditLogger.logFinancialDataAccess('STU001', 'session-123', true);
            (0, vitest_1.expect)(logger_1.logger.info).toHaveBeenCalledWith('Registro de auditoría', vitest_1.expect.objectContaining({
                action: audit_logger_1.AuditAction.ACCESS_FINANCIAL_DATA,
                studentId: 'STU001',
                resourceType: 'FinancialData',
                sensitivityLevel: audit_logger_1.SensitivityLevel.RESTRICTED,
            }));
        });
    });
    (0, vitest_1.describe)('logCertificateGeneration', () => {
        (0, vitest_1.it)('debe registrar generación de certificado', async () => {
            await audit_logger_1.AuditLogger.logCertificateGeneration('STU001', 'session-123', 'enrollment', true);
            (0, vitest_1.expect)(logger_1.logger.info).toHaveBeenCalledWith('Registro de auditoría', vitest_1.expect.objectContaining({
                action: audit_logger_1.AuditAction.GENERATE_CERTIFICATE,
                studentId: 'STU001',
                resourceType: 'Certificate',
                metadata: { certificateType: 'enrollment' },
            }));
        });
    });
    (0, vitest_1.describe)('logAuthenticationAttempt', () => {
        (0, vitest_1.it)('debe registrar autenticación exitosa', async () => {
            await audit_logger_1.AuditLogger.logAuthenticationAttempt('session-123', 'STU001', true);
            (0, vitest_1.expect)(logger_1.logger.info).toHaveBeenCalledWith('Registro de auditoría', vitest_1.expect.objectContaining({
                action: audit_logger_1.AuditAction.AUTHENTICATION_SUCCESS,
                studentId: 'STU001',
                success: true,
            }));
        });
        (0, vitest_1.it)('debe registrar autenticación fallida', async () => {
            await audit_logger_1.AuditLogger.logAuthenticationAttempt('session-123', 'STU001', false, 'Credenciales inválidas');
            (0, vitest_1.expect)(logger_1.logger.info).toHaveBeenCalledWith('Registro de auditoría', vitest_1.expect.objectContaining({
                action: audit_logger_1.AuditAction.AUTHENTICATION_FAILURE,
                success: false,
                reason: 'Credenciales inválidas',
            }));
        });
    });
    (0, vitest_1.describe)('logUnauthorizedAccessAttempt', () => {
        (0, vitest_1.it)('debe registrar intento de acceso no autorizado', async () => {
            await audit_logger_1.AuditLogger.logUnauthorizedAccessAttempt('session-123', 'STU001', 'STU002', 'StudentProfile');
            (0, vitest_1.expect)(logger_1.logger.info).toHaveBeenCalledWith('Registro de auditoría', vitest_1.expect.objectContaining({
                action: audit_logger_1.AuditAction.UNAUTHORIZED_ACCESS_ATTEMPT,
                success: false,
                metadata: {
                    authenticatedStudentId: 'STU001',
                    requestedStudentId: 'STU002',
                },
            }));
            (0, vitest_1.expect)(logger_1.logger.error).toHaveBeenCalledWith('Intento de acceso no autorizado detectado', vitest_1.expect.any(Object));
            (0, vitest_1.expect)(logger_1.logger.warn).toHaveBeenCalledWith('Acción de seguridad requerida', vitest_1.expect.objectContaining({
                action: 'SECURITY_ALERT',
                severity: 'HIGH',
            }));
        });
    });
});
//# sourceMappingURL=audit-logger.test.js.map