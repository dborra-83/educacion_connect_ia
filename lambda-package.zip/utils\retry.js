"use strict";
/**
 * Utilidad para reintentos con backoff exponencial
 * Implementa estrategia de reintento con delay exponencial: 1s, 2s, 4s
 */
Object.defineProperty(exports, "__esModule", { value: true });
exports.retryWithBackoff = retryWithBackoff;
exports.delay = delay;
async function retryWithBackoff(fn, maxRetries = 3, initialDelayMs = 1000) {
    let lastError;
    for (let attempt = 0; attempt <= maxRetries; attempt++) {
        try {
            return await fn();
        }
        catch (error) {
            lastError = error;
            // Si es el último intento, lanzar el error
            if (attempt === maxRetries) {
                throw lastError;
            }
            // Calcular delay con backoff exponencial
            const delayMs = initialDelayMs * Math.pow(2, attempt);
            // Esperar antes del siguiente intento
            await new Promise((resolve) => setTimeout(resolve, delayMs));
        }
    }
    throw lastError;
}
/**
 * Delay helper para testing y uso general
 */
function delay(ms) {
    return new Promise((resolve) => setTimeout(resolve, ms));
}
//# sourceMappingURL=retry.js.map