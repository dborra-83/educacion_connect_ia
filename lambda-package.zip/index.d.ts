/**
 * Punto de entrada principal para Lambda Handler de Amazon Connect
 */
/**
 * Lambda Handler para eventos de Amazon Connect
 * @param event Evento de Amazon Connect
 * @param context Contexto de Lambda
 */
export declare const handler: (event: any, context: any) => Promise<any>;
export { ConnectHandler } from './connect/connect-handler';
export { ReasoningEngine } from './agent/reasoning-engine';
export * from './types';
export * from './tools';
//# sourceMappingURL=index.d.ts.map