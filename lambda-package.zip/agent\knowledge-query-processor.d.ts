/**
 * Procesador de Consultas a Base de Conocimiento
 * Maneja consultas académicas y formatea respuestas con fuentes
 */
/**
 * Tipos de consulta académica
 */
export declare enum QueryType {
    PENSUM = "pensum",
    REQUISITOS = "requisitos",
    FECHAS = "fechas",
    ADMISION = "admision",
    PROGRAMA = "programa",
    GENERAL = "general"
}
/**
 * Resultado de consulta procesada
 */
export interface ProcessedQueryResult {
    queryType: QueryType;
    answer: string;
    sources: string[];
    hasResults: boolean;
}
/**
 * Procesador de consultas a base de conocimiento
 */
export declare class KnowledgeQueryProcessor {
    private useMock;
    constructor(useMock?: boolean);
    /**
     * Procesa una consulta académica
     */
    processQuery(query: string, programId?: string): Promise<ProcessedQueryResult>;
    /**
     * Detecta el tipo de consulta desde el mensaje del usuario
     */
    private detectQueryType;
    /**
     * Consulta la base de conocimiento con parámetros apropiados
     */
    private queryKnowledgeBase;
    /**
     * Formatea los resultados con excerpts y fuentes
     */
    private formatResults;
    /**
     * Genera introducción según el tipo de consulta
     */
    private generateIntroduction;
    /**
     * Genera mensaje cuando no hay resultados
     */
    private generateNoResultsMessage;
    /**
     * Extrae y formatea las fuentes de los resultados
     */
    private extractSources;
    /**
     * Genera respuesta con alternativas cuando no hay resultados
     */
    generateAlternatives(): string;
}
//# sourceMappingURL=knowledge-query-processor.d.ts.map