/**
 * Capa de Manejo de Errores
 * Traduce errores técnicos a mensajes amigables y genera alternativas
 */
import { MCPError } from '../types/errors';
/**
 * Severidad del error
 */
export declare enum ErrorSeverity {
    LOW = "low",
    MEDIUM = "medium",
    HIGH = "high",
    CRITICAL = "critical"
}
/**
 * Resultado del manejo de error
 */
export interface ErrorHandlingResult {
    userMessage: string;
    alternatives: string[];
    requiresHumanEscalation: boolean;
    severity: ErrorSeverity;
    canRetry: boolean;
}
/**
 * Traductor de errores técnicos a mensajes amigables
 */
export declare class ErrorTranslator {
    /**
     * Traduce un error técnico a un mensaje amigable para el usuario
     */
    static translateError(error: Error | MCPError): string;
    /**
     * Filtra información técnica del mensaje de error
     */
    static sanitizeErrorMessage(message: string): string;
}
/**
 * Generador de alternativas ante fallos
 */
export declare class AlternativeGenerator {
    /**
     * Genera alternativas según el tipo de error
     */
    static generateAlternatives(error: Error | MCPError): string[];
    /**
     * Genera sugerencia de contacto humano
     */
    static generateHumanContactSuggestion(error: Error | MCPError): string;
    /**
     * Genera sugerencia de reintento
     */
    static generateRetrySuggestion(error: Error | MCPError): string | null;
}
/**
 * Clasificador de severidad de errores
 */
export declare class ErrorSeverityClassifier {
    /**
     * Clasifica la severidad de un error
     */
    static classify(error: Error | MCPError): ErrorSeverity;
    /**
     * Determina si un error requiere escalamiento a humano
     */
    static requiresEscalation(error: Error | MCPError): boolean;
    /**
     * Determina si se puede reintentar la operación
     */
    static canRetry(error: Error | MCPError): boolean;
}
/**
 * Manejador principal de errores
 */
export declare class ErrorHandler {
    /**
     * Maneja un error y genera respuesta completa para el usuario
     */
    static handleError(error: Error | MCPError, context?: Record<string, any>): ErrorHandlingResult;
    /**
     * Registra el error en los logs
     */
    private static logError;
    /**
     * Genera mensaje completo para el usuario incluyendo alternativas
     */
    static generateUserMessage(result: ErrorHandlingResult): string;
}
//# sourceMappingURL=error-handler.d.ts.map