/**
 * Middleware de autenticación
 * Cumple con requisito 10.1: Autenticación antes de acceso a datos sensibles
 */
/**
 * Resultado de autenticación
 */
export interface AuthenticationResult {
    authenticated: boolean;
    studentId?: string;
    sessionId: string;
    reason?: string;
}
/**
 * Contexto de autenticación
 */
export interface AuthenticationContext {
    sessionId: string;
    studentId?: string;
    contactId: string;
    channel: string;
    instanceARN: string;
    attributes: Record<string, string>;
}
/**
 * Middleware de autenticación
 */
export declare class AuthenticationMiddleware {
    /**
     * Verifica la autenticación antes de acceder a datos sensibles
     */
    static authenticate(context: AuthenticationContext): Promise<AuthenticationResult>;
    /**
     * Valida que la sesión sea válida
     */
    private static validateSession;
    /**
     * Verifica la identidad del estudiante
     */
    private static verifyStudentIdentity;
    /**
     * Verifica si se requiere autenticación para una operación
     */
    static requiresAuthentication(operation: string): boolean;
    /**
     * Verifica permisos para acceder a datos de un estudiante
     */
    static verifyAccess(authenticatedStudentId: string, requestedStudentId: string): Promise<boolean>;
}
//# sourceMappingURL=authentication.d.ts.map