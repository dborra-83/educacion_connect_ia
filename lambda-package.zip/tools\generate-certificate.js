"use strict";
/**
 * Herramienta MCP: generateCertificate
 * Genera y envía certificados académicos
 * Integración con Lambda para generación de PDFs y envío
 */
Object.defineProperty(exports, "__esModule", { value: true });
exports.generateCertificate = generateCertificate;
exports.generateCertificateMock = generateCertificateMock;
exports.generateCertificateFailMock = generateCertificateFailMock;
exports.generateCertificateDeliveryFailMock = generateCertificateDeliveryFailMock;
const errors_1 = require("../types/errors");
const logger_1 = require("../utils/logger");
const VALID_CERTIFICATE_TYPES = ['enrollment', 'grades', 'graduation'];
/**
 * Valida el tipo de certificado
 */
function validateCertificateType(certificateType) {
    if (!VALID_CERTIFICATE_TYPES.includes(certificateType)) {
        throw new errors_1.InvalidCertificateTypeError(certificateType);
    }
}
/**
 * Valida el studentId
 */
function validateStudentId(studentId) {
    if (!studentId || studentId.trim().length === 0) {
        throw new errors_1.InvalidStudentIdError(studentId);
    }
}
/**
 * Verifica si el estudiante tiene deudas pendientes
 * En producción, esto consultaría el sistema financiero
 */
async function checkStudentDebts(studentId) {
    // Mock de verificación de deudas
    const studentsWithDebts = {
        STU003: 500,
        STU004: 1200,
    };
    return {
        hasDebts: studentId in studentsWithDebts,
        amount: studentsWithDebts[studentId],
    };
}
/**
 * Genera el certificado
 */
async function generateCertificate(input) {
    const { studentId, certificateType, deliveryMethod, language = 'es' } = input;
    // Validar entrada
    validateStudentId(studentId);
    validateCertificateType(certificateType);
    logger_1.logger.info(`Generando certificado ${certificateType} para estudiante: ${studentId}`);
    try {
        // Verificar deudas
        const debtStatus = await checkStudentDebts(studentId);
        if (debtStatus.hasDebts) {
            logger_1.logger.warn(`Estudiante ${studentId} tiene deudas pendientes: $${debtStatus.amount}`);
            throw new errors_1.StudentHasDebtsError(studentId, debtStatus.amount);
        }
        // En producción, aquí se invocaría Lambda para generar el PDF
        // Por ahora usamos mock
        const result = await generateCertificateMock(input);
        logger_1.logger.info(`Certificado generado exitosamente para: ${studentId}`);
        return result;
    }
    catch (error) {
        if (error instanceof errors_1.StudentHasDebtsError ||
            error instanceof errors_1.InvalidCertificateTypeError ||
            error instanceof errors_1.InvalidStudentIdError) {
            throw error;
        }
        logger_1.logger.error(`Error al generar certificado para ${studentId}:`, error);
        throw new errors_1.GenerationFailedError(error.message);
    }
}
/**
 * Mock para desarrollo/testing
 * Simula generación y entrega de certificados
 */
async function generateCertificateMock(input) {
    validateStudentId(input.studentId);
    validateCertificateType(input.certificateType);
    // Simular delay de generación
    await new Promise((resolve) => setTimeout(resolve, 200));
    const { studentId, certificateType, deliveryMethod, language = 'es' } = input;
    // Verificar deudas
    const debtStatus = await checkStudentDebts(studentId);
    if (debtStatus.hasDebts) {
        throw new errors_1.StudentHasDebtsError(studentId, debtStatus.amount);
    }
    // Simular generación exitosa
    const certificateId = `CERT-${Date.now()}-${studentId}`;
    const generatedAt = new Date().toISOString();
    const result = {
        certificateId,
        status: 'generated',
        generatedAt,
    };
    // Simular entrega según método
    if (deliveryMethod === 'email') {
        // Simular envío por email
        result.status = 'sent';
        result.deliveryStatus = {
            method: 'email',
            destination: `${studentId}@universidad.edu`,
            sentAt: new Date().toISOString(),
        };
    }
    else if (deliveryMethod === 'download') {
        // Simular URL de descarga
        result.downloadUrl = `https://certificates.universidad.edu/download/${certificateId}.pdf`;
        result.expiresAt = new Date(Date.now() + 24 * 60 * 60 * 1000).toISOString(); // 24 horas
    }
    return result;
}
/**
 * Mock que simula fallo en generación
 */
async function generateCertificateFailMock(input) {
    validateStudentId(input.studentId);
    validateCertificateType(input.certificateType);
    await new Promise((resolve) => setTimeout(resolve, 100));
    throw new errors_1.GenerationFailedError('Error al generar PDF: servicio de plantillas no disponible');
}
/**
 * Mock que simula fallo en entrega
 */
async function generateCertificateDeliveryFailMock(input) {
    validateStudentId(input.studentId);
    validateCertificateType(input.certificateType);
    await new Promise((resolve) => setTimeout(resolve, 100));
    const certificateId = `CERT-${Date.now()}-${input.studentId}`;
    // Certificado generado pero falla la entrega
    throw new errors_1.DeliveryFailedError('Servidor de correo no disponible', `${input.studentId}@universidad.edu`);
}
//# sourceMappingURL=generate-certificate.js.map