/**
 * Tests para Automatización de Trámites Administrativos
 */
export {};
//# sourceMappingURL=procedure-automation.test.d.ts.map