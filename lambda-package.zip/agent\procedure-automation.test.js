"use strict";
/**
 * Tests para Automatización de Trámites Administrativos
 */
var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __importStar = (this && this.__importStar) || (function () {
    var ownKeys = function(o) {
        ownKeys = Object.getOwnPropertyNames || function (o) {
            var ar = [];
            for (var k in o) if (Object.prototype.hasOwnProperty.call(o, k)) ar[ar.length] = k;
            return ar;
        };
        return ownKeys(o);
    };
    return function (mod) {
        if (mod && mod.__esModule) return mod;
        var result = {};
        if (mod != null) for (var k = ownKeys(mod), i = 0; i < k.length; i++) if (k[i] !== "default") __createBinding(result, mod, k[i]);
        __setModuleDefault(result, mod);
        return result;
    };
})();
Object.defineProperty(exports, "__esModule", { value: true });
const vitest_1 = require("vitest");
const procedure_automation_1 = require("./procedure-automation");
const checkAcademicRecordModule = __importStar(require("../tools/check-academic-record"));
const generateCertificateModule = __importStar(require("../tools/generate-certificate"));
// Mock de las herramientas
vitest_1.vi.mock('../tools/check-academic-record');
vitest_1.vi.mock('../tools/generate-certificate');
(0, vitest_1.describe)('ProcedureClassifier', () => {
    (0, vitest_1.describe)('classify', () => {
        (0, vitest_1.it)('debe clasificar solicitud de certificado de inscripción', () => {
            const result = procedure_automation_1.ProcedureClassifier.classify('Necesito un certificado de inscripción');
            (0, vitest_1.expect)(result.type).toBe(procedure_automation_1.ProcedureType.CERTIFICATE_REQUEST);
            (0, vitest_1.expect)(result.confidence).toBeGreaterThan(0.8);
            (0, vitest_1.expect)(result.parameters.certificateType).toBe('enrollment');
        });
        (0, vitest_1.it)('debe clasificar solicitud de certificado de calificaciones', () => {
            const result = procedure_automation_1.ProcedureClassifier.classify('Quiero solicitar un certificado de notas');
            (0, vitest_1.expect)(result.type).toBe(procedure_automation_1.ProcedureType.CERTIFICATE_REQUEST);
            (0, vitest_1.expect)(result.parameters.certificateType).toBe('grades');
        });
        (0, vitest_1.it)('debe clasificar solicitud de certificado de graduación', () => {
            const result = procedure_automation_1.ProcedureClassifier.classify('Necesito mi certificado de graduación');
            (0, vitest_1.expect)(result.type).toBe(procedure_automation_1.ProcedureType.CERTIFICATE_REQUEST);
            (0, vitest_1.expect)(result.parameters.certificateType).toBe('graduation');
        });
        (0, vitest_1.it)('debe clasificar solicitud de inscripción', () => {
            const result = procedure_automation_1.ProcedureClassifier.classify('Quiero inscribirme en el programa');
            (0, vitest_1.expect)(result.type).toBe(procedure_automation_1.ProcedureType.ENROLLMENT);
            (0, vitest_1.expect)(result.confidence).toBeGreaterThan(0.8);
        });
        (0, vitest_1.it)('debe clasificar registro de materias', () => {
            const result = procedure_automation_1.ProcedureClassifier.classify('Necesito registrar una materia');
            (0, vitest_1.expect)(result.type).toBe(procedure_automation_1.ProcedureType.COURSE_REGISTRATION);
            (0, vitest_1.expect)(result.confidence).toBeGreaterThan(0.8);
        });
        (0, vitest_1.it)('debe clasificar apelación de calificación', () => {
            const result = procedure_automation_1.ProcedureClassifier.classify('Quiero apelar mi calificación');
            (0, vitest_1.expect)(result.type).toBe(procedure_automation_1.ProcedureType.GRADE_APPEAL);
            (0, vitest_1.expect)(result.confidence).toBeGreaterThan(0.7);
        });
        (0, vitest_1.it)('debe clasificar cambio de programa', () => {
            const result = procedure_automation_1.ProcedureClassifier.classify('Quiero cambiar de carrera');
            (0, vitest_1.expect)(result.type).toBe(procedure_automation_1.ProcedureType.PROGRAM_CHANGE);
            (0, vitest_1.expect)(result.confidence).toBeGreaterThan(0.7);
        });
        (0, vitest_1.it)('debe clasificar retiro', () => {
            const result = procedure_automation_1.ProcedureClassifier.classify('Necesito retirar una materia');
            (0, vitest_1.expect)(result.type).toBe(procedure_automation_1.ProcedureType.WITHDRAWAL);
            (0, vitest_1.expect)(result.confidence).toBeGreaterThan(0.7);
        });
        (0, vitest_1.it)('debe retornar UNKNOWN para mensaje no reconocido', () => {
            const result = procedure_automation_1.ProcedureClassifier.classify('Hola, ¿cómo estás?');
            (0, vitest_1.expect)(result.type).toBe(procedure_automation_1.ProcedureType.UNKNOWN);
            (0, vitest_1.expect)(result.confidence).toBeLessThan(0.6);
        });
    });
});
(0, vitest_1.describe)('ProcedureValidator', () => {
    (0, vitest_1.beforeEach)(() => {
        vitest_1.vi.clearAllMocks();
    });
    (0, vitest_1.describe)('validate - CERTIFICATE_REQUEST', () => {
        (0, vitest_1.it)('debe validar exitosamente cuando no hay impedimentos', async () => {
            vitest_1.vi.spyOn(checkAcademicRecordModule, 'checkAcademicRecordMock').mockResolvedValue({
                studentId: 'S001',
                gpa: 3.5,
                totalCredits: 120,
                completedCredits: 90,
                academicStanding: 'good',
                alerts: [],
            });
            const result = await procedure_automation_1.ProcedureValidator.validate(procedure_automation_1.ProcedureType.CERTIFICATE_REQUEST, 'S001', {});
            (0, vitest_1.expect)(result.isValid).toBe(true);
            (0, vitest_1.expect)(result.impediments).toHaveLength(0);
        });
        (0, vitest_1.it)('debe invalidar cuando hay deudas pendientes', async () => {
            vitest_1.vi.spyOn(checkAcademicRecordModule, 'checkAcademicRecordMock').mockResolvedValue({
                studentId: 'S001',
                gpa: 3.5,
                totalCredits: 120,
                completedCredits: 90,
                academicStanding: 'good',
                alerts: [
                    {
                        type: 'missing_credits',
                        message: 'Tienes una deuda pendiente de $500',
                        severity: 'high',
                    },
                ],
            });
            const result = await procedure_automation_1.ProcedureValidator.validate(procedure_automation_1.ProcedureType.CERTIFICATE_REQUEST, 'S001', {});
            (0, vitest_1.expect)(result.isValid).toBe(false);
            (0, vitest_1.expect)(result.impediments).toContain('Tienes deudas pendientes que deben ser saldadas');
        });
        (0, vitest_1.it)('debe agregar advertencia cuando está en probation', async () => {
            vitest_1.vi.spyOn(checkAcademicRecordModule, 'checkAcademicRecordMock').mockResolvedValue({
                studentId: 'S001',
                gpa: 2.0,
                totalCredits: 120,
                completedCredits: 90,
                academicStanding: 'probation',
                alerts: [],
            });
            const result = await procedure_automation_1.ProcedureValidator.validate(procedure_automation_1.ProcedureType.CERTIFICATE_REQUEST, 'S001', {});
            (0, vitest_1.expect)(result.isValid).toBe(true);
            (0, vitest_1.expect)(result.warnings).toContain('Estás en período de prueba académica');
        });
    });
    (0, vitest_1.describe)('validate - ENROLLMENT', () => {
        (0, vitest_1.it)('debe invalidar cuando ya tiene materias activas', async () => {
            vitest_1.vi.spyOn(checkAcademicRecordModule, 'checkAcademicRecordMock').mockResolvedValue({
                studentId: 'S001',
                gpa: 3.5,
                totalCredits: 120,
                completedCredits: 90,
                academicStanding: 'good',
                courses: [
                    {
                        courseCode: 'CS101',
                        courseName: 'Intro to CS',
                        semester: '2024-1',
                        grade: 'A',
                        status: 'in_progress',
                        credits: 3,
                    },
                ],
            });
            const result = await procedure_automation_1.ProcedureValidator.validate(procedure_automation_1.ProcedureType.ENROLLMENT, 'S001', {});
            (0, vitest_1.expect)(result.isValid).toBe(false);
            (0, vitest_1.expect)(result.impediments).toContain('Ya tienes materias activas en el semestre actual');
        });
    });
    (0, vitest_1.describe)('validate - COURSE_REGISTRATION', () => {
        (0, vitest_1.it)('debe invalidar cuando alcanza límite de créditos', async () => {
            vitest_1.vi.spyOn(checkAcademicRecordModule, 'checkAcademicRecordMock').mockResolvedValue({
                studentId: 'S001',
                gpa: 3.5,
                totalCredits: 120,
                completedCredits: 90,
                academicStanding: 'good',
                courses: [
                    {
                        courseCode: 'CS101',
                        courseName: 'Intro to CS',
                        semester: '2024-1',
                        grade: 'A',
                        status: 'in_progress',
                        credits: 18,
                    },
                ],
            });
            const result = await procedure_automation_1.ProcedureValidator.validate(procedure_automation_1.ProcedureType.COURSE_REGISTRATION, 'S001', {});
            (0, vitest_1.expect)(result.isValid).toBe(false);
            (0, vitest_1.expect)(result.impediments[0]).toContain('límite de créditos');
        });
    });
    (0, vitest_1.describe)('validate - PROGRAM_CHANGE', () => {
        (0, vitest_1.it)('debe invalidar cuando GPA es menor al mínimo', async () => {
            vitest_1.vi.spyOn(checkAcademicRecordModule, 'checkAcademicRecordMock').mockResolvedValue({
                studentId: 'S001',
                gpa: 2.0,
                totalCredits: 120,
                completedCredits: 15,
                academicStanding: 'good',
            });
            const result = await procedure_automation_1.ProcedureValidator.validate(procedure_automation_1.ProcedureType.PROGRAM_CHANGE, 'S001', {});
            (0, vitest_1.expect)(result.isValid).toBe(false);
            (0, vitest_1.expect)(result.impediments[0]).toContain('GPA mínimo');
        });
        (0, vitest_1.it)('debe invalidar cuando no tiene suficientes créditos', async () => {
            vitest_1.vi.spyOn(checkAcademicRecordModule, 'checkAcademicRecordMock').mockResolvedValue({
                studentId: 'S001',
                gpa: 3.0,
                totalCredits: 120,
                completedCredits: 5,
                academicStanding: 'good',
            });
            const result = await procedure_automation_1.ProcedureValidator.validate(procedure_automation_1.ProcedureType.PROGRAM_CHANGE, 'S001', {});
            (0, vitest_1.expect)(result.isValid).toBe(false);
            (0, vitest_1.expect)(result.impediments[0]).toContain('créditos completados');
        });
    });
    (0, vitest_1.describe)('validate - WITHDRAWAL', () => {
        (0, vitest_1.it)('debe invalidar cuando no tiene materias activas', async () => {
            vitest_1.vi.spyOn(checkAcademicRecordModule, 'checkAcademicRecordMock').mockResolvedValue({
                studentId: 'S001',
                gpa: 3.5,
                totalCredits: 120,
                completedCredits: 90,
                academicStanding: 'good',
                courses: [],
            });
            const result = await procedure_automation_1.ProcedureValidator.validate(procedure_automation_1.ProcedureType.WITHDRAWAL, 'S001', {});
            (0, vitest_1.expect)(result.isValid).toBe(false);
            (0, vitest_1.expect)(result.missingRequirements).toContain('No tienes materias activas para retirar');
        });
        (0, vitest_1.it)('debe agregar advertencia sobre impacto', async () => {
            vitest_1.vi.spyOn(checkAcademicRecordModule, 'checkAcademicRecordMock').mockResolvedValue({
                studentId: 'S001',
                gpa: 3.5,
                totalCredits: 120,
                completedCredits: 90,
                academicStanding: 'good',
                courses: [
                    {
                        courseCode: 'CS101',
                        courseName: 'Intro to CS',
                        semester: '2024-1',
                        grade: 'A',
                        status: 'in_progress',
                        credits: 3,
                    },
                ],
            });
            const result = await procedure_automation_1.ProcedureValidator.validate(procedure_automation_1.ProcedureType.WITHDRAWAL, 'S001', {});
            (0, vitest_1.expect)(result.isValid).toBe(true);
            (0, vitest_1.expect)(result.warnings[0]).toContain('progreso académico');
        });
    });
});
(0, vitest_1.describe)('ProcedureExecutor', () => {
    (0, vitest_1.beforeEach)(() => {
        vitest_1.vi.clearAllMocks();
    });
    (0, vitest_1.describe)('execute - CERTIFICATE_REQUEST', () => {
        (0, vitest_1.it)('debe ejecutar exitosamente solicitud de certificado sin deudas', async () => {
            vitest_1.vi.spyOn(checkAcademicRecordModule, 'checkAcademicRecordMock').mockResolvedValue({
                studentId: 'S001',
                gpa: 3.5,
                totalCredits: 120,
                completedCredits: 90,
                academicStanding: 'good',
                alerts: [],
            });
            vitest_1.vi.spyOn(generateCertificateModule, 'generateCertificateMock').mockResolvedValue({
                certificateId: 'CERT-12345',
                status: 'sent',
                generatedAt: '2024-01-15T10:00:00Z',
                deliveryStatus: {
                    method: 'email',
                    destination: 'student@example.com',
                    sentAt: '2024-01-15T10:01:00Z',
                },
            });
            const result = await procedure_automation_1.ProcedureExecutor.execute(procedure_automation_1.ProcedureType.CERTIFICATE_REQUEST, 'S001', {
                certificateType: 'enrollment',
            });
            (0, vitest_1.expect)(result.success).toBe(true);
            (0, vitest_1.expect)(result.steps).toHaveLength(3);
            (0, vitest_1.expect)(result.steps[0].name).toBe('Verificación de identidad');
            (0, vitest_1.expect)(result.steps[1].name).toBe('Consulta de deudas pendientes');
            (0, vitest_1.expect)(result.steps[2].name).toBe('Generación de certificado');
            (0, vitest_1.expect)(result.steps.every((s) => s.status === 'completed')).toBe(true);
            (0, vitest_1.expect)(result.trackingId).toBe('CERT-12345');
            (0, vitest_1.expect)(result.finalMessage).toContain('certificado ha sido generado');
        });
        (0, vitest_1.it)('debe fallar cuando hay deudas pendientes', async () => {
            vitest_1.vi.spyOn(checkAcademicRecordModule, 'checkAcademicRecordMock').mockResolvedValue({
                studentId: 'S001',
                gpa: 3.5,
                totalCredits: 120,
                completedCredits: 90,
                academicStanding: 'good',
                alerts: [
                    {
                        type: 'missing_credits',
                        message: 'Tienes una deuda pendiente',
                        severity: 'high',
                    },
                ],
            });
            const result = await procedure_automation_1.ProcedureExecutor.execute(procedure_automation_1.ProcedureType.CERTIFICATE_REQUEST, 'S001', {
                certificateType: 'enrollment',
            });
            (0, vitest_1.expect)(result.success).toBe(false);
            (0, vitest_1.expect)(result.steps).toHaveLength(2);
            (0, vitest_1.expect)(result.finalMessage).toContain('deudas pendientes');
        });
        (0, vitest_1.it)('debe comunicar estado en cada paso', async () => {
            vitest_1.vi.spyOn(checkAcademicRecordModule, 'checkAcademicRecordMock').mockResolvedValue({
                studentId: 'S001',
                gpa: 3.5,
                totalCredits: 120,
                completedCredits: 90,
                academicStanding: 'good',
                alerts: [],
            });
            vitest_1.vi.spyOn(generateCertificateModule, 'generateCertificateMock').mockResolvedValue({
                certificateId: 'CERT-12345',
                status: 'sent',
                generatedAt: '2024-01-15T10:00:00Z',
            });
            const result = await procedure_automation_1.ProcedureExecutor.execute(procedure_automation_1.ProcedureType.CERTIFICATE_REQUEST, 'S001', {
                certificateType: 'enrollment',
            });
            // Verificar que cada paso tiene un nombre descriptivo
            (0, vitest_1.expect)(result.steps[0].name).toBeTruthy();
            (0, vitest_1.expect)(result.steps[1].name).toBeTruthy();
            (0, vitest_1.expect)(result.steps[2].name).toBeTruthy();
            // Verificar que cada paso tiene un número
            (0, vitest_1.expect)(result.steps[0].stepNumber).toBe(1);
            (0, vitest_1.expect)(result.steps[1].stepNumber).toBe(2);
            (0, vitest_1.expect)(result.steps[2].stepNumber).toBe(3);
        });
    });
    (0, vitest_1.describe)('execute - ENROLLMENT', () => {
        (0, vitest_1.it)('debe ejecutar inscripción con todos los pasos', async () => {
            const result = await procedure_automation_1.ProcedureExecutor.execute(procedure_automation_1.ProcedureType.ENROLLMENT, 'S001', {});
            (0, vitest_1.expect)(result.success).toBe(true);
            (0, vitest_1.expect)(result.steps).toHaveLength(3);
            (0, vitest_1.expect)(result.steps[0].name).toBe('Verificación de elegibilidad');
            (0, vitest_1.expect)(result.steps[1].name).toBe('Reserva de cupo');
            (0, vitest_1.expect)(result.steps[2].name).toBe('Generación de factura');
            (0, vitest_1.expect)(result.trackingId).toMatch(/^INS-/);
            (0, vitest_1.expect)(result.finalMessage).toContain('inscripción ha sido procesada');
        });
    });
    (0, vitest_1.describe)('execute - COURSE_REGISTRATION', () => {
        (0, vitest_1.it)('debe ejecutar registro de materia con todos los pasos', async () => {
            const result = await procedure_automation_1.ProcedureExecutor.execute(procedure_automation_1.ProcedureType.COURSE_REGISTRATION, 'S001', {});
            (0, vitest_1.expect)(result.success).toBe(true);
            (0, vitest_1.expect)(result.steps).toHaveLength(3);
            (0, vitest_1.expect)(result.steps[0].name).toBe('Verificación de disponibilidad de cupos');
            (0, vitest_1.expect)(result.steps[1].name).toBe('Verificación de prerrequisitos');
            (0, vitest_1.expect)(result.steps[2].name).toBe('Registro de materia');
            (0, vitest_1.expect)(result.trackingId).toMatch(/^REG-/);
        });
    });
    (0, vitest_1.describe)('execute - GRADE_APPEAL', () => {
        (0, vitest_1.it)('debe ejecutar apelación con todos los pasos', async () => {
            const result = await procedure_automation_1.ProcedureExecutor.execute(procedure_automation_1.ProcedureType.GRADE_APPEAL, 'S001', {});
            (0, vitest_1.expect)(result.success).toBe(true);
            (0, vitest_1.expect)(result.steps).toHaveLength(2);
            (0, vitest_1.expect)(result.steps[0].name).toBe('Creación de solicitud de apelación');
            (0, vitest_1.expect)(result.steps[1].name).toBe('Notificación al profesor');
            (0, vitest_1.expect)(result.trackingId).toMatch(/^APL-/);
            (0, vitest_1.expect)(result.finalMessage).toContain('apelación ha sido registrada');
        });
    });
    (0, vitest_1.describe)('execute - PROGRAM_CHANGE', () => {
        (0, vitest_1.it)('debe ejecutar cambio de programa con todos los pasos', async () => {
            const result = await procedure_automation_1.ProcedureExecutor.execute(procedure_automation_1.ProcedureType.PROGRAM_CHANGE, 'S001', {});
            (0, vitest_1.expect)(result.success).toBe(true);
            (0, vitest_1.expect)(result.steps).toHaveLength(3);
            (0, vitest_1.expect)(result.steps[0].name).toBe('Evaluación de elegibilidad');
            (0, vitest_1.expect)(result.steps[1].name).toBe('Creación de solicitud de cambio');
            (0, vitest_1.expect)(result.steps[2].name).toBe('Envío a comité académico');
            (0, vitest_1.expect)(result.trackingId).toMatch(/^CHG-/);
            (0, vitest_1.expect)(result.finalMessage).toContain('comité académico');
        });
    });
    (0, vitest_1.describe)('execute - WITHDRAWAL', () => {
        (0, vitest_1.it)('debe ejecutar retiro con todos los pasos', async () => {
            const result = await procedure_automation_1.ProcedureExecutor.execute(procedure_automation_1.ProcedureType.WITHDRAWAL, 'S001', {});
            (0, vitest_1.expect)(result.success).toBe(true);
            (0, vitest_1.expect)(result.steps).toHaveLength(3);
            (0, vitest_1.expect)(result.steps[0].name).toBe('Verificación de impacto financiero');
            (0, vitest_1.expect)(result.steps[1].name).toBe('Procesamiento de retiro');
            (0, vitest_1.expect)(result.steps[2].name).toBe('Actualización de registro académico');
            (0, vitest_1.expect)(result.trackingId).toMatch(/^WDR-/);
            (0, vitest_1.expect)(result.finalMessage).toContain('retiro ha sido procesado');
        });
    });
    (0, vitest_1.describe)('execute - Ejecución secuencial', () => {
        (0, vitest_1.it)('debe ejecutar pasos en orden secuencial', async () => {
            vitest_1.vi.spyOn(checkAcademicRecordModule, 'checkAcademicRecordMock').mockResolvedValue({
                studentId: 'S001',
                gpa: 3.5,
                totalCredits: 120,
                completedCredits: 90,
                academicStanding: 'good',
                alerts: [],
            });
            vitest_1.vi.spyOn(generateCertificateModule, 'generateCertificateMock').mockResolvedValue({
                certificateId: 'CERT-12345',
                status: 'sent',
                generatedAt: '2024-01-15T10:00:00Z',
            });
            const result = await procedure_automation_1.ProcedureExecutor.execute(procedure_automation_1.ProcedureType.CERTIFICATE_REQUEST, 'S001', {
                certificateType: 'enrollment',
            });
            // Verificar que los pasos están en orden
            (0, vitest_1.expect)(result.steps[0].stepNumber).toBe(1);
            (0, vitest_1.expect)(result.steps[1].stepNumber).toBe(2);
            (0, vitest_1.expect)(result.steps[2].stepNumber).toBe(3);
            // Verificar que todos se completaron
            (0, vitest_1.expect)(result.steps.every((s) => s.status === 'completed')).toBe(true);
        });
    });
    (0, vitest_1.describe)('execute - Tipo desconocido', () => {
        (0, vitest_1.it)('debe retornar mensaje de error para tipo no soportado', async () => {
            const result = await procedure_automation_1.ProcedureExecutor.execute(procedure_automation_1.ProcedureType.UNKNOWN, 'S001', {});
            (0, vitest_1.expect)(result.success).toBe(false);
            (0, vitest_1.expect)(result.finalMessage).toContain('no soportado');
        });
    });
});
//# sourceMappingURL=procedure-automation.test.js.map