/**
 * Handler principal de Amazon Connect
 * Punto de entrada para eventos de Amazon Connect
 */
import type { ConversationContext } from '../types/models';
/**
 * Evento de Amazon Connect
 */
export interface ConnectEvent {
    Details: {
        ContactData: {
            Attributes: Record<string, string>;
            ContactId: string;
            InitialContactId: string;
            Channel: string;
            InstanceARN: string;
            PreviousContactId?: string;
        };
        Parameters: Record<string, string>;
    };
    Name: string;
}
/**
 * Respuesta para Amazon Connect
 */
export interface ConnectResponse {
    statusCode: number;
    body: string;
    headers?: Record<string, string>;
}
/**
 * Handler de Amazon Connect
 */
export declare class ConnectHandler {
    private reasoningEngine;
    constructor();
    /**
     * Procesa un evento de Amazon Connect
     */
    handleEvent(event: ConnectEvent): Promise<ConnectResponse>;
    /**
     * Extrae el studentId del evento de Amazon Connect
     */
    private extractStudentId;
    /**
     * Extrae el mensaje del usuario del evento
     */
    private extractUserMessage;
    /**
     * Formatea la respuesta del agente para Amazon Connect
     */
    private formatResponse;
    /**
     * Registra la interacción completa en CloudWatch
     * Cumple con requisito 9.2: Registro de interacciones
     */
    private logInteraction;
    /**
     * Publica métricas de la interacción a CloudWatch
     * Cumple con requisito 9.4: Exposición de métricas
     */
    private publishMetrics;
    /**
     * Maneja errores y genera respuesta apropiada
     */
    private handleError;
}
/**
 * Función Lambda handler para Amazon Connect
 */
export declare const handler: (event: ConnectEvent) => Promise<ConnectResponse>;
/**
 * Gestor de transferencias a agentes humanos
 */
export declare class HumanTransferManager {
    /**
     * Inicia una transferencia a un agente humano en Amazon Connect
     * Cumple con requisito 9.3: Transferencia a agente humano
     */
    static initiateTransfer(contactId: string, context: ConversationContext, reason: string): Promise<TransferResult>;
    /**
     * Prepara el contexto de conversación para el agente humano
     */
    private static prepareTransferContext;
    /**
     * Genera un resumen de la conversación para el agente humano
     */
    private static generateConversationSummary;
    /**
     * Selecciona la cola apropiada según el motivo de transferencia
     */
    private static selectQueue;
    /**
     * Genera mensaje de transferencia para el usuario
     */
    static generateTransferMessage(result: TransferResult): string;
}
/**
 * Resultado de una transferencia
 */
export interface TransferResult {
    success: boolean;
    transferId: string;
    queueName: string;
    estimatedWaitTime: number;
    context: TransferContext;
    timestamp: string;
    error?: string;
}
/**
 * Contexto de transferencia para agente humano
 */
export interface TransferContext {
    sessionId: string;
    studentId?: string;
    studentProfile?: {
        name: string;
        program?: string | {
            name: string;
            code: string;
            enrollmentDate: string;
            programId?: string;
            level?: string;
        };
        email: string;
    };
    conversationSummary: string;
    transferReason: string;
    lastIntent?: string;
    timestamp: string;
}
//# sourceMappingURL=connect-handler.d.ts.map