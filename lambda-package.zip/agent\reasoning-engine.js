"use strict";
/**
 * Motor de Razonamiento del Agente
 * Implementa el ciclo completo: identificar intención → recuperar contexto → analizar → ejecutar → responder
 */
Object.defineProperty(exports, "__esModule", { value: true });
exports.ReasoningEngine = exports.IntentType = void 0;
const profile_manager_1 = require("./profile-manager");
const greeting_generator_1 = require("./greeting-generator");
const query_knowledge_base_1 = require("../tools/query-knowledge-base");
const check_academic_record_1 = require("../tools/check-academic-record");
const academic_advisor_1 = require("./academic-advisor");
const certificate_orchestrator_1 = require("./certificate-orchestrator");
const logger_1 = require("../utils/logger");
/**
 * Tipos de intención que el agente puede detectar
 */
var IntentType;
(function (IntentType) {
    IntentType["GREETING"] = "greeting";
    IntentType["REQUEST_CERTIFICATE"] = "request_certificate";
    IntentType["QUERY_PROGRAM"] = "query_program";
    IntentType["CHECK_ACADEMIC_STATUS"] = "check_academic_status";
    IntentType["REQUEST_HELP"] = "request_help";
    IntentType["UNKNOWN"] = "unknown";
})(IntentType || (exports.IntentType = IntentType = {}));
/**
 * Motor de razonamiento del agente
 */
class ReasoningEngine {
    useMock;
    constructor(useMock = true) {
        this.useMock = useMock;
    }
    /**
     * Procesa un mensaje del usuario y genera una respuesta
     * Implementa el ciclo completo de razonamiento
     */
    async processMessage(userMessage, context) {
        const startTime = Date.now();
        logger_1.logger.info(`Procesando mensaje: "${userMessage}"`);
        try {
            // 1. Identificar la intención del usuario
            const intentAnalysis = this.identifyIntent(userMessage, context);
            context.currentIntent = intentAnalysis.intent;
            logger_1.logger.info(`Intención detectada: ${intentAnalysis.intent} (${intentAnalysis.confidence})`);
            // 2. Recuperar contexto necesario (perfil si no está cacheado)
            if (!context.studentProfile && context.studentId) {
                await (0, profile_manager_1.retrieveStudentProfile)(context, this.useMock);
            }
            // 3. Analizar situación del estudiante
            const situationAnalysis = await this.analyzeSituation(context, intentAnalysis);
            // 4. Determinar y ejecutar acciones
            const actionResult = await this.executeActions(intentAnalysis, context, situationAnalysis);
            // 5. Generar respuesta personalizada
            const response = this.generateResponse(actionResult, context, intentAnalysis);
            // 6. Actualizar historial de conversación
            this.updateConversationHistory(context, userMessage, response.message);
            // 7. Calcular tiempo de procesamiento
            const processingTime = Date.now() - startTime;
            response.metadata = {
                ...response.metadata,
                processingTime,
            };
            logger_1.logger.info(`Mensaje procesado en ${processingTime}ms`);
            return response;
        }
        catch (error) {
            logger_1.logger.error('Error en motor de razonamiento:', error);
            return {
                message: 'Disculpa, tuve un problema al procesar tu solicitud. ¿Podrías intentar de nuevo?',
                requiresHumanEscalation: true,
                metadata: {
                    toolsUsed: [],
                    processingTime: Date.now() - startTime,
                },
            };
        }
    }
    /**
     * Identifica la intención del usuario desde su mensaje
     */
    identifyIntent(userMessage, context) {
        const messageLower = userMessage.toLowerCase();
        // Detectar saludo
        if (messageLower.match(/\b(hola|buenos días|buenas tardes|buenas noches|hey|saludos)\b/) &&
            context.conversationHistory.length === 0) {
            return {
                intent: IntentType.GREETING,
                confidence: 0.9,
                entities: {},
            };
        }
        // Detectar solicitud de certificado
        if (messageLower.match(/\b(certificado|constancia|documento|certificación|comprobante)\b/) &&
            (messageLower.includes('necesito') ||
                messageLower.includes('solicitar') ||
                messageLower.includes('quiero') ||
                messageLower.includes('generar'))) {
            // Extraer tipo de certificado
            let certificateType = 'enrollment'; // default
            if (messageLower.includes('calificacion') || messageLower.includes('notas')) {
                certificateType = 'grades';
            }
            else if (messageLower.includes('graduacion') || messageLower.includes('graduado')) {
                certificateType = 'graduation';
            }
            return {
                intent: IntentType.REQUEST_CERTIFICATE,
                confidence: 0.85,
                entities: { certificateType },
            };
        }
        // Detectar consulta sobre programa
        if (messageLower.match(/\b(programa|carrera|pensum|requisitos|inscripción|admisión)\b/) &&
            (messageLower.includes('cuál') ||
                messageLower.includes('qué') ||
                messageLower.includes('cómo') ||
                messageLower.includes('información'))) {
            return {
                intent: IntentType.QUERY_PROGRAM,
                confidence: 0.8,
                entities: { query: userMessage },
            };
        }
        // Detectar consulta de estado académico
        if (messageLower.match(/\b(calificaciones|notas|promedio|gpa|estado académico|materias)\b/) &&
            (messageLower.includes('mi') ||
                messageLower.includes('cómo') ||
                messageLower.includes('ver') ||
                messageLower.includes('consultar'))) {
            return {
                intent: IntentType.CHECK_ACADEMIC_STATUS,
                confidence: 0.85,
                entities: {},
            };
        }
        // Detectar solicitud de ayuda
        if (messageLower.match(/\b(ayuda|ayudar|puedes|necesito|apoyo|asistencia)\b/) ||
            messageLower.includes('?')) {
            return {
                intent: IntentType.REQUEST_HELP,
                confidence: 0.7,
                entities: {},
            };
        }
        // Intención desconocida
        return {
            intent: IntentType.UNKNOWN,
            confidence: 0.5,
            entities: {},
        };
    }
    /**
     * Analiza la situación del estudiante
     */
    async analyzeSituation(context, intentAnalysis) {
        const analysis = {
            hasProfile: !!context.studentProfile,
            needsAcademicCheck: false,
            academicAnalysis: null,
            impediments: null,
        };
        // Si la intención requiere verificar estado académico
        if (intentAnalysis.intent === IntentType.REQUEST_CERTIFICATE ||
            intentAnalysis.intent === IntentType.CHECK_ACADEMIC_STATUS) {
            analysis.needsAcademicCheck = true;
            if (context.studentId) {
                try {
                    const academicRecord = await (0, check_academic_record_1.checkAcademicRecordMock)({
                        studentId: context.studentId,
                        includeCourses: true,
                        includeGrades: true,
                    });
                    analysis.academicAnalysis = (0, academic_advisor_1.analyzeAcademicRecord)(academicRecord);
                    analysis.impediments = (0, academic_advisor_1.analyzeImpediments)(academicRecord);
                }
                catch (error) {
                    logger_1.logger.warn('No se pudo obtener historial académico:', error);
                }
            }
        }
        return analysis;
    }
    /**
     * Ejecuta las acciones necesarias según la intención
     */
    async executeActions(intentAnalysis, context, situationAnalysis) {
        const result = {
            intent: intentAnalysis.intent,
            success: true,
            data: null,
            toolsUsed: [],
        };
        switch (intentAnalysis.intent) {
            case IntentType.GREETING:
                // No requiere acciones adicionales
                result.toolsUsed.push('greeting-generator');
                break;
            case IntentType.REQUEST_CERTIFICATE:
                if (!context.studentId) {
                    result.success = false;
                    result.error = 'missing_student_id';
                    break;
                }
                result.toolsUsed.push('certificate-orchestrator');
                result.data = await (0, certificate_orchestrator_1.orchestrateCertificateGeneration)({
                    studentId: context.studentId,
                    certificateType: intentAnalysis.entities.certificateType || 'enrollment',
                    deliveryMethod: 'email',
                }, this.useMock);
                break;
            case IntentType.QUERY_PROGRAM:
                result.toolsUsed.push('query-knowledge-base');
                result.data = await (0, query_knowledge_base_1.queryKnowledgeBaseMock)({
                    query: intentAnalysis.entities.query || '',
                    maxResults: 3,
                });
                break;
            case IntentType.CHECK_ACADEMIC_STATUS:
                if (!context.studentId) {
                    result.success = false;
                    result.error = 'missing_student_id';
                    break;
                }
                result.toolsUsed.push('check-academic-record', 'academic-advisor');
                result.data = situationAnalysis.academicAnalysis;
                break;
            case IntentType.REQUEST_HELP:
            case IntentType.UNKNOWN:
                // Ofrecer ayuda general
                result.toolsUsed.push('help-generator');
                break;
        }
        return result;
    }
    /**
     * Genera la respuesta final para el usuario
     */
    generateResponse(actionResult, context, intentAnalysis) {
        let message = '';
        let requiresHumanEscalation = false;
        switch (intentAnalysis.intent) {
            case IntentType.GREETING:
                if (context.studentProfile) {
                    message = (0, greeting_generator_1.generateTimeBasedGreeting)(context.studentProfile);
                }
                else {
                    message = (0, greeting_generator_1.generateGreeting)(undefined);
                }
                break;
            case IntentType.REQUEST_CERTIFICATE:
                if (actionResult.success && actionResult.data) {
                    message = actionResult.data.message;
                }
                else if (actionResult.error === 'missing_student_id') {
                    message =
                        'Para generar tu certificado, necesito que me proporciones tu número de identificación de estudiante.';
                }
                else {
                    message =
                        'Lo siento, tuve un problema al procesar tu solicitud de certificado. ¿Podrías intentar de nuevo?';
                    requiresHumanEscalation = true;
                }
                break;
            case IntentType.QUERY_PROGRAM:
                if (actionResult.data && actionResult.data.results.length > 0) {
                    message = 'Encontré la siguiente información:\n\n';
                    actionResult.data.results.forEach((result, index) => {
                        message += `${index + 1}. **${result.title}**\n${result.excerpt}\n\n`;
                    });
                    message += '¿Necesitas más información sobre alguno de estos temas?';
                }
                else {
                    message =
                        'No encontré información específica sobre tu consulta. ¿Podrías reformular tu pregunta o contactar con la oficina de admisiones?';
                }
                break;
            case IntentType.CHECK_ACADEMIC_STATUS:
                if (actionResult.success && actionResult.data) {
                    const profile = context.studentProfile;
                    message = `Hola ${profile?.firstName}. `;
                    if (actionResult.data.hasIssues) {
                        message += (0, academic_advisor_1.generateProactiveMessage)(actionResult.data);
                    }
                    else {
                        message += `Tu rendimiento académico está excelente. Tienes un promedio de ${actionResult.data.gpaValue.toFixed(2)} y has completado ${actionResult.data.failedCourses.length === 0 ? 'todas tus materias' : 'la mayoría de tus materias'} exitosamente. ¡Sigue así!`;
                    }
                }
                else if (actionResult.error === 'missing_student_id') {
                    message =
                        'Para consultar tu estado académico, necesito que me proporciones tu número de identificación de estudiante.';
                }
                else {
                    message =
                        'Lo siento, no pude acceder a tu información académica en este momento. Por favor, intenta más tarde.';
                }
                break;
            case IntentType.REQUEST_HELP:
                message = this.generateHelpMessage(context);
                break;
            case IntentType.UNKNOWN:
                message =
                    'No estoy seguro de entender tu solicitud. Puedo ayudarte con:\n\n' +
                        '- Generar certificados académicos\n' +
                        '- Consultar información sobre programas\n' +
                        '- Revisar tu estado académico\n' +
                        '- Responder preguntas sobre admisiones\n\n' +
                        '¿Con cuál de estos temas te gustaría ayuda?';
                break;
        }
        return {
            message,
            requiresHumanEscalation,
            metadata: {
                toolsUsed: actionResult.toolsUsed || [],
                processingTime: 0, // Se actualizará después
            },
        };
    }
    /**
     * Genera mensaje de ayuda general
     */
    generateHelpMessage(context) {
        const profile = context.studentProfile;
        const greeting = profile ? `Hola ${profile.firstName}` : 'Hola';
        return (`${greeting}. Estoy aquí para ayudarte. Puedo asistirte con:\n\n` +
            '📄 **Certificados**: Puedo generar certificados de inscripción, calificaciones o graduación\n' +
            '📚 **Información Académica**: Consulta sobre programas, requisitos y fechas de inscripción\n' +
            '📊 **Estado Académico**: Revisa tus calificaciones y recibe recomendaciones personalizadas\n' +
            '❓ **Preguntas Generales**: Respondo dudas sobre trámites y procedimientos\n\n' +
            '¿En qué puedo ayudarte hoy?');
    }
    /**
     * Actualiza el historial de conversación
     */
    updateConversationHistory(context, userMessage, assistantMessage) {
        const timestamp = new Date().toISOString();
        context.conversationHistory.push({
            role: 'user',
            content: userMessage,
            timestamp,
        });
        context.conversationHistory.push({
            role: 'assistant',
            content: assistantMessage,
            timestamp,
        });
        // Limitar historial a últimos 20 mensajes
        if (context.conversationHistory.length > 20) {
            context.conversationHistory = context.conversationHistory.slice(-20);
        }
    }
}
exports.ReasoningEngine = ReasoningEngine;
//# sourceMappingURL=reasoning-engine.js.map