"use strict";
/**
 * Punto de entrada principal para Lambda Handler de Amazon Connect
 */
var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __exportStar = (this && this.__exportStar) || function(m, exports) {
    for (var p in m) if (p !== "default" && !Object.prototype.hasOwnProperty.call(exports, p)) __createBinding(exports, m, p);
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.ReasoningEngine = exports.ConnectHandler = exports.handler = void 0;
const connect_handler_1 = require("./connect/connect-handler");
const connectHandler = new connect_handler_1.ConnectHandler();
/**
 * Lambda Handler para eventos de Amazon Connect
 * @param event Evento de Amazon Connect
 * @param context Contexto de Lambda
 */
const handler = async (event, context) => {
    console.log('Lambda Handler - Event:', JSON.stringify(event));
    console.log('Lambda Handler - Context:', JSON.stringify(context));
    try {
        // Si el evento ya tiene la estructura de Amazon Connect, usarlo directamente
        if (event.Details?.ContactData) {
            return await connectHandler.handleEvent(event);
        }
        // Si no, construir evento de Amazon Connect desde parámetros simples
        const connectEvent = {
            Details: {
                ContactData: {
                    Attributes: {
                        studentId: event.studentId || '',
                        ...event.attributes
                    },
                    ContactId: event.contactId || event.sessionId || context.awsRequestId,
                    InitialContactId: event.contactId || event.sessionId || context.awsRequestId,
                    Channel: event.channel || 'VOICE',
                    InstanceARN: process.env.CONNECT_INSTANCE_ARN || 'arn:aws:connect:us-east-1:520754296204:instance/983955e0-57a9-4633-aad0-f87f18072f04'
                },
                Parameters: {
                    message: event.message || '',
                    ...event.parameters
                }
            },
            Name: 'ContactFlowEvent'
        };
        // Procesar con ConnectHandler
        const response = await connectHandler.handleEvent(connectEvent);
        return response;
    }
    catch (error) {
        console.error('Error en Lambda Handler:', error);
        return {
            statusCode: 500,
            body: JSON.stringify({
                error: 'InternalError',
                message: 'Error al procesar la solicitud'
            })
        };
    }
};
exports.handler = handler;
// Exportar para uso local/testing
var connect_handler_2 = require("./connect/connect-handler");
Object.defineProperty(exports, "ConnectHandler", { enumerable: true, get: function () { return connect_handler_2.ConnectHandler; } });
var reasoning_engine_1 = require("./agent/reasoning-engine");
Object.defineProperty(exports, "ReasoningEngine", { enumerable: true, get: function () { return reasoning_engine_1.ReasoningEngine; } });
__exportStar(require("./types"), exports);
__exportStar(require("./tools"), exports);
//# sourceMappingURL=index.js.map