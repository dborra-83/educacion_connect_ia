"use strict";
/**
 * Tests para queryKnowledgeBase
 */
Object.defineProperty(exports, "__esModule", { value: true });
const vitest_1 = require("vitest");
const query_knowledge_base_1 = require("./query-knowledge-base");
const errors_1 = require("../types/errors");
(0, vitest_1.describe)('queryKnowledgeBase', () => {
    (0, vitest_1.describe)('Casos de éxito', () => {
        (0, vitest_1.it)('debe retornar resultados para consulta sobre pensum', async () => {
            const result = await (0, query_knowledge_base_1.queryKnowledgeBaseMock)({
                query: '¿Cuál es el pensum de Ingeniería Informática?',
            });
            (0, vitest_1.expect)(result).toBeDefined();
            (0, vitest_1.expect)(result.totalResults).toBeGreaterThan(0);
            (0, vitest_1.expect)(result.results).toHaveLength(result.totalResults);
            (0, vitest_1.expect)(result.results[0].title).toContain('Ingeniería Informática');
        });
        (0, vitest_1.it)('debe retornar resultados para consulta sobre requisitos', async () => {
            const result = await (0, query_knowledge_base_1.queryKnowledgeBaseMock)({
                query: 'requisitos de admisión',
            });
            (0, vitest_1.expect)(result.totalResults).toBeGreaterThan(0);
            (0, vitest_1.expect)(result.results[0].documentType).toBe('requirements');
        });
        (0, vitest_1.it)('debe retornar resultados para consulta sobre fechas', async () => {
            const result = await (0, query_knowledge_base_1.queryKnowledgeBaseMock)({
                query: 'fechas de inscripción',
            });
            (0, vitest_1.expect)(result.totalResults).toBeGreaterThan(0);
            (0, vitest_1.expect)(result.results[0].excerpt).toContain('inscripciones');
        });
        (0, vitest_1.it)('debe limitar resultados según maxResults', async () => {
            const result = await (0, query_knowledge_base_1.queryKnowledgeBaseMock)({
                query: 'programa',
                maxResults: 2,
            });
            (0, vitest_1.expect)(result.results.length).toBeLessThanOrEqual(2);
        });
        (0, vitest_1.it)('debe filtrar por tipo de documento', async () => {
            const result = await (0, query_knowledge_base_1.queryKnowledgeBaseMock)({
                query: 'programa',
                filters: {
                    documentType: ['program_info'],
                },
            });
            (0, vitest_1.expect)(result.totalResults).toBeGreaterThan(0);
            result.results.forEach((doc) => {
                (0, vitest_1.expect)(doc.documentType).toBe('program_info');
            });
        });
    });
    (0, vitest_1.describe)('Casos de error', () => {
        (0, vitest_1.it)('debe lanzar EmptyQueryError cuando la consulta está vacía', async () => {
            await (0, vitest_1.expect)((0, query_knowledge_base_1.queryKnowledgeBaseMock)({
                query: '',
            })).rejects.toThrow(errors_1.EmptyQueryError);
        });
        (0, vitest_1.it)('debe lanzar EmptyQueryError cuando la consulta es solo espacios', async () => {
            await (0, vitest_1.expect)((0, query_knowledge_base_1.queryKnowledgeBaseMock)({
                query: '   ',
            })).rejects.toThrow(errors_1.EmptyQueryError);
        });
        (0, vitest_1.it)('debe lanzar NoResultsFoundError cuando no hay coincidencias', async () => {
            await (0, vitest_1.expect)((0, query_knowledge_base_1.queryKnowledgeBaseMock)({
                query: 'xyz123abc456def789',
            })).rejects.toThrow(errors_1.NoResultsFoundError);
        });
    });
    (0, vitest_1.describe)('Validación de resultados', () => {
        (0, vitest_1.it)('debe incluir todos los campos requeridos en cada resultado', async () => {
            const result = await (0, query_knowledge_base_1.queryKnowledgeBaseMock)({
                query: 'ingeniería',
            });
            result.results.forEach((doc) => {
                (0, vitest_1.expect)(doc.title).toBeTruthy();
                (0, vitest_1.expect)(doc.excerpt).toBeTruthy();
                (0, vitest_1.expect)(doc.relevanceScore).toBeGreaterThan(0);
                (0, vitest_1.expect)(doc.relevanceScore).toBeLessThanOrEqual(1);
                (0, vitest_1.expect)(doc.source).toBeTruthy();
                (0, vitest_1.expect)(doc.documentType).toBeTruthy();
            });
        });
        (0, vitest_1.it)('debe ordenar resultados por relevancia descendente', async () => {
            const result = await (0, query_knowledge_base_1.queryKnowledgeBaseMock)({
                query: 'programa',
            });
            for (let i = 1; i < result.results.length; i++) {
                (0, vitest_1.expect)(result.results[i - 1].relevanceScore).toBeGreaterThanOrEqual(result.results[i].relevanceScore);
            }
        });
        (0, vitest_1.it)('debe incluir fuente del documento', async () => {
            const result = await (0, query_knowledge_base_1.queryKnowledgeBaseMock)({
                query: 'certificado',
            });
            (0, vitest_1.expect)(result.results[0].source).toMatch(/^s3:\/\//);
        });
    });
});
//# sourceMappingURL=query-knowledge-base.test.js.map