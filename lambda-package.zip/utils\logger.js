"use strict";
/**
 * Sistema de logging con niveles y formato estructurado
 * Preparado para integración con CloudWatch Logs
 */
Object.defineProperty(exports, "__esModule", { value: true });
exports.logger = exports.LogLevel = void 0;
var LogLevel;
(function (LogLevel) {
    LogLevel["DEBUG"] = "DEBUG";
    LogLevel["INFO"] = "INFO";
    LogLevel["WARN"] = "WARN";
    LogLevel["ERROR"] = "ERROR";
})(LogLevel || (exports.LogLevel = LogLevel = {}));
class Logger {
    formatLogEntry(level, message, data) {
        return {
            level,
            timestamp: new Date().toISOString(),
            message,
            ...(data && { data }),
        };
    }
    log(level, message, ...args) {
        const entry = this.formatLogEntry(level, message, args.length > 0 ? args : undefined);
        // En desarrollo, usar console
        // En producción, esto se enviará a CloudWatch Logs
        switch (level) {
            case LogLevel.ERROR:
                console.error(JSON.stringify(entry, null, 2));
                break;
            case LogLevel.WARN:
                console.warn(JSON.stringify(entry, null, 2));
                break;
            case LogLevel.INFO:
                console.info(JSON.stringify(entry, null, 2));
                break;
            case LogLevel.DEBUG:
                console.debug(JSON.stringify(entry, null, 2));
                break;
        }
    }
    error(message, ...args) {
        this.log(LogLevel.ERROR, message, ...args);
    }
    warn(message, ...args) {
        this.log(LogLevel.WARN, message, ...args);
    }
    info(message, ...args) {
        this.log(LogLevel.INFO, message, ...args);
    }
    debug(message, ...args) {
        this.log(LogLevel.DEBUG, message, ...args);
    }
}
exports.logger = new Logger();
//# sourceMappingURL=logger.js.map