/**
 * Tests para generateCertificate
 */
export {};
//# sourceMappingURL=generate-certificate.test.d.ts.map