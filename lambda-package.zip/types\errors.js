"use strict";
/**
 * Jerarquía de errores personalizados del sistema
 */
Object.defineProperty(exports, "__esModule", { value: true });
exports.ForbiddenAccessError = exports.UnauthorizedAccessError = exports.TimeoutError = exports.ServiceUnavailableError = exports.DeliveryFailedError = exports.GenerationFailedError = exports.InvalidCertificateTypeError = exports.StudentHasDebtsError = exports.NoResultsFoundError = exports.EmptyQueryError = exports.InvalidStudentIdError = exports.StudentNotFoundError = exports.MCPError = void 0;
exports.createErrorResponse = createErrorResponse;
// ============================================================================
// Error Base
// ============================================================================
class MCPError extends Error {
    code;
    statusCode;
    metadata;
    constructor(message, code, statusCode = 500, metadata) {
        super(message);
        this.code = code;
        this.statusCode = statusCode;
        this.metadata = metadata;
        this.name = this.constructor.name;
        Error.captureStackTrace(this, this.constructor);
    }
}
exports.MCPError = MCPError;
// ============================================================================
// Errores de getStudentProfile
// ============================================================================
class StudentNotFoundError extends MCPError {
    constructor(studentId) {
        super(`Estudiante con ID ${studentId} no encontrado`, 'STUDENT_NOT_FOUND', 404, { studentId });
    }
}
exports.StudentNotFoundError = StudentNotFoundError;
class InvalidStudentIdError extends MCPError {
    constructor(studentId) {
        super(`ID de estudiante inválido: ${studentId}`, 'INVALID_STUDENT_ID', 400, { studentId });
    }
}
exports.InvalidStudentIdError = InvalidStudentIdError;
// ============================================================================
// Errores de queryKnowledgeBase
// ============================================================================
class EmptyQueryError extends MCPError {
    constructor() {
        super('La consulta no puede estar vacía', 'EMPTY_QUERY', 400);
    }
}
exports.EmptyQueryError = EmptyQueryError;
class NoResultsFoundError extends MCPError {
    constructor(query) {
        super(`No se encontraron resultados para: ${query}`, 'NO_RESULTS_FOUND', 404, { query });
    }
}
exports.NoResultsFoundError = NoResultsFoundError;
// ============================================================================
// Errores de generateCertificate
// ============================================================================
class StudentHasDebtsError extends MCPError {
    constructor(studentId, debtAmount) {
        super(`El estudiante ${studentId} tiene deudas pendientes de $${debtAmount}`, 'STUDENT_HAS_DEBTS', 403, { studentId, debtAmount });
    }
}
exports.StudentHasDebtsError = StudentHasDebtsError;
class InvalidCertificateTypeError extends MCPError {
    constructor(certificateType) {
        super(`Tipo de certificado inválido: ${certificateType}`, 'INVALID_CERTIFICATE_TYPE', 400, {
            certificateType,
        });
    }
}
exports.InvalidCertificateTypeError = InvalidCertificateTypeError;
class GenerationFailedError extends MCPError {
    constructor(reason) {
        super(`Error al generar el certificado: ${reason}`, 'GENERATION_FAILED', 500, { reason });
    }
}
exports.GenerationFailedError = GenerationFailedError;
class DeliveryFailedError extends MCPError {
    constructor(reason, destination) {
        super(`Error al entregar el certificado a ${destination}: ${reason}`, 'DELIVERY_FAILED', 500, {
            reason,
            destination,
        });
    }
}
exports.DeliveryFailedError = DeliveryFailedError;
// ============================================================================
// Errores de Servicios
// ============================================================================
class ServiceUnavailableError extends MCPError {
    constructor(serviceName) {
        super(`El servicio ${serviceName} no está disponible temporalmente`, 'SERVICE_UNAVAILABLE', 503, { serviceName });
    }
}
exports.ServiceUnavailableError = ServiceUnavailableError;
class TimeoutError extends MCPError {
    constructor(operation, timeoutMs) {
        super(`La operación ${operation} excedió el tiempo límite de ${timeoutMs}ms`, 'TIMEOUT', 504, {
            operation,
            timeoutMs,
        });
    }
}
exports.TimeoutError = TimeoutError;
// ============================================================================
// Errores de Autenticación y Autorización
// ============================================================================
class UnauthorizedAccessError extends MCPError {
    constructor(resource) {
        super(`Acceso no autorizado al recurso: ${resource}`, 'UNAUTHORIZED_ACCESS', 401, {
            resource,
        });
    }
}
exports.UnauthorizedAccessError = UnauthorizedAccessError;
class ForbiddenAccessError extends MCPError {
    constructor(resource, reason) {
        super(`Acceso prohibido a ${resource}: ${reason}`, 'FORBIDDEN_ACCESS', 403, {
            resource,
            reason,
        });
    }
}
exports.ForbiddenAccessError = ForbiddenAccessError;
// ============================================================================
// Helper para crear ErrorResponse
// ============================================================================
function createErrorResponse(error, requestId) {
    return {
        error: {
            code: error.code,
            message: error.message,
            statusCode: error.statusCode,
            metadata: {
                ...error.metadata,
                requestId,
            },
            timestamp: new Date().toISOString(),
        },
    };
}
//# sourceMappingURL=errors.js.map