/**
 * Sistema de auditoría de accesos
 * Cumple con requisito 10.4: Auditoría de accesos sensibles
 */
/**
 * Tipos de acciones auditables
 */
export declare enum AuditAction {
    ACCESS_PROFILE = "ACCESS_PROFILE",
    ACCESS_ACADEMIC_RECORD = "ACCESS_ACADEMIC_RECORD",
    ACCESS_FINANCIAL_DATA = "ACCESS_FINANCIAL_DATA",
    GENERATE_CERTIFICATE = "GENERATE_CERTIFICATE",
    UPDATE_STUDENT_DATA = "UPDATE_STUDENT_DATA",
    AUTHENTICATION_SUCCESS = "AUTHENTICATION_SUCCESS",
    AUTHENTICATION_FAILURE = "AUTHENTICATION_FAILURE",
    UNAUTHORIZED_ACCESS_ATTEMPT = "UNAUTHORIZED_ACCESS_ATTEMPT"
}
/**
 * Nivel de sensibilidad de la información
 */
export declare enum SensitivityLevel {
    PUBLIC = "PUBLIC",
    INTERNAL = "INTERNAL",
    CONFIDENTIAL = "CONFIDENTIAL",
    RESTRICTED = "RESTRICTED"
}
/**
 * Registro de auditoría
 */
export interface AuditLog {
    auditId: string;
    timestamp: string;
    action: AuditAction;
    studentId?: string;
    sessionId: string;
    contactId?: string;
    userId?: string;
    resourceType: string;
    resourceId?: string;
    sensitivityLevel: SensitivityLevel;
    success: boolean;
    reason?: string;
    metadata?: Record<string, unknown>;
    ipAddress?: string;
    userAgent?: string;
}
/**
 * Sistema de auditoría
 */
export declare class AuditLogger {
    /**
     * Registra un acceso a información sensible
     */
    static logAccess(params: {
        action: AuditAction;
        studentId?: string;
        sessionId: string;
        contactId?: string;
        resourceType: string;
        resourceId?: string;
        sensitivityLevel: SensitivityLevel;
        success: boolean;
        reason?: string;
        metadata?: Record<string, unknown>;
    }): Promise<void>;
    /**
     * Registra acceso a perfil de estudiante
     */
    static logProfileAccess(studentId: string, sessionId: string, success: boolean, reason?: string): Promise<void>;
    /**
     * Registra acceso a historial académico
     */
    static logAcademicRecordAccess(studentId: string, sessionId: string, success: boolean, reason?: string): Promise<void>;
    /**
     * Registra acceso a datos financieros
     */
    static logFinancialDataAccess(studentId: string, sessionId: string, success: boolean, reason?: string): Promise<void>;
    /**
     * Registra generación de certificado
     */
    static logCertificateGeneration(studentId: string, sessionId: string, certificateType: string, success: boolean, reason?: string): Promise<void>;
    /**
     * Registra intento de autenticación
     */
    static logAuthenticationAttempt(sessionId: string, studentId: string | undefined, success: boolean, reason?: string): Promise<void>;
    /**
     * Registra intento de acceso no autorizado
     */
    static logUnauthorizedAccessAttempt(sessionId: string, studentId: string | undefined, requestedStudentId: string, resourceType: string): Promise<void>;
    /**
     * Genera un ID único para el registro de auditoría
     */
    private static generateAuditId;
    /**
     * Maneja intentos de acceso no autorizado
     */
    private static handleUnauthorizedAccess;
    /**
     * Obtiene registros de auditoría para un estudiante
     */
    static getAuditLogsForStudent(studentId: string, startDate?: Date, endDate?: Date): Promise<AuditLog[]>;
    /**
     * Obtiene estadísticas de auditoría
     */
    static getAuditStats(period: 'day' | 'week' | 'month'): Promise<{
        totalAccesses: number;
        successfulAccesses: number;
        failedAccesses: number;
        unauthorizedAttempts: number;
    }>;
}
//# sourceMappingURL=audit-logger.d.ts.map