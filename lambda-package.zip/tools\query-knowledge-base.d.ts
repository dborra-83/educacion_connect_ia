/**
 * Herramienta MCP: queryKnowledgeBase
 * Busca información en la base de conocimiento sobre programas, requisitos y procedimientos
 * Integración con Amazon Kendra o S3
 */
import { QueryKnowledgeBaseInput, KnowledgeBaseResult } from '../types/mcp-tools';
/**
 * Consulta la base de conocimiento
 */
export declare function queryKnowledgeBase(input: QueryKnowledgeBaseInput): Promise<KnowledgeBaseResult>;
/**
 * Mock para desarrollo/testing
 * Simula búsqueda en base de conocimiento
 */
export declare function queryKnowledgeBaseMock(input: QueryKnowledgeBaseInput): Promise<KnowledgeBaseResult>;
//# sourceMappingURL=query-knowledge-base.d.ts.map