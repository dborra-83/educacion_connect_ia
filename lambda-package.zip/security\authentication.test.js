"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const vitest_1 = require("vitest");
const authentication_1 = require("./authentication");
vitest_1.vi.mock('../utils/logger');
(0, vitest_1.describe)('AuthenticationMiddleware', () => {
    let mockContext;
    (0, vitest_1.beforeEach)(() => {
        vitest_1.vi.clearAllMocks();
        mockContext = {
            sessionId: 'session-123',
            studentId: 'STU001',
            contactId: 'contact-123',
            channel: 'VOICE',
            instanceARN: 'arn:aws:connect:us-east-1:123456789012:instance/test',
            attributes: {
                studentId: 'STU001',
            },
        };
    });
    (0, vitest_1.describe)('authenticate', () => {
        (0, vitest_1.it)('debe autenticar exitosamente con contexto válido', async () => {
            const result = await authentication_1.AuthenticationMiddleware.authenticate(mockContext);
            (0, vitest_1.expect)(result.authenticated).toBe(true);
            (0, vitest_1.expect)(result.studentId).toBe('STU001');
            (0, vitest_1.expect)(result.sessionId).toBe('session-123');
        });
        (0, vitest_1.it)('debe fallar si falta sessionId', async () => {
            mockContext.sessionId = '';
            const result = await authentication_1.AuthenticationMiddleware.authenticate(mockContext);
            (0, vitest_1.expect)(result.authenticated).toBe(false);
            (0, vitest_1.expect)(result.reason).toContain('sesión incompleta');
        });
        (0, vitest_1.it)('debe fallar si falta contactId', async () => {
            mockContext.contactId = '';
            const result = await authentication_1.AuthenticationMiddleware.authenticate(mockContext);
            (0, vitest_1.expect)(result.authenticated).toBe(false);
            (0, vitest_1.expect)(result.reason).toContain('sesión incompleta');
        });
        (0, vitest_1.it)('debe fallar si el instanceARN es inválido', async () => {
            mockContext.instanceARN = 'invalid-arn';
            const result = await authentication_1.AuthenticationMiddleware.authenticate(mockContext);
            (0, vitest_1.expect)(result.authenticated).toBe(false);
            (0, vitest_1.expect)(result.reason).toContain('inválida');
        });
        (0, vitest_1.it)('debe fallar si el canal es inválido', async () => {
            mockContext.channel = 'INVALID';
            const result = await authentication_1.AuthenticationMiddleware.authenticate(mockContext);
            (0, vitest_1.expect)(result.authenticated).toBe(false);
            (0, vitest_1.expect)(result.reason).toContain('inválida');
        });
        (0, vitest_1.it)('debe fallar si studentId no coincide con atributos', async () => {
            mockContext.attributes.studentId = 'STU002';
            const result = await authentication_1.AuthenticationMiddleware.authenticate(mockContext);
            (0, vitest_1.expect)(result.authenticated).toBe(false);
            (0, vitest_1.expect)(result.reason).toContain('no verificada');
        });
        (0, vitest_1.it)('debe autenticar sin studentId si no se requiere', async () => {
            delete mockContext.studentId;
            const result = await authentication_1.AuthenticationMiddleware.authenticate(mockContext);
            (0, vitest_1.expect)(result.authenticated).toBe(true);
            (0, vitest_1.expect)(result.studentId).toBeUndefined();
        });
    });
    (0, vitest_1.describe)('requiresAuthentication', () => {
        (0, vitest_1.it)('debe requerir autenticación para operaciones sensibles', () => {
            (0, vitest_1.expect)(authentication_1.AuthenticationMiddleware.requiresAuthentication('getStudentProfile')).toBe(true);
            (0, vitest_1.expect)(authentication_1.AuthenticationMiddleware.requiresAuthentication('checkAcademicRecord')).toBe(true);
            (0, vitest_1.expect)(authentication_1.AuthenticationMiddleware.requiresAuthentication('generateCertificate')).toBe(true);
        });
        (0, vitest_1.it)('no debe requerir autenticación para operaciones públicas', () => {
            (0, vitest_1.expect)(authentication_1.AuthenticationMiddleware.requiresAuthentication('queryKnowledgeBase')).toBe(false);
            (0, vitest_1.expect)(authentication_1.AuthenticationMiddleware.requiresAuthentication('getHelp')).toBe(false);
        });
    });
    (0, vitest_1.describe)('verifyAccess', () => {
        (0, vitest_1.it)('debe permitir acceso a propios datos', async () => {
            const result = await authentication_1.AuthenticationMiddleware.verifyAccess('STU001', 'STU001');
            (0, vitest_1.expect)(result).toBe(true);
        });
        (0, vitest_1.it)('debe denegar acceso a datos de otro estudiante', async () => {
            const result = await authentication_1.AuthenticationMiddleware.verifyAccess('STU001', 'STU002');
            (0, vitest_1.expect)(result).toBe(false);
        });
    });
});
//# sourceMappingURL=authentication.test.js.map