"use strict";
/**
 * Interfaces para las herramientas MCP (Model Context Protocol)
 * Estas interfaces definen los contratos de entrada/salida para cada herramienta
 */
Object.defineProperty(exports, "__esModule", { value: true });
//# sourceMappingURL=mcp-tools.js.map