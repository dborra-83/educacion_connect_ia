/**
 * Lambda Handler para API de Registros Académicos
 * Simula una API académica que retorna información de cursos y calificaciones
 */
export declare const handler: (event: any) => Promise<any>;
//# sourceMappingURL=academic-record.d.ts.map