"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const vitest_1 = require("vitest");
const error_handler_1 = require("./error-handler");
const errors_1 = require("../types/errors");
(0, vitest_1.describe)('ErrorTranslator', () => {
    (0, vitest_1.it)('debe traducir StudentNotFoundError a mensaje amigable', () => {
        const error = new errors_1.StudentNotFoundError('12345');
        const message = error_handler_1.ErrorTranslator.translateError(error);
        (0, vitest_1.expect)(message).toContain('No pude encontrar tu información');
        (0, vitest_1.expect)(message).not.toContain('12345');
    });
    (0, vitest_1.it)('debe traducir ServiceUnavailableError a mensaje amigable', () => {
        const error = new errors_1.ServiceUnavailableError('DynamoDB');
        const message = error_handler_1.ErrorTranslator.translateError(error);
        (0, vitest_1.expect)(message).toContain('dificultades');
    });
    (0, vitest_1.it)('debe traducir StudentHasDebtsError a mensaje amigable', () => {
        const error = new errors_1.StudentHasDebtsError('12345', 500);
        const message = error_handler_1.ErrorTranslator.translateError(error);
        (0, vitest_1.expect)(message).toContain('pagos pendientes');
    });
    (0, vitest_1.it)('debe retornar mensaje genérico para errores desconocidos', () => {
        const error = new Error('Unknown technical error');
        const message = error_handler_1.ErrorTranslator.translateError(error);
        (0, vitest_1.expect)(message).toContain('problema inesperado');
    });
    (0, vitest_1.it)('debe remover stack traces', () => {
        const message = 'Error message\n  at function (file.ts:10:5)';
        const sanitized = error_handler_1.ErrorTranslator.sanitizeErrorMessage(message);
        (0, vitest_1.expect)(sanitized).toBe('Error message');
    });
    (0, vitest_1.it)('debe remover nombres de servicios técnicos', () => {
        const message = 'DynamoDB connection failed';
        const sanitized = error_handler_1.ErrorTranslator.sanitizeErrorMessage(message);
        (0, vitest_1.expect)(sanitized).toContain('servicio');
    });
});
(0, vitest_1.describe)('AlternativeGenerator', () => {
    (0, vitest_1.it)('debe generar alternativas para StudentNotFoundError', () => {
        const error = new errors_1.StudentNotFoundError('12345');
        const alternatives = error_handler_1.AlternativeGenerator.generateAlternatives(error);
        (0, vitest_1.expect)(alternatives.length).toBeGreaterThan(0);
        (0, vitest_1.expect)(alternatives.some((alt) => alt.includes('Verifica'))).toBe(true);
    });
    (0, vitest_1.it)('debe generar alternativas para ServiceUnavailableError', () => {
        const error = new errors_1.ServiceUnavailableError('API');
        const alternatives = error_handler_1.AlternativeGenerator.generateAlternatives(error);
        (0, vitest_1.expect)(alternatives.length).toBeGreaterThan(0);
        (0, vitest_1.expect)(alternatives.some((alt) => alt.includes('minutos'))).toBe(true);
    });
    (0, vitest_1.it)('debe sugerir contacto humano para ServiceUnavailableError', () => {
        const error = new errors_1.ServiceUnavailableError('API');
        const suggestion = error_handler_1.AlternativeGenerator.generateHumanContactSuggestion(error);
        (0, vitest_1.expect)(suggestion).toContain('transferirte');
    });
    (0, vitest_1.it)('debe sugerir reintento para ServiceUnavailableError', () => {
        const error = new errors_1.ServiceUnavailableError('API');
        const suggestion = error_handler_1.AlternativeGenerator.generateRetrySuggestion(error);
        (0, vitest_1.expect)(suggestion).not.toBeNull();
        (0, vitest_1.expect)(suggestion).toContain('intenta de nuevo');
    });
    (0, vitest_1.it)('NO debe sugerir reintento para StudentHasDebtsError', () => {
        const error = new errors_1.StudentHasDebtsError('12345', 500);
        const suggestion = error_handler_1.AlternativeGenerator.generateRetrySuggestion(error);
        (0, vitest_1.expect)(suggestion).toBeNull();
    });
});
(0, vitest_1.describe)('ErrorSeverityClassifier', () => {
    (0, vitest_1.it)('debe clasificar UnauthorizedAccessError como CRITICAL', () => {
        const error = new errors_1.UnauthorizedAccessError('resource');
        const severity = error_handler_1.ErrorSeverityClassifier.classify(error);
        (0, vitest_1.expect)(severity).toBe(error_handler_1.ErrorSeverity.CRITICAL);
    });
    (0, vitest_1.it)('debe clasificar ServiceUnavailableError como HIGH', () => {
        const error = new errors_1.ServiceUnavailableError('API');
        const severity = error_handler_1.ErrorSeverityClassifier.classify(error);
        (0, vitest_1.expect)(severity).toBe(error_handler_1.ErrorSeverity.HIGH);
    });
    (0, vitest_1.it)('debe clasificar StudentHasDebtsError como MEDIUM', () => {
        const error = new errors_1.StudentHasDebtsError('12345', 500);
        const severity = error_handler_1.ErrorSeverityClassifier.classify(error);
        (0, vitest_1.expect)(severity).toBe(error_handler_1.ErrorSeverity.MEDIUM);
    });
    (0, vitest_1.it)('debe clasificar InvalidStudentIdError como LOW', () => {
        const error = new errors_1.InvalidStudentIdError('invalid');
        const severity = error_handler_1.ErrorSeverityClassifier.classify(error);
        (0, vitest_1.expect)(severity).toBe(error_handler_1.ErrorSeverity.LOW);
    });
    (0, vitest_1.it)('debe requerir escalamiento para errores CRITICAL', () => {
        const error = new errors_1.UnauthorizedAccessError('resource');
        const requires = error_handler_1.ErrorSeverityClassifier.requiresEscalation(error);
        (0, vitest_1.expect)(requires).toBe(true);
    });
    (0, vitest_1.it)('NO debe requerir escalamiento para errores LOW', () => {
        const error = new errors_1.InvalidStudentIdError('invalid');
        const requires = error_handler_1.ErrorSeverityClassifier.requiresEscalation(error);
        (0, vitest_1.expect)(requires).toBe(false);
    });
    (0, vitest_1.it)('debe permitir reintento para ServiceUnavailableError', () => {
        const error = new errors_1.ServiceUnavailableError('API');
        const canRetry = error_handler_1.ErrorSeverityClassifier.canRetry(error);
        (0, vitest_1.expect)(canRetry).toBe(true);
    });
    (0, vitest_1.it)('NO debe permitir reintento para StudentHasDebtsError', () => {
        const error = new errors_1.StudentHasDebtsError('12345', 500);
        const canRetry = error_handler_1.ErrorSeverityClassifier.canRetry(error);
        (0, vitest_1.expect)(canRetry).toBe(false);
    });
});
(0, vitest_1.describe)('ErrorHandler', () => {
    (0, vitest_1.it)('debe manejar StudentNotFoundError correctamente', () => {
        const error = new errors_1.StudentNotFoundError('12345');
        const result = error_handler_1.ErrorHandler.handleError(error);
        (0, vitest_1.expect)(result.userMessage).toContain('No pude encontrar');
        (0, vitest_1.expect)(result.alternatives.length).toBeGreaterThan(0);
        (0, vitest_1.expect)(result.severity).toBe(error_handler_1.ErrorSeverity.LOW);
        (0, vitest_1.expect)(result.requiresHumanEscalation).toBe(false);
    });
    (0, vitest_1.it)('debe manejar ServiceUnavailableError correctamente', () => {
        const error = new errors_1.ServiceUnavailableError('API');
        const result = error_handler_1.ErrorHandler.handleError(error);
        (0, vitest_1.expect)(result.userMessage).toContain('dificultades');
        (0, vitest_1.expect)(result.severity).toBe(error_handler_1.ErrorSeverity.HIGH);
        (0, vitest_1.expect)(result.requiresHumanEscalation).toBe(true);
        (0, vitest_1.expect)(result.canRetry).toBe(true);
    });
    (0, vitest_1.it)('debe generar mensaje completo con alternativas', () => {
        const result = {
            userMessage: 'Error message',
            alternatives: ['Alternative 1', 'Alternative 2'],
            requiresHumanEscalation: false,
            severity: error_handler_1.ErrorSeverity.MEDIUM,
            canRetry: true,
        };
        const message = error_handler_1.ErrorHandler.generateUserMessage(result);
        (0, vitest_1.expect)(message).toContain('Error message');
        (0, vitest_1.expect)(message).toContain('Puedes:');
        (0, vitest_1.expect)(message).toContain('1. Alternative 1');
    });
    (0, vitest_1.it)('debe manejar múltiples tipos de errores consistentemente', () => {
        const errors = [
            new errors_1.StudentNotFoundError('12345'),
            new errors_1.ServiceUnavailableError('API'),
            new errors_1.StudentHasDebtsError('12345', 500),
        ];
        errors.forEach((error) => {
            const result = error_handler_1.ErrorHandler.handleError(error);
            (0, vitest_1.expect)(result.userMessage).toBeTruthy();
            (0, vitest_1.expect)(result.alternatives).toBeDefined();
            (0, vitest_1.expect)(Object.values(error_handler_1.ErrorSeverity)).toContain(result.severity);
        });
    });
});
//# sourceMappingURL=error-handling.test.js.map