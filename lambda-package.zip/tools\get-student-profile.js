"use strict";
/**
 * Herramienta MCP: getStudentProfile
 * Recupera el perfil unificado del estudiante desde DynamoDB
 * Integra datos de CRM y LMS
 */
Object.defineProperty(exports, "__esModule", { value: true });
exports.getStudentProfile = getStudentProfile;
exports.getStudentProfileMock = getStudentProfileMock;
const client_dynamodb_1 = require("@aws-sdk/client-dynamodb");
const lib_dynamodb_1 = require("@aws-sdk/lib-dynamodb");
const errors_1 = require("../types/errors");
const retry_1 = require("../utils/retry");
const logger_1 = require("../utils/logger");
// Cliente DynamoDB (en producción se configuraría con credenciales reales)
const dynamoClient = new client_dynamodb_1.DynamoDBClient({
    region: process.env.AWS_REGION || 'us-east-1',
});
const docClient = lib_dynamodb_1.DynamoDBDocumentClient.from(dynamoClient);
const TABLE_NAME = process.env.STUDENT_PROFILES_TABLE || 'StudentProfiles';
/**
 * Valida el formato del studentId
 */
function validateStudentId(studentId) {
    if (!studentId || studentId.trim().length === 0) {
        throw new errors_1.InvalidStudentIdError(studentId);
    }
    // Validar formato básico (ajustar según necesidades)
    if (studentId.length < 3 || studentId.length > 50) {
        throw new errors_1.InvalidStudentIdError(studentId);
    }
}
/**
 * Convierte UnifiedProfile de DynamoDB a StudentProfile
 */
function mapToStudentProfile(profile, includeAcademic, includeCRM) {
    const result = {
        studentId: profile.studentId,
        firstName: profile.firstName,
        lastName: profile.lastName,
        email: profile.email,
        phone: profile.phone,
    };
    // Incluir datos académicos si se solicita
    if (includeAcademic && profile.program) {
        result.program = {
            name: profile.program.name,
            code: profile.program.code,
            enrollmentDate: profile.program.enrollmentDate,
        };
        result.academicStatus = profile.academicStatus;
    }
    // Incluir datos CRM si se solicita
    if (includeCRM && profile.crmData) {
        result.crmData = {
            lastContact: profile.crmData.lastContactDate,
            preferredChannel: profile.crmData.lastContactChannel,
            tags: profile.crmData.tags,
        };
    }
    return result;
}
/**
 * Recupera el perfil del estudiante desde DynamoDB
 */
async function getStudentProfile(input) {
    const { studentId, includeAcademic = true, includeCRM = true } = input;
    // Validar entrada
    validateStudentId(studentId);
    logger_1.logger.info(`Recuperando perfil del estudiante: ${studentId}`);
    try {
        // Ejecutar consulta con reintentos
        const result = await (0, retry_1.retryWithBackoff)(async () => {
            const command = new lib_dynamodb_1.GetCommand({
                TableName: TABLE_NAME,
                Key: {
                    PK: `STUDENT#${studentId}`,
                    SK: 'PROFILE',
                },
            });
            return await docClient.send(command);
        }, 3, // maxRetries
        1000);
        // Verificar si se encontró el perfil
        if (!result.Item) {
            logger_1.logger.warn(`Perfil no encontrado para estudiante: ${studentId}`);
            throw new errors_1.StudentNotFoundError(studentId);
        }
        const profile = result.Item;
        // Mapear a StudentProfile
        const studentProfile = mapToStudentProfile(profile, includeAcademic, includeCRM);
        logger_1.logger.info(`Perfil recuperado exitosamente para: ${studentId}`);
        return studentProfile;
    }
    catch (error) {
        // Si ya es un error conocido, re-lanzarlo
        if (error instanceof errors_1.StudentNotFoundError || error instanceof errors_1.InvalidStudentIdError) {
            throw error;
        }
        // Error de servicio
        logger_1.logger.error(`Error al recuperar perfil de ${studentId}:`, error);
        throw new errors_1.ServiceUnavailableError('DynamoDB');
    }
}
/**
 * Mock para desarrollo/testing sin AWS
 * Simula datos de estudiantes
 */
async function getStudentProfileMock(input) {
    validateStudentId(input.studentId);
    // Simular delay de red
    await new Promise((resolve) => setTimeout(resolve, 100));
    // Datos mock
    const mockProfiles = {
        STU001: {
            studentId: 'STU001',
            firstName: 'Carlos',
            lastName: 'Rodríguez',
            email: 'carlos.rodriguez@universidad.edu',
            phone: '+57 300 123 4567',
            program: {
                name: 'Ingeniería Informática',
                code: 'ING-INF',
                enrollmentDate: '2022-01-15',
            },
            academicStatus: 'active',
            crmData: {
                lastContact: '2024-01-10',
                preferredChannel: 'email',
                tags: ['prospecto', 'interesado-maestria'],
            },
        },
        STU002: {
            studentId: 'STU002',
            firstName: 'María',
            lastName: 'González',
            email: 'maria.gonzalez@universidad.edu',
            phone: '+57 310 987 6543',
            program: {
                name: 'Administración de Empresas',
                code: 'ADM-EMP',
                enrollmentDate: '2021-08-20',
            },
            academicStatus: 'active',
        },
    };
    const profile = mockProfiles[input.studentId];
    if (!profile) {
        throw new errors_1.StudentNotFoundError(input.studentId);
    }
    return profile;
}
//# sourceMappingURL=get-student-profile.js.map