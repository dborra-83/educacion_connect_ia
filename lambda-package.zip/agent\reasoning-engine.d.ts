/**
 * Motor de Razonamiento del Agente
 * Implementa el ciclo completo: identificar intención → recuperar contexto → analizar → ejecutar → responder
 */
import { ConversationContext, AgentResponse } from '../types/models';
/**
 * Tipos de intención que el agente puede detectar
 */
export declare enum IntentType {
    GREETING = "greeting",
    REQUEST_CERTIFICATE = "request_certificate",
    QUERY_PROGRAM = "query_program",
    CHECK_ACADEMIC_STATUS = "check_academic_status",
    REQUEST_HELP = "request_help",
    UNKNOWN = "unknown"
}
/**
 * Resultado del análisis de intención
 */
export interface IntentAnalysis {
    intent: IntentType;
    confidence: number;
    entities: Record<string, any>;
}
/**
 * Motor de razonamiento del agente
 */
export declare class ReasoningEngine {
    private useMock;
    constructor(useMock?: boolean);
    /**
     * Procesa un mensaje del usuario y genera una respuesta
     * Implementa el ciclo completo de razonamiento
     */
    processMessage(userMessage: string, context: ConversationContext): Promise<AgentResponse>;
    /**
     * Identifica la intención del usuario desde su mensaje
     */
    private identifyIntent;
    /**
     * Analiza la situación del estudiante
     */
    private analyzeSituation;
    /**
     * Ejecuta las acciones necesarias según la intención
     */
    private executeActions;
    /**
     * Genera la respuesta final para el usuario
     */
    private generateResponse;
    /**
     * Genera mensaje de ayuda general
     */
    private generateHelpMessage;
    /**
     * Actualiza el historial de conversación
     */
    private updateConversationHistory;
}
//# sourceMappingURL=reasoning-engine.d.ts.map