"use strict";
/**
 * Tests para el Motor de Razonamiento del Agente
 */
Object.defineProperty(exports, "__esModule", { value: true });
const vitest_1 = require("vitest");
const reasoning_engine_1 = require("./reasoning-engine");
(0, vitest_1.describe)('ReasoningEngine', () => {
    let engine;
    let context;
    (0, vitest_1.beforeEach)(() => {
        engine = new reasoning_engine_1.ReasoningEngine(true); // usar mocks
        context = {
            sessionId: 'test-session-123',
            studentId: 'STU001',
            conversationHistory: [],
            metadata: {},
        };
    });
    (0, vitest_1.describe)('Detección de Intenciones', () => {
        (0, vitest_1.it)('debe detectar intención de saludo al inicio de conversación', async () => {
            const response = await engine.processMessage('Hola', context);
            (0, vitest_1.expect)(response.message).toBeTruthy();
            (0, vitest_1.expect)(response.message.length).toBeGreaterThan(0);
            (0, vitest_1.expect)(context.currentIntent).toBe(reasoning_engine_1.IntentType.GREETING);
        });
        (0, vitest_1.it)('debe detectar intención de solicitud de certificado', async () => {
            const response = await engine.processMessage('Necesito un certificado de inscripción', context);
            (0, vitest_1.expect)(context.currentIntent).toBe(reasoning_engine_1.IntentType.REQUEST_CERTIFICATE);
            (0, vitest_1.expect)(response.message).toBeTruthy();
        });
        (0, vitest_1.it)('debe detectar intención de consulta sobre programa', async () => {
            const response = await engine.processMessage('¿Cuál es el pensum de Ingeniería Informática?', context);
            (0, vitest_1.expect)(context.currentIntent).toBe(reasoning_engine_1.IntentType.QUERY_PROGRAM);
            (0, vitest_1.expect)(response.message).toBeTruthy();
        });
        (0, vitest_1.it)('debe detectar intención de consulta de estado académico', async () => {
            const response = await engine.processMessage('¿Cómo están mis calificaciones?', context);
            (0, vitest_1.expect)(context.currentIntent).toBe(reasoning_engine_1.IntentType.CHECK_ACADEMIC_STATUS);
            (0, vitest_1.expect)(response.message).toBeTruthy();
        });
        (0, vitest_1.it)('debe detectar intención de solicitud de ayuda', async () => {
            const response = await engine.processMessage('¿Puedes ayudarme?', context);
            (0, vitest_1.expect)(context.currentIntent).toBe(reasoning_engine_1.IntentType.REQUEST_HELP);
            (0, vitest_1.expect)(response.message).toContain('ayudarte');
        });
        (0, vitest_1.it)('debe detectar intención desconocida para mensajes ambiguos', async () => {
            const response = await engine.processMessage('xyz abc 123', context);
            (0, vitest_1.expect)(context.currentIntent).toBe(reasoning_engine_1.IntentType.UNKNOWN);
            (0, vitest_1.expect)(response.message).toContain('No estoy seguro');
        });
    });
    (0, vitest_1.describe)('Procesamiento de Mensajes', () => {
        (0, vitest_1.it)('debe generar saludo personalizado cuando hay perfil', async () => {
            context.studentProfile = {
                studentId: 'STU001',
                firstName: 'Carlos',
                lastName: 'Rodríguez',
                email: 'carlos@example.com',
                phone: '+1234567890',
                enrollmentStatus: 'active',
                program: {
                    programId: 'PROG001',
                    name: 'Ingeniería Informática',
                    level: 'undergraduate',
                    startDate: '2023-01-15',
                },
                academicLevel: 'sophomore',
                lastUpdated: new Date().toISOString(),
            };
            const response = await engine.processMessage('Hola', context);
            (0, vitest_1.expect)(response.message).toContain('Carlos');
            (0, vitest_1.expect)(response.message).toContain('Ingeniería Informática');
        });
        (0, vitest_1.it)('debe actualizar historial de conversación', async () => {
            const userMessage = 'Hola';
            await engine.processMessage(userMessage, context);
            (0, vitest_1.expect)(context.conversationHistory.length).toBe(2); // user + assistant
            (0, vitest_1.expect)(context.conversationHistory[0].role).toBe('user');
            (0, vitest_1.expect)(context.conversationHistory[0].content).toBe(userMessage);
            (0, vitest_1.expect)(context.conversationHistory[1].role).toBe('assistant');
        });
        (0, vitest_1.it)('debe incluir tiempo de procesamiento en metadata', async () => {
            const response = await engine.processMessage('Hola', context);
            (0, vitest_1.expect)(response.metadata?.processingTime).toBeGreaterThan(0);
        });
        (0, vitest_1.it)('debe incluir herramientas usadas en metadata', async () => {
            const response = await engine.processMessage('Hola', context);
            (0, vitest_1.expect)(response.metadata?.toolsUsed).toBeDefined();
            (0, vitest_1.expect)(Array.isArray(response.metadata?.toolsUsed)).toBe(true);
        });
    });
    (0, vitest_1.describe)('Flujo de Certificados', () => {
        (0, vitest_1.it)('debe procesar solicitud de certificado exitosamente', async () => {
            const response = await engine.processMessage('Necesito un certificado de inscripción', context);
            (0, vitest_1.expect)(response.message).toBeTruthy();
            (0, vitest_1.expect)(response.requiresHumanEscalation).toBeFalsy();
        });
        (0, vitest_1.it)('debe solicitar identificación si no hay studentId', async () => {
            context.studentId = undefined;
            const response = await engine.processMessage('Necesito un certificado de inscripción', context);
            (0, vitest_1.expect)(response.message).toContain('identificación');
        });
        (0, vitest_1.it)('debe detectar tipo de certificado de calificaciones', async () => {
            const response = await engine.processMessage('Quiero solicitar un certificado de notas', context);
            (0, vitest_1.expect)(response.message).toBeTruthy();
        });
    });
    (0, vitest_1.describe)('Consultas a Base de Conocimiento', () => {
        (0, vitest_1.it)('debe responder consultas sobre programas', async () => {
            const response = await engine.processMessage('¿Cuáles son los requisitos de admisión?', context);
            (0, vitest_1.expect)(response.message).toBeTruthy();
            (0, vitest_1.expect)(context.currentIntent).toBe(reasoning_engine_1.IntentType.QUERY_PROGRAM);
        });
        (0, vitest_1.it)('debe formatear resultados de búsqueda', async () => {
            const response = await engine.processMessage('¿Qué es el pensum?', context);
            (0, vitest_1.expect)(response.message).toBeTruthy();
        });
    });
    (0, vitest_1.describe)('Estado Académico', () => {
        (0, vitest_1.it)('debe consultar estado académico del estudiante', async () => {
            const response = await engine.processMessage('¿Cómo están mis calificaciones?', context);
            (0, vitest_1.expect)(response.message).toBeTruthy();
            (0, vitest_1.expect)(context.currentIntent).toBe(reasoning_engine_1.IntentType.CHECK_ACADEMIC_STATUS);
        });
        (0, vitest_1.it)('debe solicitar identificación si no hay studentId para estado académico', async () => {
            context.studentId = undefined;
            const response = await engine.processMessage('¿Cómo están mis calificaciones?', context);
            (0, vitest_1.expect)(response.message).toContain('identificación');
        });
    });
    (0, vitest_1.describe)('Manejo de Errores', () => {
        (0, vitest_1.it)('debe manejar errores gracefully', async () => {
            // Forzar error usando contexto inválido
            const invalidContext = {};
            const response = await engine.processMessage('Hola', invalidContext);
            (0, vitest_1.expect)(response.message).toContain('problema');
            (0, vitest_1.expect)(response.requiresHumanEscalation).toBe(true);
        });
        (0, vitest_1.it)('debe incluir tiempo de procesamiento incluso en errores', async () => {
            const invalidContext = {};
            const response = await engine.processMessage('Hola', invalidContext);
            (0, vitest_1.expect)(response.metadata?.processingTime).toBeGreaterThanOrEqual(0);
        });
    });
    (0, vitest_1.describe)('Historial de Conversación', () => {
        (0, vitest_1.it)('debe limitar historial a 20 mensajes', async () => {
            // Agregar 25 mensajes
            for (let i = 0; i < 25; i++) {
                await engine.processMessage(`Mensaje ${i}`, context);
            }
            (0, vitest_1.expect)(context.conversationHistory.length).toBeLessThanOrEqual(20);
        });
        (0, vitest_1.it)('debe mantener mensajes más recientes cuando limita historial', async () => {
            // Agregar 25 mensajes
            for (let i = 0; i < 25; i++) {
                await engine.processMessage(`Mensaje ${i}`, context);
            }
            const lastUserMessage = context.conversationHistory.find((msg) => msg.role === 'user' && msg.content.includes('Mensaje 24'));
            (0, vitest_1.expect)(lastUserMessage).toBeDefined();
        });
    });
    (0, vitest_1.describe)('Mensaje de Ayuda', () => {
        (0, vitest_1.it)('debe generar mensaje de ayuda completo', async () => {
            const response = await engine.processMessage('Ayuda', context);
            (0, vitest_1.expect)(response.message).toContain('Certificados');
            (0, vitest_1.expect)(response.message).toContain('Información Académica');
            (0, vitest_1.expect)(response.message).toContain('Estado Académico');
        });
        (0, vitest_1.it)('debe personalizar mensaje de ayuda con nombre si hay perfil', async () => {
            context.studentProfile = {
                studentId: 'STU001',
                firstName: 'María',
                lastName: 'González',
                email: 'maria@example.com',
                phone: '+1234567890',
                enrollmentStatus: 'active',
                academicLevel: 'junior',
                lastUpdated: new Date().toISOString(),
            };
            const response = await engine.processMessage('Ayuda', context);
            (0, vitest_1.expect)(response.message).toContain('María');
        });
    });
    (0, vitest_1.describe)('Intención Desconocida', () => {
        (0, vitest_1.it)('debe ofrecer opciones cuando no entiende la intención', async () => {
            const response = await engine.processMessage('xyz abc 123', context);
            (0, vitest_1.expect)(response.message).toContain('certificados');
            (0, vitest_1.expect)(response.message).toContain('programas');
            (0, vitest_1.expect)(response.message).toContain('académico');
        });
    });
});
//# sourceMappingURL=reasoning-engine.test.js.map