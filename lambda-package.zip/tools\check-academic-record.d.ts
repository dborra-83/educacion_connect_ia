/**
 * Herramienta MCP: checkAcademicRecord
 * Consulta el historial académico del estudiante
 * Integración con API académica vía Lambda
 */
import { CheckAcademicRecordInput, AcademicRecord } from '../types/mcp-tools';
/**
 * Consulta el historial académico del estudiante
 */
export declare function checkAcademicRecord(input: CheckAcademicRecordInput): Promise<AcademicRecord>;
/**
 * Mock para desarrollo/testing
 * Simula datos académicos de estudiantes
 */
export declare function checkAcademicRecordMock(input: CheckAcademicRecordInput): Promise<AcademicRecord>;
//# sourceMappingURL=check-academic-record.d.ts.map