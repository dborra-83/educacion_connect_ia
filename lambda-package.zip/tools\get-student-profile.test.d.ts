/**
 * Tests para getStudentProfile
 */
export {};
//# sourceMappingURL=get-student-profile.test.d.ts.map