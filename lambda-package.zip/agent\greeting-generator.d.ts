/**
 * Generador de saludos personalizados
 * Crea mensajes de bienvenida basados en el perfil del estudiante
 */
import { StudentProfile } from '../types/mcp-tools';
/**
 * Genera un saludo personalizado con el nombre completo del estudiante
 */
export declare function generateGreeting(profile?: StudentProfile): string;
/**
 * Genera mensaje solicitando identificación cuando no hay perfil
 */
export declare function generateIdentificationRequest(): string;
/**
 * Genera saludo con información adicional del estado académico
 */
export declare function generateDetailedGreeting(profile: StudentProfile, includeAcademicStatus?: boolean): string;
/**
 * Genera saludo de retorno para estudiantes que ya han interactuado antes
 */
export declare function generateReturningStudentGreeting(profile: StudentProfile): string;
/**
 * Genera saludo con manejo de caracteres especiales en nombres
 */
export declare function sanitizeAndFormatName(firstName: string, lastName: string): string;
/**
 * Genera saludo según hora del día
 */
export declare function generateTimeBasedGreeting(profile: StudentProfile): string;
//# sourceMappingURL=greeting-generator.d.ts.map