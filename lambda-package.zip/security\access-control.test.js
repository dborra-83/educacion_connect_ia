"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const vitest_1 = require("vitest");
const access_control_1 = require("./access-control");
const audit_logger_1 = require("./audit-logger");
vitest_1.vi.mock('../utils/logger');
vitest_1.vi.mock('./audit-logger');
(0, vitest_1.describe)('AccessControl', () => {
    (0, vitest_1.beforeEach)(() => {
        vitest_1.vi.clearAllMocks();
    });
    (0, vitest_1.describe)('checkAccess', () => {
        (0, vitest_1.it)('debe permitir acceso a propios datos', async () => {
            const result = await access_control_1.AccessControl.checkAccess({
                sessionId: 'session-123',
                authenticatedStudentId: 'STU001',
                requestedStudentId: 'STU001',
                resourceType: 'StudentProfile',
                operation: 'getStudentProfile',
            });
            (0, vitest_1.expect)(result.allowed).toBe(true);
        });
        (0, vitest_1.it)('debe denegar acceso a datos de otro estudiante', async () => {
            const result = await access_control_1.AccessControl.checkAccess({
                sessionId: 'session-123',
                authenticatedStudentId: 'STU001',
                requestedStudentId: 'STU002',
                resourceType: 'StudentProfile',
                operation: 'getStudentProfile',
            });
            (0, vitest_1.expect)(result.allowed).toBe(false);
            (0, vitest_1.expect)(result.reason).toContain('No autorizado');
            (0, vitest_1.expect)(audit_logger_1.AuditLogger.logUnauthorizedAccessAttempt).toHaveBeenCalled();
        });
        (0, vitest_1.it)('debe denegar acceso si no está autenticado', async () => {
            const result = await access_control_1.AccessControl.checkAccess({
                sessionId: 'session-123',
                authenticatedStudentId: undefined,
                requestedStudentId: 'STU001',
                resourceType: 'StudentProfile',
                operation: 'getStudentProfile',
            });
            (0, vitest_1.expect)(result.allowed).toBe(false);
            (0, vitest_1.expect)(result.reason).toContain('Autenticación requerida');
        });
        (0, vitest_1.it)('debe bloquear sesión después de múltiples intentos no autorizados', async () => {
            const sessionId = 'session-suspicious';
            // Primer intento
            await access_control_1.AccessControl.checkAccess({
                sessionId,
                authenticatedStudentId: 'STU001',
                requestedStudentId: 'STU002',
                resourceType: 'StudentProfile',
                operation: 'getStudentProfile',
            });
            // Segundo intento
            await access_control_1.AccessControl.checkAccess({
                sessionId,
                authenticatedStudentId: 'STU001',
                requestedStudentId: 'STU003',
                resourceType: 'StudentProfile',
                operation: 'getStudentProfile',
            });
            // Tercer intento - debe bloquear
            const result = await access_control_1.AccessControl.checkAccess({
                sessionId,
                authenticatedStudentId: 'STU001',
                requestedStudentId: 'STU004',
                resourceType: 'StudentProfile',
                operation: 'getStudentProfile',
            });
            (0, vitest_1.expect)(result.allowed).toBe(false);
            (0, vitest_1.expect)(result.blocked).toBe(true);
            (0, vitest_1.expect)(result.requiresEscalation).toBe(true);
        });
        (0, vitest_1.it)('debe denegar acceso a sesión bloqueada', async () => {
            const sessionId = 'session-blocked';
            // Generar 3 intentos para bloquear
            for (let i = 0; i < 3; i++) {
                await access_control_1.AccessControl.checkAccess({
                    sessionId,
                    authenticatedStudentId: 'STU001',
                    requestedStudentId: `STU00${i + 2}`,
                    resourceType: 'StudentProfile',
                    operation: 'getStudentProfile',
                });
            }
            // Intentar acceso legítimo - debe estar bloqueado
            const result = await access_control_1.AccessControl.checkAccess({
                sessionId,
                authenticatedStudentId: 'STU001',
                requestedStudentId: 'STU001',
                resourceType: 'StudentProfile',
                operation: 'getStudentProfile',
            });
            (0, vitest_1.expect)(result.allowed).toBe(false);
            (0, vitest_1.expect)(result.blocked).toBe(true);
            (0, vitest_1.expect)(result.reason).toContain('bloqueada');
        });
        (0, vitest_1.it)('debe permitir operaciones que no requieren autenticación', async () => {
            const result = await access_control_1.AccessControl.checkAccess({
                sessionId: 'session-123',
                authenticatedStudentId: undefined,
                requestedStudentId: 'STU001',
                resourceType: 'KnowledgeBase',
                operation: 'queryKnowledgeBase',
            });
            (0, vitest_1.expect)(result.allowed).toBe(true);
        });
    });
    (0, vitest_1.describe)('unblockSession', () => {
        (0, vitest_1.it)('debe desbloquear una sesión', async () => {
            const sessionId = 'session-to-unblock';
            // Bloquear sesión
            for (let i = 0; i < 3; i++) {
                await access_control_1.AccessControl.checkAccess({
                    sessionId,
                    authenticatedStudentId: 'STU001',
                    requestedStudentId: `STU00${i + 2}`,
                    resourceType: 'StudentProfile',
                    operation: 'getStudentProfile',
                });
            }
            // Desbloquear
            access_control_1.AccessControl.unblockSession(sessionId);
            // Verificar que ahora puede acceder
            const result = await access_control_1.AccessControl.checkAccess({
                sessionId,
                authenticatedStudentId: 'STU001',
                requestedStudentId: 'STU001',
                resourceType: 'StudentProfile',
                operation: 'getStudentProfile',
            });
            (0, vitest_1.expect)(result.allowed).toBe(true);
        });
    });
    (0, vitest_1.describe)('getSecurityStats', () => {
        (0, vitest_1.it)('debe retornar estadísticas de seguridad', () => {
            const stats = access_control_1.AccessControl.getSecurityStats();
            (0, vitest_1.expect)(stats).toHaveProperty('blockedSessions');
            (0, vitest_1.expect)(stats).toHaveProperty('suspiciousAttempts');
            (0, vitest_1.expect)(typeof stats.blockedSessions).toBe('number');
            (0, vitest_1.expect)(typeof stats.suspiciousAttempts).toBe('number');
        });
    });
    (0, vitest_1.describe)('cleanupExpiredBlocks', () => {
        (0, vitest_1.it)('debe limpiar bloqueos expirados', () => {
            const count = access_control_1.AccessControl.cleanupExpiredBlocks();
            (0, vitest_1.expect)(typeof count).toBe('number');
            (0, vitest_1.expect)(count).toBeGreaterThanOrEqual(0);
        });
    });
});
//# sourceMappingURL=access-control.test.js.map