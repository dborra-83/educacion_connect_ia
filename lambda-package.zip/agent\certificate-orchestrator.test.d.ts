/**
 * Tests para certificate-orchestrator
 */
export {};
//# sourceMappingURL=certificate-orchestrator.test.d.ts.map