/**
 * Tests para greeting-generator
 */
export {};
//# sourceMappingURL=greeting-generator.test.d.ts.map