"use strict";
/**
 * Tests para el Gestor de Estado de Conversación
 */
Object.defineProperty(exports, "__esModule", { value: true });
const vitest_1 = require("vitest");
const conversation_manager_1 = require("./conversation-manager");
(0, vitest_1.describe)('ConversationManager', () => {
    const testSessionId = 'test-session-123';
    const testStudentId = 'STU001';
    (0, vitest_1.beforeEach)(() => {
        // Limpiar todas las sesiones antes de cada test
        const stats = conversation_manager_1.ConversationManager.getStats();
        // No hay método público para limpiar todo, así que limpiamos manualmente
    });
    (0, vitest_1.afterEach)(() => {
        // Limpiar sesión de test
        conversation_manager_1.ConversationManager.clearContext(testSessionId);
    });
    (0, vitest_1.describe)('Creación de Contexto', () => {
        (0, vitest_1.it)('debe crear un nuevo contexto de conversación', () => {
            const context = conversation_manager_1.ConversationManager.createContext(testSessionId, testStudentId);
            (0, vitest_1.expect)(context.sessionId).toBe(testSessionId);
            (0, vitest_1.expect)(context.studentId).toBe(testStudentId);
            (0, vitest_1.expect)(context.conversationHistory).toEqual([]);
            (0, vitest_1.expect)(context.metadata.createdAt).toBeDefined();
            (0, vitest_1.expect)(context.metadata.lastActivity).toBeDefined();
        });
        (0, vitest_1.it)('debe crear contexto sin studentId', () => {
            const context = conversation_manager_1.ConversationManager.createContext(testSessionId);
            (0, vitest_1.expect)(context.sessionId).toBe(testSessionId);
            (0, vitest_1.expect)(context.studentId).toBeUndefined();
        });
        (0, vitest_1.it)('debe obtener o crear contexto cuando no existe', () => {
            const context = conversation_manager_1.ConversationManager.getOrCreateContext(testSessionId, testStudentId);
            (0, vitest_1.expect)(context.sessionId).toBe(testSessionId);
            (0, vitest_1.expect)(context.studentId).toBe(testStudentId);
        });
        (0, vitest_1.it)('debe obtener contexto existente en getOrCreateContext', () => {
            const context1 = conversation_manager_1.ConversationManager.createContext(testSessionId, testStudentId);
            const context2 = conversation_manager_1.ConversationManager.getOrCreateContext(testSessionId);
            (0, vitest_1.expect)(context2.sessionId).toBe(context1.sessionId);
            (0, vitest_1.expect)(context2.metadata.createdAt).toBe(context1.metadata.createdAt);
        });
        (0, vitest_1.it)('debe actualizar studentId en contexto existente si no estaba presente', () => {
            conversation_manager_1.ConversationManager.createContext(testSessionId);
            const context = conversation_manager_1.ConversationManager.getOrCreateContext(testSessionId, testStudentId);
            (0, vitest_1.expect)(context.studentId).toBe(testStudentId);
        });
    });
    (0, vitest_1.describe)('Recuperación de Contexto', () => {
        (0, vitest_1.it)('debe recuperar contexto guardado', () => {
            const originalContext = conversation_manager_1.ConversationManager.createContext(testSessionId, testStudentId);
            const retrievedContext = conversation_manager_1.ConversationManager.getContext(testSessionId);
            (0, vitest_1.expect)(retrievedContext).toBeDefined();
            (0, vitest_1.expect)(retrievedContext?.sessionId).toBe(originalContext.sessionId);
            (0, vitest_1.expect)(retrievedContext?.studentId).toBe(originalContext.studentId);
        });
        (0, vitest_1.it)('debe retornar undefined para sesión inexistente', () => {
            const context = conversation_manager_1.ConversationManager.getContext('non-existent-session');
            (0, vitest_1.expect)(context).toBeUndefined();
        });
        (0, vitest_1.it)('debe verificar si una sesión está activa', () => {
            conversation_manager_1.ConversationManager.createContext(testSessionId);
            (0, vitest_1.expect)(conversation_manager_1.ConversationManager.hasActiveSession(testSessionId)).toBe(true);
            (0, vitest_1.expect)(conversation_manager_1.ConversationManager.hasActiveSession('non-existent')).toBe(false);
        });
    });
    (0, vitest_1.describe)('Actualización de Contexto', () => {
        (0, vitest_1.it)('debe actualizar contexto existente', () => {
            conversation_manager_1.ConversationManager.createContext(testSessionId);
            const updatedContext = conversation_manager_1.ConversationManager.updateContext(testSessionId, {
                studentId: 'STU002',
                currentIntent: 'greeting',
            });
            (0, vitest_1.expect)(updatedContext).toBeDefined();
            (0, vitest_1.expect)(updatedContext?.studentId).toBe('STU002');
            (0, vitest_1.expect)(updatedContext?.currentIntent).toBe('greeting');
        });
        (0, vitest_1.it)('debe actualizar timestamp de última actividad al actualizar', () => {
            const context = conversation_manager_1.ConversationManager.createContext(testSessionId);
            const originalTimestamp = context.metadata.lastActivity;
            // Esperar un poco para que el timestamp cambie
            vitest_1.vi.useFakeTimers();
            vitest_1.vi.advanceTimersByTime(1000);
            const updatedContext = conversation_manager_1.ConversationManager.updateContext(testSessionId, {
                currentIntent: 'greeting',
            });
            vitest_1.vi.useRealTimers();
            (0, vitest_1.expect)(updatedContext?.metadata.lastActivity).not.toBe(originalTimestamp);
        });
        (0, vitest_1.it)('debe retornar undefined al actualizar sesión inexistente', () => {
            const result = conversation_manager_1.ConversationManager.updateContext('non-existent', {
                studentId: 'STU001',
            });
            (0, vitest_1.expect)(result).toBeUndefined();
        });
        (0, vitest_1.it)('debe preservar metadata existente al actualizar', () => {
            const context = conversation_manager_1.ConversationManager.createContext(testSessionId);
            context.metadata.customField = 'test-value';
            conversation_manager_1.ConversationManager.saveContext(context);
            const updatedContext = conversation_manager_1.ConversationManager.updateContext(testSessionId, {
                studentId: 'STU002',
            });
            (0, vitest_1.expect)(updatedContext?.metadata.customField).toBe('test-value');
        });
    });
    (0, vitest_1.describe)('Guardado de Contexto', () => {
        (0, vitest_1.it)('debe guardar contexto correctamente', () => {
            const context = {
                sessionId: testSessionId,
                studentId: testStudentId,
                conversationHistory: [],
                metadata: {},
            };
            conversation_manager_1.ConversationManager.saveContext(context);
            const retrieved = conversation_manager_1.ConversationManager.getContext(testSessionId);
            (0, vitest_1.expect)(retrieved).toBeDefined();
            (0, vitest_1.expect)(retrieved?.sessionId).toBe(testSessionId);
        });
        (0, vitest_1.it)('debe actualizar timestamp al guardar', () => {
            const context = {
                sessionId: testSessionId,
                conversationHistory: [],
                metadata: {},
            };
            conversation_manager_1.ConversationManager.saveContext(context);
            const retrieved = conversation_manager_1.ConversationManager.getContext(testSessionId);
            (0, vitest_1.expect)(retrieved?.metadata.lastActivity).toBeDefined();
        });
    });
    (0, vitest_1.describe)('Limpieza de Contexto', () => {
        (0, vitest_1.it)('debe limpiar contexto de sesión', () => {
            conversation_manager_1.ConversationManager.createContext(testSessionId);
            (0, vitest_1.expect)(conversation_manager_1.ConversationManager.hasActiveSession(testSessionId)).toBe(true);
            conversation_manager_1.ConversationManager.clearContext(testSessionId);
            (0, vitest_1.expect)(conversation_manager_1.ConversationManager.hasActiveSession(testSessionId)).toBe(false);
        });
        (0, vitest_1.it)('debe limpiar sesiones expiradas', () => {
            vitest_1.vi.useFakeTimers();
            // Crear sesión
            conversation_manager_1.ConversationManager.createContext(testSessionId);
            // Avanzar tiempo más allá del timeout (30 minutos)
            vitest_1.vi.advanceTimersByTime(31 * 60 * 1000);
            const cleanedCount = conversation_manager_1.ConversationManager.cleanupExpiredSessions();
            vitest_1.vi.useRealTimers();
            (0, vitest_1.expect)(cleanedCount).toBeGreaterThan(0);
            (0, vitest_1.expect)(conversation_manager_1.ConversationManager.hasActiveSession(testSessionId)).toBe(false);
        });
        (0, vitest_1.it)('debe no limpiar sesiones activas', () => {
            conversation_manager_1.ConversationManager.createContext(testSessionId);
            const cleanedCount = conversation_manager_1.ConversationManager.cleanupExpiredSessions();
            (0, vitest_1.expect)(cleanedCount).toBe(0);
            (0, vitest_1.expect)(conversation_manager_1.ConversationManager.hasActiveSession(testSessionId)).toBe(true);
        });
        (0, vitest_1.it)('debe retornar undefined para sesión expirada', () => {
            vitest_1.vi.useFakeTimers();
            conversation_manager_1.ConversationManager.createContext(testSessionId);
            // Avanzar tiempo más allá del timeout
            vitest_1.vi.advanceTimersByTime(31 * 60 * 1000);
            const context = conversation_manager_1.ConversationManager.getContext(testSessionId);
            vitest_1.vi.useRealTimers();
            (0, vitest_1.expect)(context).toBeUndefined();
        });
    });
    (0, vitest_1.describe)('Metadata', () => {
        (0, vitest_1.it)('debe agregar metadata personalizada', () => {
            conversation_manager_1.ConversationManager.createContext(testSessionId);
            conversation_manager_1.ConversationManager.addMetadata(testSessionId, 'customKey', 'customValue');
            const context = conversation_manager_1.ConversationManager.getContext(testSessionId);
            (0, vitest_1.expect)(context?.metadata.customKey).toBe('customValue');
        });
        (0, vitest_1.it)('debe no agregar metadata a sesión inexistente', () => {
            conversation_manager_1.ConversationManager.addMetadata('non-existent', 'key', 'value');
            const context = conversation_manager_1.ConversationManager.getContext('non-existent');
            (0, vitest_1.expect)(context).toBeUndefined();
        });
        (0, vitest_1.it)('debe soportar diferentes tipos de valores en metadata', () => {
            conversation_manager_1.ConversationManager.createContext(testSessionId);
            conversation_manager_1.ConversationManager.addMetadata(testSessionId, 'number', 42);
            conversation_manager_1.ConversationManager.addMetadata(testSessionId, 'boolean', true);
            conversation_manager_1.ConversationManager.addMetadata(testSessionId, 'object', { nested: 'value' });
            const context = conversation_manager_1.ConversationManager.getContext(testSessionId);
            (0, vitest_1.expect)(context?.metadata.number).toBe(42);
            (0, vitest_1.expect)(context?.metadata.boolean).toBe(true);
            (0, vitest_1.expect)(context?.metadata.object).toEqual({ nested: 'value' });
        });
    });
    (0, vitest_1.describe)('Estadísticas', () => {
        (0, vitest_1.it)('debe obtener conteo de sesiones activas', () => {
            const initialCount = conversation_manager_1.ConversationManager.getActiveSessionCount();
            conversation_manager_1.ConversationManager.createContext(testSessionId);
            const newCount = conversation_manager_1.ConversationManager.getActiveSessionCount();
            (0, vitest_1.expect)(newCount).toBe(initialCount + 1);
        });
        (0, vitest_1.it)('debe obtener estadísticas completas', () => {
            conversation_manager_1.ConversationManager.createContext(testSessionId);
            const stats = conversation_manager_1.ConversationManager.getStats();
            (0, vitest_1.expect)(stats.activeSessions).toBeGreaterThan(0);
            (0, vitest_1.expect)(stats.totalSessions).toBeGreaterThan(0);
        });
        (0, vitest_1.it)('debe identificar sesión más antigua', () => {
            vitest_1.vi.useFakeTimers();
            const session1 = 'session-1';
            const session2 = 'session-2';
            conversation_manager_1.ConversationManager.createContext(session1);
            vitest_1.vi.advanceTimersByTime(1000);
            conversation_manager_1.ConversationManager.createContext(session2);
            const stats = conversation_manager_1.ConversationManager.getStats();
            vitest_1.vi.useRealTimers();
            (0, vitest_1.expect)(stats.oldestSession).toBe(session1);
            // Limpiar
            conversation_manager_1.ConversationManager.clearContext(session1);
            conversation_manager_1.ConversationManager.clearContext(session2);
        });
        (0, vitest_1.it)('debe retornar null para oldestSession cuando no hay sesiones', () => {
            // Limpiar todas las sesiones primero
            conversation_manager_1.ConversationManager.cleanupExpiredSessions();
            const stats = conversation_manager_1.ConversationManager.getStats();
            // Puede haber otras sesiones de otros tests, así que solo verificamos la estructura
            (0, vitest_1.expect)(stats).toHaveProperty('oldestSession');
        });
    });
    (0, vitest_1.describe)('Persistencia entre Turnos', () => {
        (0, vitest_1.it)('debe mantener historial de conversación entre recuperaciones', () => {
            const context = conversation_manager_1.ConversationManager.createContext(testSessionId);
            context.conversationHistory.push({
                role: 'user',
                content: 'Hola',
                timestamp: new Date().toISOString(),
            });
            conversation_manager_1.ConversationManager.saveContext(context);
            const retrieved = conversation_manager_1.ConversationManager.getContext(testSessionId);
            (0, vitest_1.expect)(retrieved?.conversationHistory.length).toBe(1);
            (0, vitest_1.expect)(retrieved?.conversationHistory[0].content).toBe('Hola');
        });
        (0, vitest_1.it)('debe mantener perfil de estudiante entre recuperaciones', () => {
            const context = conversation_manager_1.ConversationManager.createContext(testSessionId, testStudentId);
            context.studentProfile = {
                studentId: testStudentId,
                firstName: 'Carlos',
                lastName: 'Rodríguez',
                email: 'carlos@example.com',
                phone: '+1234567890',
                enrollmentStatus: 'active',
                academicLevel: 'sophomore',
                lastUpdated: new Date().toISOString(),
            };
            conversation_manager_1.ConversationManager.saveContext(context);
            const retrieved = conversation_manager_1.ConversationManager.getContext(testSessionId);
            (0, vitest_1.expect)(retrieved?.studentProfile?.firstName).toBe('Carlos');
            (0, vitest_1.expect)(retrieved?.studentProfile?.lastName).toBe('Rodríguez');
        });
    });
});
//# sourceMappingURL=conversation-manager.test.js.map