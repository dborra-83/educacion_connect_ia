/**
 * Tests para queryKnowledgeBase
 */
export {};
//# sourceMappingURL=query-knowledge-base.test.d.ts.map