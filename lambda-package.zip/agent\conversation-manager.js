"use strict";
/**
 * Gestor de Estado de Conversación
 * Mantiene y persiste el contexto de conversación entre turnos
 */
Object.defineProperty(exports, "__esModule", { value: true });
exports.ConversationManager = void 0;
const logger_1 = require("../utils/logger");
/**
 * Almacenamiento en memoria para contextos de conversación
 * En producción, esto debería usar DynamoDB o similar
 */
const conversationStore = new Map();
/**
 * Tiempo de expiración de sesiones (30 minutos)
 */
const SESSION_TIMEOUT_MS = 30 * 60 * 1000;
/**
 * Gestor de estado de conversación
 */
class ConversationManager {
    /**
     * Obtiene el contexto de conversación para una sesión
     * Si no existe, retorna undefined
     */
    static getContext(sessionId) {
        const context = conversationStore.get(sessionId);
        if (!context) {
            logger_1.logger.info(`No se encontró contexto para sesión: ${sessionId}`);
            return undefined;
        }
        // Verificar si la sesión ha expirado
        const lastActivity = new Date(context.metadata.lastActivity || 0).getTime();
        const now = Date.now();
        if (now - lastActivity > SESSION_TIMEOUT_MS) {
            logger_1.logger.info(`Sesión expirada: ${sessionId}`);
            this.clearContext(sessionId);
            return undefined;
        }
        logger_1.logger.info(`Contexto recuperado para sesión: ${sessionId}`);
        return context;
    }
    /**
     * Guarda o actualiza el contexto de conversación
     */
    static saveContext(context) {
        // Actualizar timestamp de última actividad
        context.metadata.lastActivity = new Date().toISOString();
        conversationStore.set(context.sessionId, context);
        logger_1.logger.info(`Contexto guardado para sesión: ${context.sessionId}`);
    }
    /**
     * Actualiza el contexto de conversación
     */
    static updateContext(sessionId, updates) {
        const context = this.getContext(sessionId);
        if (!context) {
            logger_1.logger.warn(`No se puede actualizar contexto inexistente: ${sessionId}`);
            return undefined;
        }
        // Aplicar actualizaciones
        const updatedContext = {
            ...context,
            ...updates,
            metadata: {
                ...context.metadata,
                ...updates.metadata,
                lastActivity: new Date().toISOString(),
            },
        };
        this.saveContext(updatedContext);
        logger_1.logger.info(`Contexto actualizado para sesión: ${sessionId}`);
        return updatedContext;
    }
    /**
     * Limpia el contexto de una sesión
     */
    static clearContext(sessionId) {
        conversationStore.delete(sessionId);
        logger_1.logger.info(`Contexto eliminado para sesión: ${sessionId}`);
    }
    /**
     * Limpia todas las sesiones expiradas
     */
    static cleanupExpiredSessions() {
        const now = Date.now();
        let cleanedCount = 0;
        for (const [sessionId, context] of conversationStore.entries()) {
            const lastActivity = new Date(context.metadata.lastActivity || 0).getTime();
            if (now - lastActivity > SESSION_TIMEOUT_MS) {
                conversationStore.delete(sessionId);
                cleanedCount++;
                logger_1.logger.info(`Sesión expirada limpiada: ${sessionId}`);
            }
        }
        if (cleanedCount > 0) {
            logger_1.logger.info(`Limpiadas ${cleanedCount} sesiones expiradas`);
        }
        return cleanedCount;
    }
    /**
     * Obtiene el número de sesiones activas
     */
    static getActiveSessionCount() {
        return conversationStore.size;
    }
    /**
     * Verifica si una sesión existe y está activa
     */
    static hasActiveSession(sessionId) {
        const context = this.getContext(sessionId);
        return context !== undefined;
    }
    /**
     * Crea un nuevo contexto de conversación
     */
    static createContext(sessionId, studentId) {
        const context = {
            sessionId,
            studentId,
            conversationHistory: [],
            entities: new Map(),
            metadata: {
                createdAt: new Date().toISOString(),
                lastActivity: new Date().toISOString(),
            },
        };
        this.saveContext(context);
        logger_1.logger.info(`Nuevo contexto creado para sesión: ${sessionId}`);
        return context;
    }
    /**
     * Obtiene o crea un contexto de conversación
     */
    static getOrCreateContext(sessionId, studentId) {
        let context = this.getContext(sessionId);
        if (!context) {
            context = this.createContext(sessionId, studentId);
        }
        else if (studentId && !context.studentId) {
            // Actualizar studentId si no estaba presente
            context = this.updateContext(sessionId, { studentId }) || context;
        }
        return context;
    }
    /**
     * Agrega metadata personalizada al contexto
     */
    static addMetadata(sessionId, key, value) {
        const context = this.getContext(sessionId);
        if (!context) {
            logger_1.logger.warn(`No se puede agregar metadata a sesión inexistente: ${sessionId}`);
            return;
        }
        context.metadata[key] = value;
        this.saveContext(context);
        logger_1.logger.info(`Metadata agregada a sesión ${sessionId}: ${key}`);
    }
    /**
     * Obtiene estadísticas del gestor de conversaciones
     */
    static getStats() {
        let oldestTimestamp = Date.now();
        let oldestSessionId = null;
        for (const [sessionId, context] of conversationStore.entries()) {
            const lastActivity = new Date(context.metadata.lastActivity || 0).getTime();
            if (lastActivity < oldestTimestamp) {
                oldestTimestamp = lastActivity;
                oldestSessionId = sessionId;
            }
        }
        return {
            activeSessions: conversationStore.size,
            totalSessions: conversationStore.size,
            oldestSession: oldestSessionId,
        };
    }
}
exports.ConversationManager = ConversationManager;
//# sourceMappingURL=conversation-manager.js.map