/**
 * Tests para el Motor de Razonamiento del Agente
 */
export {};
//# sourceMappingURL=reasoning-engine.test.d.ts.map