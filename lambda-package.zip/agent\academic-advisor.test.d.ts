/**
 * Tests para academic-advisor
 */
export {};
//# sourceMappingURL=academic-advisor.test.d.ts.map