"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const vitest_1 = require("vitest");
const logger_1 = require("./logger");
(0, vitest_1.describe)('Logger', () => {
    let consoleErrorSpy;
    let consoleWarnSpy;
    let consoleInfoSpy;
    let consoleDebugSpy;
    (0, vitest_1.beforeEach)(() => {
        consoleErrorSpy = vitest_1.vi.spyOn(console, 'error').mockImplementation(() => { });
        consoleWarnSpy = vitest_1.vi.spyOn(console, 'warn').mockImplementation(() => { });
        consoleInfoSpy = vitest_1.vi.spyOn(console, 'info').mockImplementation(() => { });
        consoleDebugSpy = vitest_1.vi.spyOn(console, 'debug').mockImplementation(() => { });
    });
    (0, vitest_1.afterEach)(() => {
        vitest_1.vi.restoreAllMocks();
    });
    (0, vitest_1.it)('debe registrar mensajes de error', () => {
        logger_1.logger.error('Test error message');
        (0, vitest_1.expect)(consoleErrorSpy).toHaveBeenCalledTimes(1);
        const logEntry = JSON.parse(consoleErrorSpy.mock.calls[0][0]);
        (0, vitest_1.expect)(logEntry.level).toBe(logger_1.LogLevel.ERROR);
        (0, vitest_1.expect)(logEntry.message).toBe('Test error message');
        (0, vitest_1.expect)(logEntry.timestamp).toBeDefined();
    });
    (0, vitest_1.it)('debe registrar mensajes de advertencia', () => {
        logger_1.logger.warn('Test warning message');
        (0, vitest_1.expect)(consoleWarnSpy).toHaveBeenCalledTimes(1);
        const logEntry = JSON.parse(consoleWarnSpy.mock.calls[0][0]);
        (0, vitest_1.expect)(logEntry.level).toBe(logger_1.LogLevel.WARN);
        (0, vitest_1.expect)(logEntry.message).toBe('Test warning message');
    });
    (0, vitest_1.it)('debe registrar mensajes informativos', () => {
        logger_1.logger.info('Test info message');
        (0, vitest_1.expect)(consoleInfoSpy).toHaveBeenCalledTimes(1);
        const logEntry = JSON.parse(consoleInfoSpy.mock.calls[0][0]);
        (0, vitest_1.expect)(logEntry.level).toBe(logger_1.LogLevel.INFO);
        (0, vitest_1.expect)(logEntry.message).toBe('Test info message');
    });
    (0, vitest_1.it)('debe registrar mensajes de debug', () => {
        logger_1.logger.debug('Test debug message');
        (0, vitest_1.expect)(consoleDebugSpy).toHaveBeenCalledTimes(1);
        const logEntry = JSON.parse(consoleDebugSpy.mock.calls[0][0]);
        (0, vitest_1.expect)(logEntry.level).toBe(logger_1.LogLevel.DEBUG);
        (0, vitest_1.expect)(logEntry.message).toBe('Test debug message');
    });
    (0, vitest_1.it)('debe incluir datos adicionales en el log', () => {
        const errorData = { code: 'ERR_001', details: 'Error details' };
        logger_1.logger.error('Error with data', errorData);
        const logEntry = JSON.parse(consoleErrorSpy.mock.calls[0][0]);
        (0, vitest_1.expect)(logEntry.data).toBeDefined();
        (0, vitest_1.expect)(logEntry.data[0]).toEqual(errorData);
    });
    (0, vitest_1.it)('debe incluir timestamp en formato ISO', () => {
        logger_1.logger.info('Test timestamp');
        const logEntry = JSON.parse(consoleInfoSpy.mock.calls[0][0]);
        (0, vitest_1.expect)(logEntry.timestamp).toMatch(/^\d{4}-\d{2}-\d{2}T\d{2}:\d{2}:\d{2}\.\d{3}Z$/);
    });
    (0, vitest_1.it)('debe manejar múltiples argumentos', () => {
        logger_1.logger.error('Error', { code: 'ERR_001' }, { context: 'test' });
        const logEntry = JSON.parse(consoleErrorSpy.mock.calls[0][0]);
        (0, vitest_1.expect)(logEntry.data).toHaveLength(2);
    });
});
//# sourceMappingURL=logger.test.js.map