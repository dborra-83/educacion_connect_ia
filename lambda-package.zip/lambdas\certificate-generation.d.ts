/**
 * Lambda Handler para Generación de Certificados
 * Simula la generación de certificados académicos en PDF
 */
export declare const handler: (event: any) => Promise<any>;
//# sourceMappingURL=certificate-generation.d.ts.map