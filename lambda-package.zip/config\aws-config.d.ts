/**
 * Configuración de AWS y servicios
 */
export declare const awsConfig: {
    region: string;
    accountId: string;
    connect: {
        instanceId: string;
        instanceArn: string;
        instanceAlias: string;
    };
    dynamodb: {
        studentProfilesTable: string;
    };
    lambda: {
        academicApiArn: string;
        certificateGeneratorArn: string;
    };
    knowledgeBase: {
        s3Bucket: string;
        kendraIndexId: string;
    };
    logging: {
        level: string;
    };
};
//# sourceMappingURL=aws-config.d.ts.map