/**
 * Gestor de Estado de Conversación
 * Mantiene y persiste el contexto de conversación entre turnos
 */
import { ConversationContext } from '../types/models';
/**
 * Gestor de estado de conversación
 */
export declare class ConversationManager {
    /**
     * Obtiene el contexto de conversación para una sesión
     * Si no existe, retorna undefined
     */
    static getContext(sessionId: string): ConversationContext | undefined;
    /**
     * Guarda o actualiza el contexto de conversación
     */
    static saveContext(context: ConversationContext): void;
    /**
     * Actualiza el contexto de conversación
     */
    static updateContext(sessionId: string, updates: Partial<ConversationContext>): ConversationContext | undefined;
    /**
     * Limpia el contexto de una sesión
     */
    static clearContext(sessionId: string): void;
    /**
     * Limpia todas las sesiones expiradas
     */
    static cleanupExpiredSessions(): number;
    /**
     * Obtiene el número de sesiones activas
     */
    static getActiveSessionCount(): number;
    /**
     * Verifica si una sesión existe y está activa
     */
    static hasActiveSession(sessionId: string): boolean;
    /**
     * Crea un nuevo contexto de conversación
     */
    static createContext(sessionId: string, studentId?: string): ConversationContext;
    /**
     * Obtiene o crea un contexto de conversación
     */
    static getOrCreateContext(sessionId: string, studentId?: string): ConversationContext;
    /**
     * Agrega metadata personalizada al contexto
     */
    static addMetadata(sessionId: string, key: string, value: unknown): void;
    /**
     * Obtiene estadísticas del gestor de conversaciones
     */
    static getStats(): {
        activeSessions: number;
        totalSessions: number;
        oldestSession: string | null;
    };
}
//# sourceMappingURL=conversation-manager.d.ts.map