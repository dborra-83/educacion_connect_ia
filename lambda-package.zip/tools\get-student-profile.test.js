"use strict";
/**
 * Tests para getStudentProfile
 */
Object.defineProperty(exports, "__esModule", { value: true });
const vitest_1 = require("vitest");
const get_student_profile_1 = require("./get-student-profile");
const errors_1 = require("../types/errors");
(0, vitest_1.describe)('getStudentProfile', () => {
    (0, vitest_1.describe)('Casos de éxito', () => {
        (0, vitest_1.it)('debe recuperar perfil completo de estudiante existente', async () => {
            const result = await (0, get_student_profile_1.getStudentProfileMock)({
                studentId: 'STU001',
                includeAcademic: true,
                includeCRM: true,
            });
            (0, vitest_1.expect)(result).toBeDefined();
            (0, vitest_1.expect)(result.studentId).toBe('STU001');
            (0, vitest_1.expect)(result.firstName).toBe('Carlos');
            (0, vitest_1.expect)(result.lastName).toBe('Rodríguez');
            (0, vitest_1.expect)(result.email).toContain('@universidad.edu');
            (0, vitest_1.expect)(result.program).toBeDefined();
            (0, vitest_1.expect)(result.program?.name).toBe('Ingeniería Informática');
            (0, vitest_1.expect)(result.crmData).toBeDefined();
        });
        (0, vitest_1.it)('debe recuperar perfil sin datos CRM cuando includeCRM es false', async () => {
            const result = await (0, get_student_profile_1.getStudentProfileMock)({
                studentId: 'STU002',
                includeAcademic: true,
                includeCRM: false,
            });
            (0, vitest_1.expect)(result).toBeDefined();
            (0, vitest_1.expect)(result.studentId).toBe('STU002');
            (0, vitest_1.expect)(result.crmData).toBeUndefined();
        });
    });
    (0, vitest_1.describe)('Casos de error', () => {
        (0, vitest_1.it)('debe lanzar StudentNotFoundError cuando el estudiante no existe', async () => {
            await (0, vitest_1.expect)((0, get_student_profile_1.getStudentProfileMock)({
                studentId: 'STU999',
            })).rejects.toThrow(errors_1.StudentNotFoundError);
        });
        (0, vitest_1.it)('debe lanzar InvalidStudentIdError cuando el ID está vacío', async () => {
            await (0, vitest_1.expect)((0, get_student_profile_1.getStudentProfileMock)({
                studentId: '',
            })).rejects.toThrow(errors_1.InvalidStudentIdError);
        });
        (0, vitest_1.it)('debe lanzar InvalidStudentIdError cuando el ID es muy corto', async () => {
            await (0, vitest_1.expect)((0, get_student_profile_1.getStudentProfileMock)({
                studentId: 'AB',
            })).rejects.toThrow(errors_1.InvalidStudentIdError);
        });
    });
    (0, vitest_1.describe)('Validación de datos', () => {
        (0, vitest_1.it)('debe retornar email válido', async () => {
            const result = await (0, get_student_profile_1.getStudentProfileMock)({
                studentId: 'STU001',
            });
            (0, vitest_1.expect)(result.email).toMatch(/^[^\s@]+@[^\s@]+\.[^\s@]+$/);
        });
        (0, vitest_1.it)('debe retornar teléfono con formato válido', async () => {
            const result = await (0, get_student_profile_1.getStudentProfileMock)({
                studentId: 'STU001',
            });
            (0, vitest_1.expect)(result.phone).toBeTruthy();
            (0, vitest_1.expect)(result.phone.length).toBeGreaterThan(5);
        });
        (0, vitest_1.it)('debe retornar programa académico con código', async () => {
            const result = await (0, get_student_profile_1.getStudentProfileMock)({
                studentId: 'STU001',
                includeAcademic: true,
            });
            (0, vitest_1.expect)(result.program).toBeDefined();
            (0, vitest_1.expect)(result.program?.code).toBeTruthy();
            (0, vitest_1.expect)(result.program?.name).toBeTruthy();
        });
    });
});
//# sourceMappingURL=get-student-profile.test.js.map