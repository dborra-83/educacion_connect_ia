/**
 * Orquestador de Generación de Certificados
 * Maneja el flujo completo: verificación de identidad, deudas, generación y entrega
 */
import { StudentProfile, GenerateCertificateInput, GenerateCertificateResult } from '../types/mcp-tools';
/**
 * Resultado del proceso de generación de certificado
 */
export interface CertificateProcessResult {
    success: boolean;
    certificateResult?: GenerateCertificateResult;
    message: string;
    blockedReason?: string;
}
/**
 * Orquesta el proceso completo de generación de certificado
 * Implementa el flujo: verificar identidad → verificar deudas → generar → entregar
 */
export declare function orchestrateCertificateGeneration(input: GenerateCertificateInput, useMock?: boolean): Promise<CertificateProcessResult>;
/**
 * Genera mensaje de inicio del proceso
 */
export declare function generateCertificateRequestMessage(profile: StudentProfile, certificateType: string): string;
/**
 * Valida que el tipo de certificado sea válido
 */
export declare function validateCertificateRequest(certificateType: string): {
    valid: boolean;
    message?: string;
};
//# sourceMappingURL=certificate-orchestrator.d.ts.map