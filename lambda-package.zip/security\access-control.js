"use strict";
/**
 * Control de acceso y detección de intentos no autorizados
 * Cumple con requisito 10.5: Bloqueo de accesos no autorizados
 */
Object.defineProperty(exports, "__esModule", { value: true });
exports.AccessControl = void 0;
const logger_1 = require("../utils/logger");
const audit_logger_1 = require("./audit-logger");
const authentication_1 = require("./authentication");
/**
 * Contador de intentos sospechosos por sesión
 */
const suspiciousAttempts = new Map();
/**
 * Sesiones bloqueadas temporalmente
 */
const blockedSessions = new Map();
/**
 * Control de acceso
 */
class AccessControl {
    /**
     * Verifica si se permite el acceso a un recurso
     */
    static async checkAccess(params) {
        const { sessionId, authenticatedStudentId, requestedStudentId, resourceType, operation } = params;
        // Verificar si la sesión está bloqueada
        if (this.isSessionBlocked(sessionId)) {
            logger_1.logger.warn('Acceso denegado: sesión bloqueada', {
                sessionId,
                resourceType,
            });
            return {
                allowed: false,
                blocked: true,
                reason: 'Sesión bloqueada por actividad sospechosa',
                requiresEscalation: true,
            };
        }
        // Verificar si la operación requiere autenticación
        if (authentication_1.AuthenticationMiddleware.requiresAuthentication(operation)) {
            if (!authenticatedStudentId) {
                logger_1.logger.warn('Acceso denegado: no autenticado', {
                    sessionId,
                    operation,
                });
                return {
                    allowed: false,
                    reason: 'Autenticación requerida',
                };
            }
            // Verificar que el estudiante solo acceda a sus propios datos
            if (authenticatedStudentId !== requestedStudentId) {
                logger_1.logger.warn('Intento de acceso no autorizado detectado', {
                    sessionId,
                    authenticatedStudentId,
                    requestedStudentId,
                    resourceType,
                });
                // Registrar intento no autorizado
                await audit_logger_1.AuditLogger.logUnauthorizedAccessAttempt(sessionId, authenticatedStudentId, requestedStudentId, resourceType);
                // Incrementar contador de intentos sospechosos
                this.recordSuspiciousAttempt(sessionId);
                // Verificar si se debe bloquear la sesión
                if (this.shouldBlockSession(sessionId)) {
                    this.blockSession(sessionId);
                    return {
                        allowed: false,
                        blocked: true,
                        reason: 'Sesión bloqueada por múltiples intentos no autorizados',
                        requiresEscalation: true,
                    };
                }
                return {
                    allowed: false,
                    reason: 'No autorizado para acceder a datos de otro estudiante',
                };
            }
        }
        // Acceso permitido
        return {
            allowed: true,
        };
    }
    /**
     * Verifica si una sesión está bloqueada
     */
    static isSessionBlocked(sessionId) {
        const blockTime = blockedSessions.get(sessionId);
        if (!blockTime) {
            return false;
        }
        // Verificar si el bloqueo ha expirado (15 minutos)
        const now = Date.now();
        const blockDuration = 15 * 60 * 1000; // 15 minutos
        if (now - blockTime > blockDuration) {
            // Bloqueo expirado, remover
            blockedSessions.delete(sessionId);
            suspiciousAttempts.delete(sessionId);
            return false;
        }
        return true;
    }
    /**
     * Registra un intento sospechoso
     */
    static recordSuspiciousAttempt(sessionId) {
        const currentAttempts = suspiciousAttempts.get(sessionId) || 0;
        suspiciousAttempts.set(sessionId, currentAttempts + 1);
        logger_1.logger.warn('Intento sospechoso registrado', {
            sessionId,
            totalAttempts: currentAttempts + 1,
        });
    }
    /**
     * Determina si se debe bloquear una sesión
     */
    static shouldBlockSession(sessionId) {
        const attempts = suspiciousAttempts.get(sessionId) || 0;
        const threshold = 3; // Bloquear después de 3 intentos
        return attempts >= threshold;
    }
    /**
     * Bloquea una sesión temporalmente
     */
    static blockSession(sessionId) {
        blockedSessions.set(sessionId, Date.now());
        logger_1.logger.error('Sesión bloqueada por actividad sospechosa', {
            sessionId,
            attempts: suspiciousAttempts.get(sessionId),
            blockDuration: '15 minutos',
        });
    }
    /**
     * Desbloquea una sesión manualmente
     */
    static unblockSession(sessionId) {
        blockedSessions.delete(sessionId);
        suspiciousAttempts.delete(sessionId);
        logger_1.logger.info('Sesión desbloqueada manualmente', { sessionId });
    }
    /**
     * Obtiene estadísticas de seguridad
     */
    static getSecurityStats() {
        return {
            blockedSessions: blockedSessions.size,
            suspiciousAttempts: suspiciousAttempts.size,
        };
    }
    /**
     * Limpia sesiones bloqueadas expiradas
     */
    static cleanupExpiredBlocks() {
        const now = Date.now();
        const blockDuration = 15 * 60 * 1000;
        let cleanedCount = 0;
        for (const [sessionId, blockTime] of blockedSessions.entries()) {
            if (now - blockTime > blockDuration) {
                blockedSessions.delete(sessionId);
                suspiciousAttempts.delete(sessionId);
                cleanedCount++;
            }
        }
        if (cleanedCount > 0) {
            logger_1.logger.info('Bloqueos expirados limpiados', { count: cleanedCount });
        }
        return cleanedCount;
    }
}
exports.AccessControl = AccessControl;
//# sourceMappingURL=access-control.js.map