"use strict";
/**
 * Tests para generateCertificate
 */
Object.defineProperty(exports, "__esModule", { value: true });
const vitest_1 = require("vitest");
const generate_certificate_1 = require("./generate-certificate");
const errors_1 = require("../types/errors");
(0, vitest_1.describe)('generateCertificate', () => {
    (0, vitest_1.describe)('Casos de éxito', () => {
        (0, vitest_1.it)('debe generar certificado de inscripción exitosamente', async () => {
            const result = await (0, generate_certificate_1.generateCertificateMock)({
                studentId: 'STU001',
                certificateType: 'enrollment',
                deliveryMethod: 'email',
            });
            (0, vitest_1.expect)(result).toBeDefined();
            (0, vitest_1.expect)(result.certificateId).toBeTruthy();
            (0, vitest_1.expect)(result.status).toBe('sent');
            (0, vitest_1.expect)(result.generatedAt).toBeTruthy();
            (0, vitest_1.expect)(result.deliveryStatus).toBeDefined();
            (0, vitest_1.expect)(result.deliveryStatus?.method).toBe('email');
        });
        (0, vitest_1.it)('debe generar certificado de calificaciones', async () => {
            const result = await (0, generate_certificate_1.generateCertificateMock)({
                studentId: 'STU002',
                certificateType: 'grades',
                deliveryMethod: 'email',
            });
            (0, vitest_1.expect)(result.certificateId).toBeTruthy();
            (0, vitest_1.expect)(result.status).toBe('sent');
        });
        (0, vitest_1.it)('debe generar certificado de graduación', async () => {
            const result = await (0, generate_certificate_1.generateCertificateMock)({
                studentId: 'STU001',
                certificateType: 'graduation',
                deliveryMethod: 'email',
            });
            (0, vitest_1.expect)(result.certificateId).toBeTruthy();
            (0, vitest_1.expect)(result.status).toBe('sent');
        });
        (0, vitest_1.it)('debe proporcionar URL de descarga cuando deliveryMethod es download', async () => {
            const result = await (0, generate_certificate_1.generateCertificateMock)({
                studentId: 'STU001',
                certificateType: 'enrollment',
                deliveryMethod: 'download',
            });
            (0, vitest_1.expect)(result.downloadUrl).toBeTruthy();
            (0, vitest_1.expect)(result.downloadUrl).toMatch(/^https:\/\//);
            (0, vitest_1.expect)(result.expiresAt).toBeTruthy();
        });
        (0, vitest_1.it)('debe incluir destino de email en deliveryStatus', async () => {
            const result = await (0, generate_certificate_1.generateCertificateMock)({
                studentId: 'STU001',
                certificateType: 'enrollment',
                deliveryMethod: 'email',
            });
            (0, vitest_1.expect)(result.deliveryStatus?.destination).toContain('@universidad.edu');
            (0, vitest_1.expect)(result.deliveryStatus?.sentAt).toBeTruthy();
        });
        (0, vitest_1.it)('debe usar idioma español por defecto', async () => {
            const result = await (0, generate_certificate_1.generateCertificateMock)({
                studentId: 'STU001',
                certificateType: 'enrollment',
                deliveryMethod: 'email',
            });
            (0, vitest_1.expect)(result).toBeDefined();
            // En producción, verificaríamos que el PDF está en español
        });
    });
    (0, vitest_1.describe)('Validación de deudas', () => {
        (0, vitest_1.it)('debe bloquear generación si el estudiante tiene deudas', async () => {
            await (0, vitest_1.expect)((0, generate_certificate_1.generateCertificateMock)({
                studentId: 'STU003',
                certificateType: 'enrollment',
                deliveryMethod: 'email',
            })).rejects.toThrow(errors_1.StudentHasDebtsError);
        });
        (0, vitest_1.it)('debe incluir monto de deuda en el error', async () => {
            try {
                await (0, generate_certificate_1.generateCertificateMock)({
                    studentId: 'STU003',
                    certificateType: 'enrollment',
                    deliveryMethod: 'email',
                });
            }
            catch (error) {
                (0, vitest_1.expect)(error).toBeInstanceOf(errors_1.StudentHasDebtsError);
                (0, vitest_1.expect)(error.metadata?.debtAmount).toBeGreaterThan(0);
            }
        });
    });
    (0, vitest_1.describe)('Casos de error', () => {
        (0, vitest_1.it)('debe lanzar InvalidCertificateTypeError para tipo inválido', async () => {
            await (0, vitest_1.expect)((0, generate_certificate_1.generateCertificateMock)({
                studentId: 'STU001',
                certificateType: 'invalid_type',
                deliveryMethod: 'email',
            })).rejects.toThrow(errors_1.InvalidCertificateTypeError);
        });
        (0, vitest_1.it)('debe lanzar InvalidStudentIdError cuando el ID está vacío', async () => {
            await (0, vitest_1.expect)((0, generate_certificate_1.generateCertificateMock)({
                studentId: '',
                certificateType: 'enrollment',
                deliveryMethod: 'email',
            })).rejects.toThrow(errors_1.InvalidStudentIdError);
        });
        (0, vitest_1.it)('debe manejar fallo en generación de PDF', async () => {
            await (0, vitest_1.expect)((0, generate_certificate_1.generateCertificateFailMock)({
                studentId: 'STU001',
                certificateType: 'enrollment',
                deliveryMethod: 'email',
            })).rejects.toThrow(errors_1.GenerationFailedError);
        });
        (0, vitest_1.it)('debe manejar fallo en entrega de certificado', async () => {
            await (0, vitest_1.expect)((0, generate_certificate_1.generateCertificateDeliveryFailMock)({
                studentId: 'STU001',
                certificateType: 'enrollment',
                deliveryMethod: 'email',
            })).rejects.toThrow(errors_1.DeliveryFailedError);
        });
    });
    (0, vitest_1.describe)('Validación de datos', () => {
        (0, vitest_1.it)('debe generar certificateId único', async () => {
            const result1 = await (0, generate_certificate_1.generateCertificateMock)({
                studentId: 'STU001',
                certificateType: 'enrollment',
                deliveryMethod: 'email',
            });
            // Pequeño delay para asegurar timestamp diferente
            await new Promise((resolve) => setTimeout(resolve, 10));
            const result2 = await (0, generate_certificate_1.generateCertificateMock)({
                studentId: 'STU001',
                certificateType: 'enrollment',
                deliveryMethod: 'email',
            });
            (0, vitest_1.expect)(result1.certificateId).not.toBe(result2.certificateId);
        });
        (0, vitest_1.it)('debe incluir timestamp de generación', async () => {
            const before = new Date().toISOString();
            const result = await (0, generate_certificate_1.generateCertificateMock)({
                studentId: 'STU001',
                certificateType: 'enrollment',
                deliveryMethod: 'email',
            });
            const after = new Date().toISOString();
            (0, vitest_1.expect)(result.generatedAt).toBeTruthy();
            (0, vitest_1.expect)(result.generatedAt >= before).toBe(true);
            (0, vitest_1.expect)(result.generatedAt <= after).toBe(true);
        });
        (0, vitest_1.it)('debe tener URL de descarga válida cuando deliveryMethod es download', async () => {
            const result = await (0, generate_certificate_1.generateCertificateMock)({
                studentId: 'STU001',
                certificateType: 'enrollment',
                deliveryMethod: 'download',
            });
            (0, vitest_1.expect)(result.downloadUrl).toMatch(/^https:\/\/.*\.pdf$/);
        });
        (0, vitest_1.it)('debe tener fecha de expiración futura para URLs de descarga', async () => {
            const result = await (0, generate_certificate_1.generateCertificateMock)({
                studentId: 'STU001',
                certificateType: 'enrollment',
                deliveryMethod: 'download',
            });
            const expiresAt = new Date(result.expiresAt);
            const now = new Date();
            (0, vitest_1.expect)(expiresAt.getTime()).toBeGreaterThan(now.getTime());
        });
    });
});
//# sourceMappingURL=generate-certificate.test.js.map