/**
 * Asesor Académico Proactivo
 * Analiza el historial académico y genera recomendaciones personalizadas
 */
import { AcademicRecord } from '../types/mcp-tools';
/**
 * Resultado del análisis académico
 */
export interface AcademicAnalysis {
    hasIssues: boolean;
    failedCourses: Array<{
        courseCode: string;
        courseName: string;
        semester: string;
    }>;
    coursesAtRisk: Array<{
        courseCode: string;
        courseName: string;
        alertType: string;
    }>;
    lowGPA: boolean;
    gpaValue: number;
    recommendations: string[];
}
/**
 * Analiza el historial académico del estudiante
 * Detecta materias reprobadas, en riesgo y bajo GPA
 */
export declare function analyzeAcademicRecord(record: AcademicRecord): AcademicAnalysis;
/**
 * Genera recomendaciones de tutoría para materias reprobadas
 */
export declare function generateTutoringRecommendation(failedCourses: AcademicAnalysis['failedCourses']): string;
/**
 * Genera recomendaciones de recursos académicos para materias en riesgo
 */
export declare function generateResourceRecommendation(coursesAtRisk: AcademicAnalysis['coursesAtRisk']): string;
/**
 * Genera recomendación de cursos de verano
 */
export declare function generateSummerCoursesRecommendation(failedCourses: AcademicAnalysis['failedCourses']): string;
/**
 * Genera recomendación para mejorar GPA
 */
export declare function generateGPAImprovementRecommendation(gpa: number): string;
/**
 * Genera mensaje proactivo completo basado en el análisis
 */
export declare function generateProactiveMessage(analysis: AcademicAnalysis): string;
/**
 * Analiza impedimentos antes de realizar un trámite
 */
export interface ImpedimentAnalysis {
    hasImpediments: boolean;
    impediments: Array<{
        type: 'academic' | 'financial';
        severity: 'high' | 'medium' | 'low';
        message: string;
    }>;
    canProceed: boolean;
}
/**
 * Analiza impedimentos académicos y financieros antes de un trámite
 */
export declare function analyzeImpediments(record: AcademicRecord): ImpedimentAnalysis;
/**
 * Genera mensaje de impedimentos
 */
export declare function generateImpedimentMessage(analysis: ImpedimentAnalysis): string;
//# sourceMappingURL=academic-advisor.d.ts.map