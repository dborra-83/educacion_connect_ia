/**
 * Tests para checkAcademicRecord
 */
export {};
//# sourceMappingURL=check-academic-record.test.d.ts.map